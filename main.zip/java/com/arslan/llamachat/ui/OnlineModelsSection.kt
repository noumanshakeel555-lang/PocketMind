package com.arslan.llamachat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class OnlineModelEntry(
    val key: String,
    val displayName: String,
    val provider: String,
    val modelId: String,
    val speed: String,
    val limit: String,
    val color: Color,
    val hasKey: Boolean,
    val tier: String,
    val description: String,
    val supportsVision: Boolean = false,
)

@Composable
fun OnlineModelsSection(
    groqKeySet: Boolean,
    geminiKeySet: Boolean,
    activeProvider: String,
    onSelect: (String) -> Unit,
    onSetupKeys: () -> Unit,
    onChat: () -> Unit,
    onTest: (String) -> Unit,
    huggingFaceKeySet: Boolean = false,
    togetherKeySet: Boolean = false,
) {
    val freeModels = listOf(
        OnlineModelEntry(
            key = "groq",
            displayName = "Llama 3.3 70B + Vision",
            provider = "Groq",
            modelId = "llama-3.3-70b / llama-4-scout",
            speed = "~1–2 sec",
            limit = "Text + photo vision",
            color = Color(0xFF00A67E),
            hasKey = groqKeySet,
            tier = "Free-tier where available",
            description = "Fast online chat option. Text and photo requests are sent directly to Groq when selected.",
            supportsVision = true,
        ),
        OnlineModelEntry(
            key = "gemini",
            displayName = "Gemini 2.5 Flash",
            provider = "Google",
            modelId = "gemini-2.5-flash",
            speed = "~1–3 sec",
            limit = "Text + photo vision",
            color = Color(0xFF4285F4),
            hasKey = geminiKeySet,
            tier = "Free-tier where available",
            description = "Balanced online model for chat, studying, summaries, and image understanding. Requests are sent directly to Google when selected.",
            supportsVision = true,
        ),
        OnlineModelEntry(
            key = "hf_qwen_coder",
            displayName = "Qwen Coder 7B",
            provider = "Hugging Face",
            modelId = "Qwen/Qwen2.5-Coder-7B-Instruct",
            speed = "variable",
            limit = "Coding + reasoning",
            color = Color(0xFFFFC107),
            hasKey = huggingFaceKeySet,
            tier = "Provider free-tier with HF token",
            description = "Online coding assistant through Hugging Face Router. Request content is sent directly to Hugging Face when selected.",
        ),
        OnlineModelEntry(
            key = "hf_mistral",
            displayName = "Mistral 7B Instruct",
            provider = "Hugging Face",
            modelId = "mistralai/Mistral-7B-Instruct-v0.3",
            speed = "variable",
            limit = "General chat",
            color = Color(0xFFFFC107),
            hasKey = huggingFaceKeySet,
            tier = "Provider free-tier with HF token",
            description = "General-purpose online model through Hugging Face Router. Request content is sent directly to Hugging Face when selected.",
        ),
    )

    val premiumModels = listOf(
        OnlineModelEntry(
            key = "together_llama",
            displayName = "Llama 3.3 70B",
            provider = "Together AI",
            modelId = "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free",
            speed = "fast",
            limit = "Premium/free-credit",
            color = Color(0xFF7C4DFF),
            hasKey = togetherKeySet,
            tier = "Premium / credit-based",
            description = "Strong online reasoning model. Request content is sent directly to Together AI when selected.",
        ),
        OnlineModelEntry(
            key = "together_qwen",
            displayName = "Qwen 2.5 72B",
            provider = "Together AI",
            modelId = "Qwen/Qwen2.5-72B-Instruct-Turbo",
            speed = "fast",
            limit = "Premium/credit-based",
            color = Color(0xFF7C4DFF),
            hasKey = togetherKeySet,
            tier = "Premium / credit-based",
            description = "Large online reasoning model for study, coding, and professional writing. Requests go directly to Together AI.",
        ),
        OnlineModelEntry(
            key = "together_mixtral",
            displayName = "Mixtral 8x7B",
            provider = "Together AI",
            modelId = "mistralai/Mixtral-8x7B-Instruct-v0.1",
            speed = "fast",
            limit = "Premium/credit-based",
            color = Color(0xFF7C4DFF),
            hasKey = togetherKeySet,
            tier = "Premium / credit-based",
            description = "Reliable online model for chat, explanations, and summaries. Requests go directly to Together AI.",
        ),
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        OnlineTierHeader(
            icon = Icons.Default.AutoAwesome,
            title = "Free-tier online models",
            subtitle = "Provider-hosted models. Prompts, context, and supported attachments are sent only to the selected provider."
        )
        freeModels.forEach { model ->
            OnlineModelCard(
                model = model,
                isActive = activeProvider == model.key,
                onSelect = { if (model.hasKey) onSelect(model.key) else onSetupKeys() },
                onChat = onChat,
                onSetupKeys = onSetupKeys,
                onTest = { onTest(model.key) },
            )
        }

        OnlineTierHeader(
            icon = Icons.Default.WorkspacePremium,
            title = "Premium / credit-based online models",
            subtitle = "Provider-hosted models for stronger responses when your key is available."
        )
        premiumModels.forEach { model ->
            OnlineModelCard(
                model = model,
                isActive = activeProvider == model.key,
                onSelect = { if (model.hasKey) onSelect(model.key) else onSetupKeys() },
                onChat = onChat,
                onSetupKeys = onSetupKeys,
                onTest = { onTest(model.key) },
            )
        }

        if (!groqKeySet && !geminiKeySet && !huggingFaceKeySet && !togetherKeySet) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, null, tint = MaterialTheme.colorScheme.tertiary)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Set up online AI", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Add a provider key once. Keys stay on-device and are used only to call the selected provider.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.75f)
                        )
                    }
                    FilledTonalButton(onClick = onSetupKeys, shape = RoundedCornerShape(14.dp)) { Text("Keys") }
                }
            }
        }
    }
}

@Composable
private fun OnlineTierHeader(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun OnlineModelCard(
    model: OnlineModelEntry,
    isActive: Boolean,
    onSelect: () -> Unit,
    onChat: () -> Unit,
    onSetupKeys: () -> Unit,
    onTest: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isActive) 4.dp else 2.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(17.dp)).background(model.color),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(model.provider.first().toString(), color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(model.displayName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Badge(containerColor = if (model.hasKey) MaterialTheme.colorScheme.primary else Color(0xFFFFC107)) {
                            Text(if (model.hasKey) "READY" else "KEY", modifier = Modifier.padding(horizontal = 4.dp), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Text(
                        "${model.provider} · ${model.speed} · ${model.limit}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(model.modelId, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                if (isActive) Icon(Icons.Default.CheckCircle, "Active", tint = MaterialTheme.colorScheme.primary)
            }

            Text(model.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AssistChip(onClick = {}, enabled = false, label = { Text(model.tier) })
                if (model.supportsVision) AssistChip(onClick = {}, enabled = false, label = { Text("Vision") })
                else AssistChip(onClick = {}, enabled = false, label = { Text("Text") })
            }

            if (model.hasKey) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(onClick = onSelect, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                        Icon(if (isActive) Icons.Default.Check else Icons.Default.Bolt, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (isActive) "Selected" else "Use this")
                    }
                    FilledTonalButton(onClick = onChat, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                        Icon(Icons.Default.Chat, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Chat")
                    }
                }
                OutlinedButton(onClick = onTest, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.HealthAndSafety, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Test ${model.provider}")
                }
            } else {
                Button(onClick = onSetupKeys, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.Key, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Add ${model.provider} API Key")
                }
            }
        }
    }
}
