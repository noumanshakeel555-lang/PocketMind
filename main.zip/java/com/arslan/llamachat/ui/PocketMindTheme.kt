package com.arslan.llamachat.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.drawable.ColorDrawable
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

object PocketMindThemeMode {
    const val DARK = "dark"

    // Compatibility aliases only. Older saved settings/backups may contain these.
    // The release app intentionally uses the polished dark theme only.
    const val LIGHT = DARK
    const val SYSTEM = DARK
}

fun normalizeThemeMode(mode: String): String = PocketMindThemeMode.DARK

@Composable
fun PocketMindAppTheme(
    themeMode: String = PocketMindThemeMode.DARK,
    content: @Composable () -> Unit,
) {
    val colors = PocketMindDarkColors
    val view = LocalView.current

    SideEffect {
        val window = view.context.findActivity()?.window ?: return@SideEffect
        val background = colors.background.toArgb()
        window.setBackgroundDrawable(ColorDrawable(background))
        window.statusBarColor = background
        window.navigationBarColor = background
        WindowCompat.setDecorFitsSystemWindows(window, true)
        WindowCompat.getInsetsController(window, view).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(colorScheme = colors) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = colors.background,
            contentColor = colors.onBackground,
            content = content,
        )
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

private val PocketMindDarkColors = darkColorScheme(
    primary = Color(0xFFD0BCFF),
    onPrimary = Color(0xFF241547),
    primaryContainer = Color(0xFF2C2544),
    onPrimaryContainer = Color(0xFFEADDFF),

    secondary = Color(0xFF55DBC4),
    onSecondary = Color(0xFF002C25),
    secondaryContainer = Color(0xFF173D38),
    onSecondaryContainer = Color(0xFFB7F2E2),

    tertiary = Color(0xFFFFB784),
    onTertiary = Color(0xFF432000),
    tertiaryContainer = Color(0xFF503222),
    onTertiaryContainer = Color(0xFFFFDBC8),

    background = Color(0xFF101018),
    onBackground = Color(0xFFECE6F0),

    surface = Color(0xFF161622),
    onSurface = Color(0xFFECE6F0),

    surfaceVariant = Color(0xFF252437),
    onSurfaceVariant = Color(0xFFD2CBD8),

    surfaceTint = Color(0xFFD0BCFF),
    inverseSurface = Color(0xFFECE6F0),
    inverseOnSurface = Color(0xFF302D38),
    inversePrimary = Color(0xFF6750A4),

    outline = Color(0xFF9A94A4),
    outlineVariant = Color(0xFF494554),

    error = Color(0xFFFFB4AB),
    onError = Color(0xFF690005),
    errorContainer = Color(0xFF93000A),
    onErrorContainer = Color(0xFFFFDAD6),
)
