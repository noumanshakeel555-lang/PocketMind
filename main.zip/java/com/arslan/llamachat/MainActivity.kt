package com.arslan.llamachat

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.viewmodel.compose.viewModel
import com.arslan.llamachat.ui.ChatViewModel
import com.arslan.llamachat.ui.MainNavigation
import com.arslan.llamachat.ui.PocketMindAppTheme

class MainActivity : ComponentActivity() {

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val perms = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (perms.isNotEmpty()) {
            permLauncher.launch(perms.toTypedArray())
        }

        setContent {
            PocketMindAppTheme {
                val vm: ChatViewModel = viewModel()
                MainNavigation(vm = vm)
            }
        }
    }
}
