package com.arslan.llamachat.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.arslan.llamachat.image.ImageEngine
import com.arslan.llamachat.llm.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageStudioScreen(
    vm: ChatViewModel,
    modifier: Modifier = Modifier,
    onSetupKeys: () -> Unit = {},
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var prompt by remember { mutableStateOf(Prefs.getString(context, "imageGenPrompt", "")) }
    var negativePrompt by remember { mutableStateOf(Prefs.getString(context, "imageGenNegativePrompt", "blurry, low quality, distorted, watermark, text")) }
    var selectedSize by remember { mutableStateOf(Prefs.getInt(context, "imageGenSize", 512)) }
    var steps by remember { mutableStateOf(Prefs.getInt(context, "imageGenSteps", 8)) }
    var cfgScale by remember { mutableStateOf(Prefs.getFloat(context, "imageGenCfg", 2.0f)) }
    var seedText by remember { mutableStateOf(Prefs.getString(context, "imageGenSeed", "")) }

    var modelPath by remember { mutableStateOf(Prefs.getString(context, "imageGenModelPath", "")) }
    var modelName by remember { mutableStateOf(Prefs.getString(context, "imageGenModelName", "")) }
    var modelSize by remember { mutableStateOf(Prefs.getString(context, "imageGenModelSize", "")) }

    var message by remember { mutableStateOf("") }
    var isImporting by remember { mutableStateOf(false) }
    var importProgress by remember { mutableStateOf(0f) }
    var isGenerating by remember { mutableStateOf(false) }
    var generatedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var generationStartedAt by remember { mutableStateOf(0L) }
    var generationElapsedSeconds by remember { mutableStateOf(0L) }
    var generationStage by remember { mutableStateOf("") }
    var generationDetails by remember { mutableStateOf("") }

    var imageDownloadingKeys by remember { mutableStateOf<Set<String>>(emptySet()) }
    var imageDownloadProgress by remember { mutableStateOf<Map<String, Float>>(emptyMap()) }
    var imageDownloadStats by remember { mutableStateOf<Map<String, ImageDownloadStats>>(emptyMap()) }
    var installedImageModelKeys by remember { mutableStateOf(ImageModelManager.downloadedKeys(context)) }

    var imageSourceTier by remember {
        mutableStateOf(Prefs.getString(context, "imageSourceTier", ImageSourceTier.FREE_ONLINE.name))
    }
    var selectedOnlineModelKey by remember {
        mutableStateOf(
            Prefs.getString(
                context,
                "imageOnlineModelKey",
                FREE_ONLINE_IMAGE_MODELS.firstOrNull()?.key ?: ""
            )
        )
    }

    val normalizedImageSourceTier = when (imageSourceTier) {
        ImageSourceTier.OFFLINE.name -> ImageSourceTier.OFFLINE.name
        ImageSourceTier.FREE_ONLINE.name -> ImageSourceTier.FREE_ONLINE.name
        ImageSourceTier.PREMIUM_ONLINE.name -> ImageSourceTier.PREMIUM_ONLINE.name
        else -> ImageSourceTier.FREE_ONLINE.name
    }

    LaunchedEffect(normalizedImageSourceTier) {
        if (imageSourceTier != normalizedImageSourceTier) {
            imageSourceTier = normalizedImageSourceTier
            Prefs.saveString(context, "imageSourceTier", normalizedImageSourceTier)
        }
    }

    val onlineModelsForSelectedTier = when (normalizedImageSourceTier) {
        ImageSourceTier.PREMIUM_ONLINE.name -> PREMIUM_ONLINE_IMAGE_MODELS
        else -> FREE_ONLINE_IMAGE_MODELS
    }

    val selectedOnlineModel = onlineModelsForSelectedTier.firstOrNull { it.key == selectedOnlineModelKey }
        ?: onlineModelsForSelectedTier.firstOrNull()

    LaunchedEffect(normalizedImageSourceTier, selectedOnlineModelKey) {
        if (normalizedImageSourceTier != ImageSourceTier.OFFLINE.name) {
            val firstForTier = onlineModelsForSelectedTier.firstOrNull()?.key.orEmpty()
            if (firstForTier.isNotBlank() && onlineModelsForSelectedTier.none { it.key == selectedOnlineModelKey }) {
                selectedOnlineModelKey = firstForTier
                Prefs.saveString(context, "imageOnlineModelKey", firstForTier)
            }
        }
    }

    fun requiredApiKeyFor(providerKey: String): String = when (providerKey) {
        "huggingface" -> Prefs.getString(context, "hfImageApiKey", "")
        "together" -> Prefs.getString(context, "togetherImageApiKey", "")
        else -> ""
    }

    LaunchedEffect(isGenerating, generationStartedAt) {
        if (!isGenerating) {
            generationElapsedSeconds = 0L
            generationStage = ""
            return@LaunchedEffect
        }

        while (isGenerating) {
            val elapsed = ((System.currentTimeMillis() - generationStartedAt).coerceAtLeast(0L)) / 1000L
            generationElapsedSeconds = elapsed
            generationStage = when {
                elapsed < 8L -> "Preparing the image engine and checking the model…"
                elapsed < 25L -> "Loading model weights. The first run is usually the slowest."
                elapsed < 90L -> "Sampling the image. Keep the app open while this finishes."
                elapsed < 240L -> "Still working. Offline generation on phones can take several minutes."
                else -> "Taking longer than expected. For reliability, use 256×256 and 8–12 steps on phones."
            }
            delay(1000L)
        }
    }

    fun selectImageModel(path: String, name: String, size: String) {
        modelPath = path
        modelName = name
        modelSize = size
        generatedBitmap = null
        Prefs.saveString(context, "imageGenModelPath", modelPath)
        Prefs.saveString(context, "imageGenModelName", modelName)
        Prefs.saveString(context, "imageGenModelSize", modelSize)
    }


    LaunchedEffect(normalizedImageSourceTier, installedImageModelKeys) {
        if (normalizedImageSourceTier == ImageSourceTier.OFFLINE.name && modelPath.isBlank()) {
            val installedModel = IMAGE_MODELS.firstOrNull { it.key in installedImageModelKeys && it.isRecommended }
                ?: IMAGE_MODELS.firstOrNull { it.key in installedImageModelKeys }
            if (installedModel != null) {
                val file = ImageModelManager.modelFile(context, installedModel)
                if (file.exists()) {
                    selectImageModel(file.absolutePath, installedModel.displayName, formatFileSize(file.length()))
                    message = "${installedModel.displayName} selected for Offline Studio."
                }
            }
        }
    }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            isImporting = true
            importProgress = 0f
            message = "Importing image model into PocketMind storage…"
            val result = importImageModel(context, uri) { progress -> importProgress = progress }
            isImporting = false
            result.onSuccess { imported ->
                selectImageModel(imported.path, imported.name, formatFileSize(imported.bytes))
                installedImageModelKeys = ImageModelManager.downloadedKeys(context)
                message = "Model imported successfully. Offline generation is ready."
            }.onFailure { e ->
                message = "Model import failed: ${e.message ?: "Unknown error"}"
            }
        }
    }


    fun startImageModelDownload(model: ImageModelInfo) {
        if (imageDownloadingKeys.contains(model.key)) return
        imageDownloadingKeys = imageDownloadingKeys + model.key
        imageDownloadProgress = imageDownloadProgress + (model.key to 0f)
        imageDownloadStats = imageDownloadStats + (model.key to ImageDownloadStats())
        message = "Downloading ${model.displayName}. Keep the app open for large model downloads…"

        scope.launch {
            val result = ImageModelManager.download(context, model) { progress, downloaded, total, speed ->
                scope.launch {
                    imageDownloadProgress = imageDownloadProgress + (model.key to progress)
                    imageDownloadStats = imageDownloadStats + (model.key to ImageDownloadStats(progress, speed, downloaded, total))
                }
            }

            imageDownloadingKeys = imageDownloadingKeys - model.key
            imageDownloadProgress = imageDownloadProgress - model.key
            imageDownloadStats = imageDownloadStats - model.key
            installedImageModelKeys = ImageModelManager.downloadedKeys(context)

            result.onSuccess {
                val file = ImageModelManager.modelFile(context, model)
                selectImageModel(file.absolutePath, model.displayName, formatFileSize(file.length()))
                message = "${model.displayName} downloaded and selected. Offline generation is ready."
            }.onFailure { e ->
                val msg = e.message ?: "Unknown error"
                message = if (msg == "Cancelled") "Download cancelled." else "Image model download failed: $msg"
            }
        }
    }


    fun runImageGeneration(testMode: Boolean = false) {
        if (isGenerating) {
            message = "Image generation is already running. Please wait for the current job to finish."
            return
        }

        val localPath = modelPath
        if (localPath.isBlank()) {
            message = "Import or download an image model first."
            return
        }

        val modelFile = File(localPath)
        if (!modelFile.exists()) {
            message = "The selected image model file was not found. Please re-select or re-import it."
            return
        }

        val runPrompt = if (testMode) {
            val safePrompt = "a simple red apple on a wooden table, clean studio lighting"
            prompt = safePrompt
            negativePrompt = "blurry, low quality, distorted, watermark, text"
            selectedSize = 256
            steps = 8
            cfgScale = 2.0f
            seedText = "42"
            Prefs.saveString(context, "imageGenPrompt", prompt)
            Prefs.saveString(context, "imageGenNegativePrompt", negativePrompt)
            Prefs.saveInt(context, "imageGenSize", selectedSize)
            Prefs.saveInt(context, "imageGenSteps", steps)
            Prefs.saveFloat(context, "imageGenCfg", cfgScale)
            Prefs.saveString(context, "imageGenSeed", seedText)
            safePrompt
        } else {
            prompt.trim()
        }

        if (runPrompt.isBlank()) {
            message = "Write a prompt first."
            return
        }

        val isLcmModel = modelName.contains("LCM", ignoreCase = true) || localPath.contains("LCM", ignoreCase = true)
        val effectiveSize = if (testMode) 256 else selectedSize.coerceAtMost(384)
        val effectiveSteps = if (testMode) 8 else steps.coerceAtMost(if (isLcmModel) 10 else 16)
        val effectiveCfg = if (testMode) 2.0f else if (isLcmModel) cfgScale.coerceIn(1f, 3f) else cfgScale.coerceIn(1f, 12f)
        val seed = if (testMode) 42 else (seedText.toIntOrNull() ?: Random.nextInt(1, Int.MAX_VALUE))

        val safetyNote = buildString {
            if (selectedSize > effectiveSize) append(" 512×512 is heavy on phones, so this run uses ${effectiveSize}×$effectiveSize for stability.")
            if (steps > effectiveSteps) append(" Steps were limited to $effectiveSteps to avoid very long generation.")
            if (isLcmModel && cfgScale > effectiveCfg) append(" LCM models work best with CFG 1–3, so CFG was limited to ${String.format(Locale.US, "%.1f", effectiveCfg)}.")
        }.trim()

        scope.launch {
            isGenerating = true
            generatedBitmap = null
            generationStartedAt = System.currentTimeMillis()
            generationElapsedSeconds = 0L
            generationStage = "Starting image generation…"
            generationDetails = "${effectiveSize}×$effectiveSize · $effectiveSteps steps · CFG ${String.format(Locale.US, "%.1f", effectiveCfg)} · seed $seed"
            message = if (testMode) {
                "Running a safe image model test. $generationDetails"
            } else {
                "Generating image. $generationDetails${if (safetyNote.isNotBlank()) "\n$safetyNote" else ""}"
            }

            val result = ImageEngine.generateImage(
                prompt = runPrompt,
                negativePrompt = negativePrompt,
                modelPath = localPath,
                size = effectiveSize,
                steps = effectiveSteps,
                cfgScale = effectiveCfg,
                seed = seed,
            )

            result
                .onSuccess { bmp ->
                    generatedBitmap = bmp
                    message = if (testMode) {
                        "Image model test completed successfully in ${formatDurationSeconds(generationElapsedSeconds)}."
                    } else {
                        "Image generated successfully in ${formatDurationSeconds(generationElapsedSeconds)}."
                    }
                }
                .onFailure { e ->
                    val errorText = e.message ?: "Unknown error"
                    message = if (testMode) {
                        "Image model test failed: $errorText"
                    } else {
                        "Image generation failed: $errorText"
                    }
                }

            isGenerating = false
            generationStage = ""
        }
    }

    fun runOnlineImageGeneration() {
        if (isGenerating) {
            message = "Image generation is already running. Please wait for the current job to finish."
            return
        }

        val runPrompt = prompt.trim()
        if (runPrompt.isBlank()) {
            message = "Write a prompt first."
            return
        }

        val model = selectedOnlineModel
        if (model == null) {
            message = "Select an online image model first."
            return
        }

        val apiKey = requiredApiKeyFor(model.providerKey)
        if (model.requiresApiKey && apiKey.isBlank()) {
            message = "Add a ${model.providerLabel} API key from Online Models Setup, then return to Image Studio and generate again. Pollinations works without a key in Free Online mode."
            return
        }

        val safeSize = selectedSize.coerceIn(256, 1024)
        val safeSteps = steps.coerceIn(1, 12)
        val seed = seedText.toIntOrNull() ?: Random.nextInt(1, Int.MAX_VALUE)

        scope.launch {
            isGenerating = true
            generatedBitmap = null
            generationStartedAt = System.currentTimeMillis()
            generationElapsedSeconds = 0L
            generationStage = "Connecting to ${model.providerLabel}…"
            generationDetails = "${model.displayName} · ${safeSize}×$safeSize · $safeSteps steps · seed $seed"
            message = "Generating online with ${model.providerLabel}. The prompt is sent only to the selected provider for this request."

            val result = ImageEngine.generateOnlineImage(
                providerKey = model.providerKey,
                remoteModelId = model.remoteModelId,
                apiKey = apiKey,
                prompt = runPrompt,
                negativePrompt = negativePrompt,
                size = safeSize,
                steps = safeSteps,
                seed = seed,
            )

            result
                .onSuccess { bmp ->
                    generatedBitmap = bmp
                    message = "Image generated successfully with ${model.displayName} in ${formatDurationSeconds(generationElapsedSeconds)}."
                }
                .onFailure { e ->
                    generatedBitmap = null
                    message = "Online image generation failed: ${e.message ?: "Unknown error"}"
                }

            isGenerating = false
            generationStage = ""
        }
    }

    Column(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        TopAppBar(
            title = {
                Column {
                    Text("Image Studio", fontWeight = FontWeight.Bold)
                    Text(
                        "Offline, free-tier online, and premium online",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f)
                    )
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            windowInsets = pocketMindTopBarInsets()
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            ImageStudioHeroCard()

            EngineStatusCard()

            ImageSourceModeCard(
                selectedTier = normalizedImageSourceTier,
                onSelectTier = { tier ->
                    imageSourceTier = tier.name
                    Prefs.saveString(context, "imageSourceTier", tier.name)
                    generatedBitmap = null
                    message = when (tier) {
                        ImageSourceTier.OFFLINE -> "Offline Studio selected. Download one of the provided offline models below, or import your own local model."
                        ImageSourceTier.FREE_ONLINE -> "Free Online mode selected. Your prompt is sent to the selected online image provider; Pollinations works without an API key, and Hugging Face can use an access token."
                        ImageSourceTier.PREMIUM_ONLINE -> "Premium Online mode selected. Your prompt and settings are sent directly to Together AI when you generate."
                    }
                }
            )

            if (normalizedImageSourceTier == ImageSourceTier.OFFLINE.name) {
                OfflineImageStudioNotice(hasSelectedModel = modelPath.isNotBlank())

                ImageModelLibrarySection(
                    selectedModelPath = modelPath,
                    installedKeys = installedImageModelKeys,
                    downloadingKeys = imageDownloadingKeys,
                    progress = imageDownloadProgress,
                    stats = imageDownloadStats,
                    onDownload = { startImageModelDownload(it) },
                    onCancel = { ImageModelManager.cancelDownload(it.key) },
                    onSelect = { model ->
                        val file = ImageModelManager.modelFile(context, model)
                        if (file.exists()) {
                            selectImageModel(file.absolutePath, model.displayName, formatFileSize(file.length()))
                            message = "${model.displayName} selected for Offline Studio. Prompts stay on this device."
                        } else {
                            message = "This offline image model is not downloaded yet. Tap Download first."
                        }
                    },
                    onDelete = { model ->
                        ImageModelManager.delete(context, model)
                        installedImageModelKeys = ImageModelManager.downloadedKeys(context)
                        if (modelPath == ImageModelManager.modelFile(context, model).absolutePath) {
                            modelPath = ""
                            modelName = ""
                            modelSize = ""
                            generatedBitmap = null
                            Prefs.saveString(context, "imageGenModelPath", "")
                            Prefs.saveString(context, "imageGenModelName", "")
                            Prefs.saveString(context, "imageGenModelSize", "")
                        }
                        message = "${model.displayName} removed."
                    }
                )

                ImageModelCard(
                    modelName = modelName,
                    modelSize = modelSize,
                    modelPath = modelPath,
                    importing = isImporting,
                    progress = importProgress,
                    onPickModel = {
                        modelPicker.launch(
                            arrayOf(
                                "application/octet-stream",
                                "application/x-safetensors",
                                "application/x-gguf",
                                "*/*"
                            )
                        )
                    },
                    onClear = {
                        if (modelPath.isNotBlank()) runCatching { File(modelPath).delete() }
                        modelPath = ""
                        modelName = ""
                        modelSize = ""
                        generatedBitmap = null
                        Prefs.saveString(context, "imageGenModelPath", "")
                        Prefs.saveString(context, "imageGenModelName", "")
                        Prefs.saveString(context, "imageGenModelSize", "")
                        message = "Image model removed."
                    }
                )

            } else {
                OnlineImageModelsSection(
                    models = onlineModelsForSelectedTier,
                    selectedModelKey = selectedOnlineModel?.key.orEmpty(),
                    hasHuggingFaceKey = Prefs.getString(context, "hfImageApiKey", "").isNotBlank(),
                    hasTogetherKey = Prefs.getString(context, "togetherImageApiKey", "").isNotBlank(),
                    onSetupKeys = onSetupKeys,
                    onSelectModel = { model ->
                        selectedOnlineModelKey = model.key
                        Prefs.saveString(context, "imageOnlineModelKey", model.key)
                        generatedBitmap = null
                        message = "${model.displayName} selected for online image generation."
                    }
                )
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    SectionTitle(Icons.Default.Edit, "Prompt")

                    OutlinedTextField(
                        value = prompt,
                        onValueChange = {
                            prompt = it
                            Prefs.saveString(context, "imageGenPrompt", it)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Describe the image") },
                        placeholder = { Text("Example: a futuristic AI assistant glowing on a phone screen") },
                        minLines = 3,
                        shape = RoundedCornerShape(16.dp)
                    )

                    OutlinedTextField(
                        value = negativePrompt,
                        onValueChange = {
                            negativePrompt = it
                            Prefs.saveString(context, "imageGenNegativePrompt", it)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Negative prompt") },
                        minLines = 2,
                        shape = RoundedCornerShape(16.dp)
                    )
                }
            }

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    SectionTitle(Icons.Default.Tune, "Generation settings")

                    Text("Image size", fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(256, 384, 512).forEach { size ->
                            FilterChip(
                                selected = selectedSize == size,
                                onClick = {
                                    selectedSize = size
                                    Prefs.saveInt(context, "imageGenSize", size)
                                },
                                label = { Text("${size}×$size") }
                            )
                        }
                    }

                    Column {
                        Text("Steps: $steps", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Higher steps can improve quality but will be much slower on phones.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Slider(
                            value = steps.toFloat(),
                            onValueChange = {
                                steps = it.toInt()
                                Prefs.saveInt(context, "imageGenSteps", steps)
                            },
                            valueRange = 8f..30f,
                            steps = 21
                        )
                    }

                    Column {
                        Text("CFG scale: ${String.format(Locale.US, "%.1f", cfgScale)}", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Higher CFG follows the prompt more strongly.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Slider(
                            value = cfgScale,
                            onValueChange = {
                                cfgScale = it
                                Prefs.saveFloat(context, "imageGenCfg", cfgScale)
                            },
                            valueRange = 1f..14f,
                            steps = 25
                        )
                    }

                    OutlinedTextField(
                        value = seedText,
                        onValueChange = {
                            seedText = it.filter { ch -> ch.isDigit() }.take(12)
                            Prefs.saveString(context, "imageGenSeed", seedText)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        label = { Text("Seed (optional)") },
                        placeholder = { Text("Leave empty for random") },
                        singleLine = true,
                        shape = RoundedCornerShape(16.dp)
                    )
                }
            }

            if (isGenerating) {
                ImageGenerationStatusCard(
                    elapsedSeconds = generationElapsedSeconds,
                    stage = generationStage,
                    details = generationDetails,
                )
            }

            generatedBitmap?.let { bmp ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(24.dp)
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        SectionTitle(Icons.Default.Image, "Generated preview")
                        Image(
                            bitmap = bmp.asImageBitmap(),
                            contentDescription = "Generated image",
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.surface)
                        )
                        Button(
                            onClick = {
                                val saved = saveBitmapToGallery(context, bmp)
                                message = if (saved) "Image saved to gallery." else "Could not save image."
                            },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Icon(Icons.Default.SaveAlt, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Save to Gallery")
                        }
                    }
                }
            }

            if (message.isNotBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            message,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }
                }
            }

            val canGenerate = when (normalizedImageSourceTier) {
                ImageSourceTier.OFFLINE.name -> modelPath.isNotBlank() && prompt.isNotBlank() && !isImporting && !isGenerating
                else -> prompt.isNotBlank() && !isGenerating
            }

            Button(
                onClick = {
                    if (normalizedImageSourceTier == ImageSourceTier.OFFLINE.name) {
                        runImageGeneration(testMode = false)
                    } else {
                        runOnlineImageGeneration()
                    }
                },
                enabled = canGenerate,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(18.dp)
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(Modifier.width(8.dp))
                    Text("Generating…")
                } else {
                    Icon(Icons.Default.AutoAwesome, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (normalizedImageSourceTier == ImageSourceTier.OFFLINE.name) "Generate Offline" else "Generate Online")
                }
            }

            if (normalizedImageSourceTier == ImageSourceTier.OFFLINE.name) {
                OutlinedButton(
                    onClick = { runImageGeneration(testMode = true) },
                    enabled = modelPath.isNotBlank() && !isImporting && !isGenerating,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Icon(Icons.Default.HealthAndSafety, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Test Image Model")
                }
            }

            Text(
                when (normalizedImageSourceTier) {
                    ImageSourceTier.OFFLINE.name -> "Offline mode keeps generation on-device. For first tests, use 256×256 and 8–12 steps."
                    ImageSourceTier.FREE_ONLINE.name -> "Free Online mode is useful when local generation takes too long. Your prompt is sent to the selected provider; Pollinations needs no key and Hugging Face uses an access token."
                    else -> "Premium Online mode uses your API key and sends the prompt/settings directly to the selected provider."
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 24.dp)
            )
        }
    }
}

@Composable
private fun ImageStudioHeroCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(28.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(
            Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                            MaterialTheme.colorScheme.tertiary.copy(alpha = 0.10f),
                            Color.Transparent
                        )
                    )
                )
                .padding(20.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier
                        .size(58.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Image, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Create images with clear privacy controls", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Choose private offline generation, free-tier online creation, or premium provider models. Online image prompts are sent only to the selected provider.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f)
                    )
                }
            }
        }
    }
}

@Composable
private fun EngineStatusCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Memory, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Image generation engine", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Text(
                    ImageEngine.engineInfo(),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun OfflineImageStudioNotice(hasSelectedModel: Boolean) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (hasSelectedModel) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
        ),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    if (hasSelectedModel) Icons.Default.CheckCircle else Icons.Default.Download,
                    null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    if (hasSelectedModel) "Offline Studio is ready" else "Offline Studio needs a local image model",
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    if (hasSelectedModel) "The selected model will run on-device. Your image prompt will not be sent to an online provider."
                    else "Download one of the provided offline models below, or import your own .safetensors/.ckpt file.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
}

@Composable
private fun ImageModelCard(
    modelName: String,
    modelSize: String,
    modelPath: String,
    importing: Boolean,
    progress: Float,
    onPickModel: () -> Unit,
    onClear: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionTitle(Icons.Default.Memory, "Manual import / selected local model")

            if (importing) {
                Text("Importing model into app storage…", fontWeight = FontWeight.SemiBold)
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Text(
                    "${(progress * 100).toInt()}% copied. Keep the app open while importing large models.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
            } else if (modelName.isBlank()) {
                Text(
                    "No custom image model imported yet.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium
                )
                Text(
                    "This is optional. You can use the provided download cards above, or import your own .safetensors/.ckpt model here.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = onPickModel, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                    Icon(Icons.Default.FolderOpen, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Import image model")
                }
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(15.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(modelName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        if (modelSize.isNotBlank()) {
                            Text(modelSize, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            modelPath.substringAfterLast('/'),
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                            style = MaterialTheme.typography.labelSmall,
                            maxLines = 1
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onPickModel, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text("Change")
                    }
                    OutlinedButton(onClick = onClear, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text("Remove")
                    }
                }
            }
        }
    }
}

@Composable
private fun ImageGenerationStatusCard(
    elapsedSeconds: Long,
    stage: String,
    details: String,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(22.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Generating image", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "Elapsed: ${formatDurationSeconds(elapsedSeconds)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f)
                    )
                }
            }

            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

            if (stage.isNotBlank()) {
                Text(
                    stage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            if (details.isNotBlank()) {
                Text(
                    details,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f)
                )
            }

            Text(
                "Recommended starting point for phones: 256×256 with 8–12 steps. Larger settings can take several minutes.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.72f)
            )
        }
    }
}


@Composable
private fun ImageSourceModeCard(
    selectedTier: String,
    onSelectTier: (ImageSourceTier) -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        shape = RoundedCornerShape(30.dp),
        elevation = CardDefaults.cardElevation(5.dp)
    ) {
        Column(
            Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.85f),
                            MaterialTheme.colorScheme.tertiaryContainer.copy(alpha = 0.75f),
                        )
                    )
                )
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.onPrimary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Choose an image engine", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Select the workflow that fits the task: private on-device, free-tier online, or premium provider generation.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f)
                    )
                }
            }

            ModeOptionCard(
                icon = Icons.Default.PhoneAndroid,
                title = "Offline Studio",
                subtitle = "Private on-device generation",
                body = "Best for privacy. No prompt leaves the phone, but generation depends on device performance and can be slow.",
                badge = "PRIVATE",
                selected = selectedTier == ImageSourceTier.OFFLINE.name,
                accent = Color(0xFF00A67E),
                onClick = { onSelectTier(ImageSourceTier.OFFLINE) }
            )

            ModeOptionCard(
                icon = Icons.Default.Public,
                title = "Free-Tier Online Studio",
                subtitle = "Fast fallback with free options",
                body = "Use this when offline generation takes too long. Your prompt is sent to the selected online provider.",
                badge = "NO KEY OPTION",
                selected = selectedTier == ImageSourceTier.FREE_ONLINE.name,
                accent = Color(0xFF4285F4),
                onClick = { onSelectTier(ImageSourceTier.FREE_ONLINE) }
            )

            ModeOptionCard(
                icon = Icons.Default.Bolt,
                title = "Premium Online Studio",
                subtitle = "Higher speed and reliability",
                body = "Use your provider key for stronger online generation. Your prompt and generation settings are sent directly to that provider.",
                badge = "PRO",
                selected = selectedTier == ImageSourceTier.PREMIUM_ONLINE.name,
                accent = Color(0xFFB03A83),
                onClick = { onSelectTier(ImageSourceTier.PREMIUM_ONLINE) }
            )
        }
    }
}

@Composable
private fun ModeOptionCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    body: String,
    badge: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = if (selected) accent.copy(alpha = 0.16f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.72f)
        ),
        border = if (selected) BorderStroke(2.dp, accent) else null,
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(if (selected) 6.dp else 1.dp)
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(54.dp).clip(RoundedCornerShape(18.dp)).background(accent.copy(alpha = if (selected) 0.22f else 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(28.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(title, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleSmall)
                    AssistChip(onClick = {}, enabled = false, label = { Text(if (selected) "SELECTED" else badge, style = MaterialTheme.typography.labelSmall) })
                }
                Text(subtitle, fontWeight = FontWeight.SemiBold, color = accent, style = MaterialTheme.typography.bodySmall)
                Text(body, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
            Icon(if (selected) Icons.Default.CheckCircle else Icons.Default.ChevronRight, null, tint = if (selected) accent else MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun OnlineImageModelsSection(
    models: List<OnlineImageModelInfo>,
    selectedModelKey: String,
    hasHuggingFaceKey: Boolean,
    hasTogetherKey: Boolean,
    onSetupKeys: () -> Unit,
    onSelectModel: (OnlineImageModelInfo) -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionTitle(Icons.Default.CloudDownload, "Pick an online model")
            Text(
                "Large cards make the current choice obvious. Online generation sends the prompt and settings directly to the selected provider; premium providers require an API key.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            models.forEach { model ->
                OnlineImageModelCard(
                    model = model,
                    isSelected = model.key == selectedModelKey,
                    hasKey = when (model.providerKey) {
                        "huggingface" -> hasHuggingFaceKey
                        "together" -> hasTogetherKey
                        else -> true
                    },
                    onSelect = { onSelectModel(model) },
                    onSetupKeys = onSetupKeys,
                )
            }
        }
    }
}

@Composable
private fun OnlineImageModelCard(
    model: OnlineImageModelInfo,
    isSelected: Boolean,
    hasKey: Boolean,
    onSelect: () -> Unit,
    onSetupKeys: () -> Unit,
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(if (isSelected) 5.dp else 1.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Cloud, null, tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(model.displayName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        if (model.isRecommended) {
                            AssistChip(
                                onClick = {},
                                label = { Text("Recommended", style = MaterialTheme.typography.labelSmall) },
                                enabled = false
                            )
                        }
                    }
                    Text(
                        "${model.providerLabel} · ${if (model.requiresApiKey) "API key" else "No key"}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(model.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text("${model.bestSize}×${model.bestSize}") }, enabled = false)
                AssistChip(onClick = {}, label = { Text("${model.bestSteps} steps") }, enabled = false)
                AssistChip(onClick = {}, label = { Text(if (hasKey) "Ready" else "Needs key") }, enabled = false)
            }

            Text(model.note, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

            if (model.requiresApiKey && !hasKey) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onSetupKeys,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Default.Key, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Enter key")
                    }
                    if (model.apiKeyUrl.isNotBlank()) {
                        OutlinedButton(
                            onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(model.apiKeyUrl))) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(Icons.Default.OpenInBrowser, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Get key")
                        }
                    }
                }
            }

            Button(onClick = onSelect, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(if (isSelected) Icons.Default.CheckCircle else Icons.Default.PlayArrow, null, Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(if (isSelected) "Selected" else "Use this model")
            }
        }
    }
}

@Composable
private fun ImageModelLibrarySection(
    selectedModelPath: String,
    installedKeys: Set<String>,
    downloadingKeys: Set<String>,
    progress: Map<String, Float>,
    stats: Map<String, ImageDownloadStats>,
    onDownload: (ImageModelInfo) -> Unit,
    onCancel: (ImageModelInfo) -> Unit,
    onSelect: (ImageModelInfo) -> Unit,
    onDelete: (ImageModelInfo) -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(24.dp)
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionTitle(Icons.Default.CloudDownload, "Provided offline models")

            Text(
                "These are local Stable Diffusion checkpoints users can download inside the app. After download, tap Use Model and generation stays on-device.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )

            IMAGE_MODELS.forEach { model ->
                val filePath = ImageModelManager.modelFile(LocalContext.current, model).absolutePath
                ImageDownloadModelCard(
                    model = model,
                    isInstalled = model.key in installedKeys,
                    isSelected = selectedModelPath == filePath,
                    isDownloading = model.key in downloadingKeys,
                    progress = progress[model.key] ?: 0f,
                    stats = stats[model.key],
                    onDownload = { onDownload(model) },
                    onCancel = { onCancel(model) },
                    onSelect = { onSelect(model) },
                    onDelete = { onDelete(model) }
                )
            }
        }
    }
}

@Composable
private fun ImageDownloadModelCard(
    model: ImageModelInfo,
    isInstalled: Boolean,
    isSelected: Boolean,
    isDownloading: Boolean,
    progress: Float,
    stats: ImageDownloadStats?,
    onDownload: () -> Unit,
    onCancel: () -> Unit,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface
        ),
        border = if (isSelected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(if (isSelected) 5.dp else 1.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(15.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(if (isSelected) Icons.Default.CheckCircle else Icons.Default.Image, null, tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(model.displayName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                        if (isSelected) {
                            AssistChip(
                                onClick = {},
                                label = { Text("Selected", style = MaterialTheme.typography.labelSmall) },
                                enabled = false
                            )
                        } else if (model.isRecommended) {
                            AssistChip(
                                onClick = {},
                                label = { Text("Best start", style = MaterialTheme.typography.labelSmall) },
                                enabled = false
                            )
                        }
                    }
                    Text(model.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text(model.sizeDisplay) }, enabled = false)
                AssistChip(onClick = {}, label = { Text("${model.bestSize}×${model.bestSize}") }, enabled = false)
                AssistChip(onClick = {}, label = { Text("${model.bestSteps} steps") }, enabled = false)
            }

            Text(
                model.note,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (isDownloading) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("${(progress * 100).toInt()}% · ${formatImageSpeed(stats?.speedBytesPerSec ?: 0L)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold)
                        val downloaded = stats?.downloadedBytes ?: 0L
                        val total = stats?.totalBytes ?: 0L
                        if (total > 0L) {
                            Text("${formatFileSize(downloaded)} / ${formatFileSize(total)}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    TextButton(onClick = onCancel) {
                        Text("Cancel", color = MaterialTheme.colorScheme.error)
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    when {
                        !isInstalled -> Button(onClick = onDownload, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.Download, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Download")
                        }
                        isSelected -> Button(onClick = onSelect, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp), enabled = false) {
                            Icon(Icons.Default.CheckCircle, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Selected for Offline")
                        }
                        else -> Button(onClick = onSelect, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                            Icon(Icons.Default.PlayArrow, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Use Model")
                        }
                    }

                    if (isInstalled) {
                        IconButton(onClick = onDelete) {
                            Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }
        }
    }
}

private fun formatDurationSeconds(seconds: Long): String {
    val safe = seconds.coerceAtLeast(0L)
    val minutes = safe / 60L
    val rem = safe % 60L
    return if (minutes > 0L) {
        String.format(Locale.US, "%d:%02d", minutes, rem)
    } else {
        "${rem}s"
    }
}

private fun formatImageSpeed(bytesPerSec: Long): String {
    if (bytesPerSec <= 0L) return "Starting"
    return "${formatFileSize(bytesPerSec)}/s"
}

@Composable
private fun SectionTitle(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(34.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(10.dp))
        Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
    }
}

private data class ImportedImageModel(
    val path: String,
    val name: String,
    val bytes: Long,
)

private suspend fun importImageModel(
    context: Context,
    uri: Uri,
    onProgress: (Float) -> Unit,
): Result<ImportedImageModel> = withContext(Dispatchers.IO) {
    runCatching {
        val displayName = getDisplayName(context, uri).ifBlank { "image-model.safetensors" }
        val safeName = sanitizeFileName(displayName)
        val destDir = File(context.filesDir, "image_models").also { it.mkdirs() }
        val dest = File(destDir, safeName)
        val total = getSizeBytes(context, uri)

        context.contentResolver.openInputStream(uri)?.use { input ->
            dest.outputStream().use { output ->
                val buffer = ByteArray(1024 * 1024)
                var copied = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    output.write(buffer, 0, read)
                    copied += read
                    if (total > 0L) onProgress((copied.toFloat() / total).coerceIn(0f, 1f))
                }
                output.flush()
            }
        } ?: error("Could not open selected file")

        if (!dest.exists() || dest.length() <= 0L) error("Copied model file is empty")
        onProgress(1f)
        ImportedImageModel(dest.absolutePath, displayName, dest.length())
    }
}

private fun getDisplayName(context: Context, uri: Uri): String {
    return context.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && idx >= 0) c.getString(idx) ?: "" else ""
    } ?: ""
}

private fun getSizeBytes(context: Context, uri: Uri): Long {
    return context.contentResolver.query(uri, null, null, null, null)?.use { c ->
        val idx = c.getColumnIndex(OpenableColumns.SIZE)
        if (c.moveToFirst() && idx >= 0) c.getLong(idx) else -1L
    } ?: -1L
}

private fun sanitizeFileName(name: String): String = name
    .replace(Regex("[^A-Za-z0-9._-]"), "_")
    .ifBlank { "image-model.safetensors" }

private fun formatFileSize(bytes: Long): String = when {
    bytes < 1024L -> "$bytes B"
    bytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
    bytes < 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)
    else -> String.format(Locale.US, "%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
}

private fun saveBitmapToGallery(context: Context, bitmap: Bitmap): Boolean {
    return runCatching {
        val filename = "PocketMind_${System.currentTimeMillis()}.png"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, filename)
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PocketMind")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        resolver.openOutputStream(uri)?.use { output ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
        } ?: return false
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
        }
        true
    }.getOrDefault(false)
}
