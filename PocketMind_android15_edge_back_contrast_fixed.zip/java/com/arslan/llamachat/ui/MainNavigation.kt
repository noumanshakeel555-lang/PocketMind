package com.arslan.llamachat.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import com.arslan.llamachat.llm.Prefs
import kotlinx.coroutines.launch

private const val ONBOARDING_DONE_KEY = "pocketmind_onboarding_done_v5"
private const val PRIVACY_ACCEPTED_KEY = "pocketmind_privacy_policy_accepted_v1"

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainNavigation(vm: ChatViewModel) {
    val context = LocalContext.current
    val activity = context.findActivity()
    var privacyAccepted by remember {
        mutableStateOf(Prefs.getBool(context, PRIVACY_ACCEPTED_KEY, false))
    }
    var onboardingDone by remember {
        mutableStateOf(Prefs.getBool(context, ONBOARDING_DONE_KEY, false))
    }

    var chatOpen by remember { mutableStateOf(false) }
    var apiKeySetupOpen by remember { mutableStateOf(false) }
    var charactersOpen by remember { mutableStateOf(false) }
    var customModelOpen by remember { mutableStateOf(false) }
    var helpOpen by remember { mutableStateOf(false) }
    var helpdeskOpen by remember { mutableStateOf(false) }
    var setupWizardOpen by remember { mutableStateOf(false) }
    var statusOpen by remember { mutableStateOf(false) }
    var storageOpen by remember { mutableStateOf(false) }
    var backupRestoreOpen by remember { mutableStateOf(false) }
    var aboutOpen by remember { mutableStateOf(false) }
    var privacyOpen by remember { mutableStateOf(false) }
    var whatsNewOpen by remember { mutableStateOf(false) }

    var backPressCount by remember { mutableIntStateOf(0) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val pagerState = rememberPagerState(pageCount = { 5 })

    fun openPage(page: Int) {
        scope.launch {
            pagerState.animateScrollToPage(page, animationSpec = tween(300))
        }
    }

    fun goHome(saveChat: Boolean = false) {
        if (saveChat) vm.saveSession()
        apiKeySetupOpen = false
        charactersOpen = false
        customModelOpen = false
        helpOpen = false
        helpdeskOpen = false
        setupWizardOpen = false
        statusOpen = false
        storageOpen = false
        backupRestoreOpen = false
        aboutOpen = false
        privacyOpen = false
        whatsNewOpen = false
        chatOpen = false
        backPressCount = 0
        openPage(0)
    }

    fun navigateTo(target: HelpTarget) {
        when (target) {
            HelpTarget.Chat -> chatOpen = true
            HelpTarget.Models -> openPage(1)
            HelpTarget.ImageStudio -> openPage(3)
            HelpTarget.Characters -> charactersOpen = true
            HelpTarget.CustomModel -> customModelOpen = true
            HelpTarget.ApiKeys -> apiKeySetupOpen = true
            HelpTarget.Storage -> storageOpen = true
            HelpTarget.Settings -> openPage(4)
        }
    }

    if (!privacyAccepted) {
        PrivacyConsentGate(
            onAccepted = {
                Prefs.saveBool(context, PRIVACY_ACCEPTED_KEY, true)
                privacyAccepted = true
            }
        )
        return
    }

    if (!onboardingDone) {
        OnboardingScreen(
            onFinished = {
                Prefs.saveBool(context, ONBOARDING_DONE_KEY, true)
                onboardingDone = true
            }
        )
        return
    }

    when {
        apiKeySetupOpen -> {
            BackHandler { goHome() }
            ApiKeySetupScreen(
                vm = vm,
                onBack = { apiKeySetupOpen = false }
            )
            return
        }

        charactersOpen -> {
            BackHandler { goHome() }
            CharactersScreen(
                vm = vm,
                onBack = { charactersOpen = false },
                onStartChat = {
                    charactersOpen = false
                    chatOpen = true
                }
            )
            return
        }

        customModelOpen -> {
            BackHandler { goHome() }
            CustomModelScreen(
                vm = vm,
                onBack = { customModelOpen = false },
                onLoaded = {
                    customModelOpen = false
                    chatOpen = true
                }
            )
            return
        }

        helpOpen -> {
            BackHandler { goHome() }
            UseCasesScreen(
                onBack = { helpOpen = false },
                onNavigate = { target ->
                    helpOpen = false
                    navigateTo(target)
                }
            )
            return
        }

        helpdeskOpen -> {
            BackHandler { goHome() }
            HelpdeskScreen(
                vm = vm,
                onBack = { helpdeskOpen = false },
                onSetupKeys = {
                    helpdeskOpen = false
                    apiKeySetupOpen = true
                }
            )
            return
        }

        setupWizardOpen -> {
            BackHandler { goHome() }
            SetupWizardScreen(
                onBack = { setupWizardOpen = false },
                onNavigate = { target ->
                    setupWizardOpen = false
                    navigateTo(target)
                }
            )
            return
        }

        statusOpen -> {
            BackHandler { goHome() }
            AppStatusScreen(
                vm = vm,
                onBack = { statusOpen = false },
                onNavigate = { target ->
                    statusOpen = false
                    navigateTo(target)
                },
                onOpenBackupRestore = {
                    statusOpen = false
                    backupRestoreOpen = true
                }
            )
            return
        }

        storageOpen -> {
            BackHandler { goHome() }
            StorageManagerScreen(
                vm = vm,
                onBack = { storageOpen = false }
            )
            return
        }

        backupRestoreOpen -> {
            BackHandler { goHome() }
            BackupRestoreScreen(
                vm = vm,
                onBack = { backupRestoreOpen = false }
            )
            return
        }

        aboutOpen -> {
            BackHandler { goHome() }
            AboutPocketMindScreen(
                onBack = { aboutOpen = false },
                onOpenPrivacy = {
                    aboutOpen = false
                    privacyOpen = true
                },
                onOpenWhatsNew = {
                    aboutOpen = false
                    whatsNewOpen = true
                }
            )
            return
        }

        privacyOpen -> {
            BackHandler { goHome() }
            PrivacyScreen(
                onBack = { privacyOpen = false }
            )
            return
        }

        whatsNewOpen -> {
            BackHandler { goHome() }
            WhatsNewScreen(
                onBack = { whatsNewOpen = false }
            )
            return
        }

        chatOpen -> {
            BackHandler { goHome(saveChat = true) }
            ChatScreen(
                onBack = {
                    vm.saveSession()
                    chatOpen = false
                },
                vm = vm
            )
            return
        }
    }

    BackHandler {
        if (pagerState.currentPage != 0) {
            openPage(0)
            backPressCount = 0
        } else {
            backPressCount++
            if (backPressCount >= 2) {
                activity?.finish()
            } else {
                scope.launch {
                    snackbarHostState.showSnackbar("Press back again to exit")
                    backPressCount = 0
                }
            }
        }
    }

    LaunchedEffect(pagerState.currentPage) {
        backPressCount = 0
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                listOf(
                    Triple(Icons.Default.Home, "Home", 0),
                    Triple(Icons.Default.GridView, "Models", 1),
                    Triple(Icons.Default.Chat, "Chats", 2),
                    Triple(Icons.Default.Image, "Create", 3),
                    Triple(Icons.Default.Settings, "Settings", 4),
                ).forEach { (icon, label, page) ->
                    NavigationBarItem(
                        selected = pagerState.currentPage == page,
                        onClick = { openPage(page) },
                        icon = { Icon(icon, contentDescription = label) },
                        label = {
                            Text(
                                text = label,
                                fontWeight = if (pagerState.currentPage == page) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }
        }
    ) { padding ->
        HorizontalPager(
            state = pagerState,
            modifier = Modifier.padding(padding)
        ) { page ->
            when (page) {
                0 -> HomeScreen(
                    vm = vm,
                    onStartChat = { chatOpen = true },
                    onOpenModels = { openPage(1) },
                    onOpenChats = { openPage(2) },
                    onOpenImageStudio = { openPage(3) },
                    onOpenSettings = { openPage(4) },
                    onOpenCharacters = { charactersOpen = true },
                    onOpenCustomModel = { customModelOpen = true },
                    onSetupKeys = { apiKeySetupOpen = true },
                    onOpenStorage = { storageOpen = true },
                    onOpenSession = { session ->
                        vm.loadSession(session)
                        chatOpen = true
                    },
                    onRunHealthCheck = { vm.testActiveModel() },
                    onOpenHelp = { helpOpen = true },
                    onOpenHelpdesk = { helpdeskOpen = true },
                    onOpenSetupWizard = { setupWizardOpen = true },
                    onOpenStatus = { statusOpen = true },
                )

                1 -> ModelsScreen(
                    vm = vm,
                    onStartChat = { chatOpen = true },
                    onSetupKeys = { apiKeySetupOpen = true },
                    onOpenCharacters = { charactersOpen = true },
                    onOpenCustomModel = { customModelOpen = true },
                    onOpenImageStudio = { openPage(3) },
                )

                2 -> ChatsScreen(
                    vm = vm,
                    onOpenChat = { chatOpen = true }
                )

                3 -> ImageStudioScreen(
                    vm = vm,
                    onSetupKeys = { apiKeySetupOpen = true }
                )

                4 -> SettingsScreen(
                    vm = vm,
                    onSetupKeys = { apiKeySetupOpen = true },
                    onOpenCharacters = { charactersOpen = true },
                    onOpenStorage = { storageOpen = true },
                    onOpenHelp = { helpOpen = true },
                    onOpenHelpdesk = { helpdeskOpen = true },
                    onOpenSetupWizard = { setupWizardOpen = true },
                    onOpenStatus = { statusOpen = true },
                    onOpenBackupRestore = { backupRestoreOpen = true },
                    onOpenAbout = { aboutOpen = true },
                    onOpenWhatsNew = { whatsNewOpen = true },
                    onOpenPrivacy = { privacyOpen = true },
                )
            }
        }
    }
}


private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
