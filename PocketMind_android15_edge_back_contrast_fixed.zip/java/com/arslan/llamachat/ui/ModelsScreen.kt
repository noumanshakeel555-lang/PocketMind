package com.arslan.llamachat.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arslan.llamachat.llm.*
import kotlinx.coroutines.launch

private val TABS = listOf(
    "All", "General", "Coding", "Study", "Medical", "Law", "Business", "Small", "Popular", "Downloaded"
)

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ModelsScreen(
    vm: ChatViewModel,
    onStartChat: () -> Unit,
    onSetupKeys: () -> Unit,
    onOpenCharacters: () -> Unit,
    onOpenCustomModel: () -> Unit,
    onOpenImageStudio: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val state by vm.state.collectAsState()
    val spec = remember { getDeviceSpec(context) }
    val pagerState = rememberPagerState(pageCount = { TABS.size })
    val scope = rememberCoroutineScope()

    LaunchedEffect(state.downloadingKeys) {
        if (state.downloadingKeys.isEmpty()) vm.refreshDownloadedModels()
    }

    val isReady = state.loadedModel != null || state.activeOnlineProvider.isNotBlank() || state.customGgufName.isNotBlank()

    Column(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        TopAppBar(
            title = {
                Column {
                    Text("PocketMind", fontWeight = FontWeight.Bold, fontSize = 22.sp)
                    Text(
                        "Local, online and domain AI",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                    )
                }
            },
            actions = {
                FilledTonalIconButton(onClick = onOpenCharacters) {
                    Icon(Icons.Default.Person, "Characters")
                }
                FilledTonalIconButton(onClick = onOpenCustomModel) {
                    Icon(Icons.Default.FolderOpen, "Custom model")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            windowInsets = pocketMindTopBarInsets(),
        )

        state.error?.let { err ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                shape = RoundedCornerShape(16.dp),
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Error, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        err,
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                    IconButton(onClick = { vm.dismissError() }, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
        }

        ScrollableTabRow(selectedTabIndex = pagerState.currentPage, edgePadding = 12.dp) {
            TABS.forEachIndexed { i, label ->
                Tab(
                    selected = pagerState.currentPage == i,
                    onClick = { scope.launch { pagerState.animateScrollToPage(i) } },
                    text = { Text(label, fontWeight = if (pagerState.currentPage == i) FontWeight.Bold else FontWeight.Normal) },
                )
            }
        }

        HorizontalPager(state = pagerState, modifier = Modifier.fillMaxSize()) { page ->
            val tab = TABS[page]
            val filtered = remember(tab, state.bookmarkedKeys, state.downloadedKeys, state.downloadingKeys) {
                when (tab) {
                    "All" -> MODELS
                    "Popular" -> MODELS.filter { it.isPopular || it.isTrending || it.isNew }
                    "Downloaded" -> MODELS.filter { it.key in state.downloadedKeys || it.key in state.downloadingKeys }
                    else -> MODELS.filter { it.category == tab }
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
            ) {
                if (tab == "All") {
                    item {
                        FeatureHub(
                            isReady = isReady,
                            onOpenCharacters = onOpenCharacters,
                            onOpenCustomModel = onOpenCustomModel,
                            onOpenImageStudio = onOpenImageStudio,
                            onSetupKeys = onSetupKeys,
                            onStartChat = onStartChat,
                        )
                    }

                    item { DeviceCard(spec) }

                    item {
                        SectionHeader(
                            icon = Icons.Default.Bolt,
                            title = "Online AI",
                            subtitle = "Provider-hosted models using your own API keys",
                        )
                        OnlineModelsSection(
                            groqKeySet = state.groqApiKey.isNotBlank(),
                            geminiKeySet = state.geminiApiKey.isNotBlank(),
                            huggingFaceKeySet = Prefs.getString(context, "hfImageApiKey", "").isNotBlank(),
                            togetherKeySet = Prefs.getString(context, "togetherImageApiKey", "").isNotBlank(),
                            activeProvider = state.activeOnlineProvider,
                            onSelect = { vm.setOnlineProvider(it) },
                            onSetupKeys = onSetupKeys,
                            onChat = onStartChat,
                            onTest = { provider ->
                                vm.testOnlineProvider(provider)
                                onStartChat()
                            },
                        )
                    }

                    item {
                        QuickModelTools(
                            onOpenCustomModel = onOpenCustomModel,
                            onOpenImageStudio = onOpenImageStudio,
                        )
                    }

                    MODEL_CATEGORIES.forEach { category ->
                        val categoryModels = MODELS.filter { it.category == category }
                        if (categoryModels.isNotEmpty()) {
                            item {
                                DomainSectionHeader(category = category, count = categoryModels.size)
                            }
                            items(categoryModels, key = { it.key }) { model ->
                                ModelCardWithState(
                                    model = model,
                                    spec = spec,
                                    state = state,
                                    onStartChat = onStartChat,
                                    vm = vm,
                                )
                            }
                        }
                    }
                } else {
                    item { DeviceCard(spec) }
                    item {
                        DomainSectionHeader(category = tab, count = filtered.size)
                    }

                    if ((tab == "Medical" || tab == "Law") && filtered.isNotEmpty()) {
                        item { DomainSafetyCard(category = tab) }
                    }

                    if (filtered.isEmpty()) {
                        item {
                            EmptyModelsCard(tab)
                        }
                    } else {
                        items(filtered, key = { it.key }) { model ->
                            ModelCardWithState(
                                model = model,
                                spec = spec,
                                state = state,
                                onStartChat = onStartChat,
                                vm = vm,
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ModelCardWithState(
    model: ModelInfo,
    spec: DeviceSpec,
    state: ChatState,
    onStartChat: () -> Unit,
    vm: ChatViewModel,
) {
    val context = LocalContext.current
    val compat = remember(spec, model.key) { getCompatibility(spec, model) }
    val isDownloaded = model.key in state.downloadedKeys
    val isDownloading = model.key in state.downloadingKeys
    val stats = state.downloadStats[model.key]

    ModelCard(
        model = model,
        compat = compat,
        isDownloaded = isDownloaded,
        isLoaded = state.loadedModel?.key == model.key,
        isLoadingThis = state.loadingModelKey == model.key,
        isDownloading = isDownloading,
        progress = state.downloadProgress[model.key],
        downloadStats = stats,
        isBookmarked = model.key in state.bookmarkedKeys,
        onDownload = { vm.startDownload(model) },
        onCancelDownload = { vm.cancelDownload(model.key) },
        onLoad = { vm.loadModel(model) },
        onDelete = { ModelManager.delete(context, model); vm.refreshDownloadedModels() },
        onChat = onStartChat,
        onTest = {
            vm.loadAndTestModel(model)
            onStartChat()
        },
        onBookmark = { vm.toggleBookmark(model.key) },
    )
}

@Composable
private fun FeatureHub(
    isReady: Boolean,
    onOpenCharacters: () -> Unit,
    onOpenCustomModel: () -> Unit,
    onOpenImageStudio: () -> Unit,
    onSetupKeys: () -> Unit,
    onStartChat: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        elevation = CardDefaults.cardElevation(3.dp),
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            MaterialTheme.colorScheme.tertiary.copy(alpha = 0.10f),
                            Color.Transparent,
                        )
                    )
                )
                .padding(18.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.onPrimary)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Model library", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Choose by purpose: coding, study, medicine, law, business, or compact offline chat.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f),
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                QuickActionCard(Icons.Default.Code, "Coding", "Developer models", onOpenCustomModel, Modifier.weight(1f))
                QuickActionCard(Icons.Default.School, "Study", "Math & exams", onStartChat, Modifier.weight(1f), enabled = isReady)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                QuickActionCard(Icons.Default.Image, "Image Studio", "Offline + online", onOpenImageStudio, Modifier.weight(1f))
                QuickActionCard(Icons.Default.Key, "API Keys", "Cloud models", onSetupKeys, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                QuickActionCard(Icons.Default.Person, "Characters", "AI personalities", onOpenCharacters, Modifier.weight(1f))
                QuickActionCard(Icons.Default.FolderOpen, "Custom GGUF", "Import a model", onOpenCustomModel, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun QuickModelTools(
    onOpenCustomModel: () -> Unit,
    onOpenImageStudio: () -> Unit,
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
            shape = RoundedCornerShape(22.dp),
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Default.FolderOpen, null, tint = MaterialTheme.colorScheme.secondary)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Import custom GGUF", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Load specialized models from phone storage.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.78f),
                    )
                }
                FilledTonalButton(onClick = onOpenCustomModel, shape = RoundedCornerShape(14.dp)) { Text("Open") }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
            shape = RoundedCornerShape(22.dp),
        ) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.tertiary.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Default.Image, null, tint = MaterialTheme.colorScheme.tertiary)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Image Studio", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text(
                        "Create visuals with offline on-device or online provider modes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onTertiaryContainer.copy(alpha = 0.78f),
                    )
                }
                FilledTonalButton(onClick = onOpenImageStudio, shape = RoundedCornerShape(14.dp)) { Text("Open") }
            }
        }
    }
}

@Composable
private fun QuickActionCard(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier.defaultMinSize(minHeight = 76.dp),
        shape = RoundedCornerShape(18.dp),
        contentPadding = PaddingValues(10.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface,
            disabledContainerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.55f),
            disabledContentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f),
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, modifier = Modifier.size(22.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(4.dp))
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, maxLines = 1, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun DomainSectionHeader(category: String, count: Int) {
    val meta = categoryMeta(category)
    SectionHeader(
        icon = meta.icon,
        title = meta.title,
        subtitle = "${meta.subtitle} · $count models",
    )
}

@Composable
private fun SectionHeader(icon: ImageVector, title: String, subtitle: String) {
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(34.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    Spacer(Modifier.height(8.dp))
}

private data class CategoryMeta(val title: String, val subtitle: String, val icon: ImageVector)

private fun categoryMeta(category: String): CategoryMeta = when (category) {
    "General" -> CategoryMeta("General AI", "Balanced assistants for everyday work", Icons.Default.AutoAwesome)
    "Coding" -> CategoryMeta("Coding", "Code, debugging, APIs, and software engineering", Icons.Default.Code)
    "Study" -> CategoryMeta("Math & Study", "Math, reasoning, exams, and academic learning", Icons.Default.School)
    "Medical" -> CategoryMeta("Medicine", "Biomedical learning and literature support", Icons.Default.LocalHospital)
    "Law" -> CategoryMeta("Law", "Legal text explanation and document study", Icons.Default.Gavel)
    "Business" -> CategoryMeta("Business", "Emails, proposals, strategy, and productivity", Icons.Default.BusinessCenter)
    "Small" -> CategoryMeta("Small/Test Models", "Fast downloads and low-RAM testing", Icons.Default.Speed)
    "Large" -> CategoryMeta("Large Models", "Best quality for stronger devices", Icons.Default.Memory)
    "Popular" -> CategoryMeta("Popular & Trending", "Recommended models across categories", Icons.Default.TrendingUp)
    "Downloaded" -> CategoryMeta("Downloaded", "Models already available on this device", Icons.Default.DownloadDone)
    else -> CategoryMeta(category, "Specialized local models", Icons.Default.Memory)
}

@Composable
private fun DomainSafetyCard(category: String) {
    val text = when (category) {
        "Medical" -> "Medical models are for study, literature review, and terminology support only. They must not replace a qualified clinician, diagnosis, or emergency care."
        "Law" -> "Law models are for learning, summaries, and document understanding only. They must not replace a licensed lawyer or jurisdiction-specific legal advice."
        else -> "Specialized models can make mistakes. Verify important information before relying on it."
    }
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.65f)),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.HealthAndSafety, null, tint = MaterialTheme.colorScheme.error)
            Spacer(Modifier.width(10.dp))
            Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
        }
    }
}

@Composable
private fun EmptyModelsCard(tab: String) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(20.dp),
    ) {
        Column(Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Info, null, modifier = Modifier.size(38.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f))
            Spacer(Modifier.height(10.dp))
            Text("No $tab models found", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun DeviceCard(spec: DeviceSpec) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(24.dp),
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Default.Memory, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(10.dp))
                Column {
                    Text("Device profile", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text("Compatibility is based on currently available memory.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DeviceStatBox("Total RAM", "${spec.totalRamMb / 1024} GB", Modifier.weight(1f))
                DeviceStatBox("Free RAM", "${spec.freeRamMb / 1024} GB", Modifier.weight(1f))
                DeviceStatBox("CPU", spec.abi.replace("arm64-v8a", "ARM64").replace("armeabi-v7a", "ARM32"), Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun DeviceStatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface).padding(10.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(4.dp))
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ModelCard(
    model: ModelInfo, compat: Compatibility,
    isDownloaded: Boolean, isLoaded: Boolean,
    isLoadingThis: Boolean, isDownloading: Boolean,
    progress: Float?, downloadStats: DownloadStats?,
    isBookmarked: Boolean,
    onDownload: () -> Unit, onCancelDownload: () -> Unit,
    onLoad: () -> Unit, onDelete: () -> Unit,
    onChat: () -> Unit, onTest: () -> Unit, onBookmark: () -> Unit,
) {
    val compatColor = when (compat) {
        Compatibility.GREAT -> Color(0xFF4CAF50)
        Compatibility.OK -> Color(0xFF8BC34A)
        Compatibility.TIGHT -> Color(0xFFFFD54F)
        Compatibility.TOO_LARGE -> Color(0xFFF44336)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = if (isLoaded) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(2.dp),
    ) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(categoryMeta(model.category).icon, null, tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(model.displayName, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        if (model.isNew) Badge(containerColor = Color(0xFF7B61FF)) {
                            Text("NEW", modifier = Modifier.padding(horizontal = 6.dp), style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(model.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onBookmark) {
                    Icon(
                        if (isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        null,
                        tint = if (isBookmarked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                InfoChip(model.sizeDisplay, MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.onSurface)
                InfoChip(model.category, MaterialTheme.colorScheme.surface, MaterialTheme.colorScheme.onSurface)
                InfoChip(
                    compatibilityLabel(compat),
                    bg = if (compat == Compatibility.TIGHT) Color(0xFF4A3500) else compatColor.copy(alpha = 0.18f),
                    fg = if (compat == Compatibility.TIGHT) Color(0xFFFFF3D0) else compatColor,
                )
                if (isLoaded) Badge(containerColor = MaterialTheme.colorScheme.primary) {
                    Text("Active", modifier = Modifier.padding(horizontal = 6.dp))
                }
            }

            CapabilityBadges(
                labels = domainModelCapabilityLabels(model.category),
                modifier = Modifier.padding(top = 10.dp),
                compact = true,
            )

            if (model.category == "Medical" || model.category == "Law") {
                Spacer(Modifier.height(8.dp))
                Text(
                    if (model.category == "Medical") "Educational support only — not a medical diagnosis tool."
                    else "Educational support only — not legal advice.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            if (compat == Compatibility.TOO_LARGE) {
                Spacer(Modifier.height(6.dp))
                Text(
                    "Needs ${model.ramNeededMb / 1024}+ GB free RAM — enable Low RAM Mode or choose a smaller model.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            Spacer(Modifier.height(16.dp))

            if (isDownloading && progress != null) {
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        val speed = downloadStats?.let { formatSpeed(it.speedBytesPerSec) } ?: ""
                        val dl = downloadStats?.downloadedBytes?.let { formatBytes(it) } ?: ""
                        val tot = downloadStats?.totalBytes?.let { formatBytes(it) } ?: ""
                        Text(
                            "${(progress * 100).toInt()}%${if (speed.isNotBlank()) "  ·  $speed" else ""}",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        if (dl.isNotBlank()) Text(
                            "$dl / $tot  ·  safe to lock screen",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    TextButton(onClick = onCancelDownload) {
                        Text("Cancel", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    when {
                        !isDownloaded -> Button(
                            onClick = onDownload,
                            modifier = Modifier.weight(1f),
                            enabled = compat != Compatibility.TOO_LARGE,
                            shape = RoundedCornerShape(16.dp),
                        ) {
                            Icon(Icons.Default.Download, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Download  ${model.sizeDisplay}")
                        }
                        !isLoaded -> {
                            Button(
                                onClick = onLoad,
                                modifier = Modifier.weight(1f),
                                enabled = !isLoadingThis,
                                shape = RoundedCornerShape(16.dp),
                            ) {
                                if (isLoadingThis) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                else Icon(Icons.Default.PlayArrow, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(if (isLoadingThis) "Loading…" else "Load Model")
                            }
                            FilledTonalButton(
                                onClick = onTest,
                                modifier = Modifier.weight(1f),
                                enabled = !isLoadingThis,
                                shape = RoundedCornerShape(16.dp),
                            ) {
                                Icon(Icons.Default.HealthAndSafety, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Test")
                            }
                            IconButton(onClick = onDelete, enabled = !isLoadingThis) {
                                Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
                            }
                        }
                        else -> {
                            Button(onClick = onChat, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                                Icon(Icons.Default.Chat, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Chat Now")
                            }
                            FilledTonalButton(onClick = onTest, modifier = Modifier.weight(1f), shape = RoundedCornerShape(16.dp)) {
                                Icon(Icons.Default.HealthAndSafety, null, Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Test")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoChip(text: String, bg: Color, fg: Color) {
    Box(Modifier.clip(RoundedCornerShape(10.dp)).background(bg).padding(horizontal = 10.dp, vertical = 6.dp)) {
        Text(text, style = MaterialTheme.typography.bodySmall, color = fg, fontWeight = FontWeight.SemiBold)
    }
}

fun formatBytes(bytes: Long): String = when {
    bytes < 1024 * 1024 -> "${"%.1f".format(bytes / 1024.0)} KB"
    bytes < 1024 * 1024 * 1024 -> "${"%.1f".format(bytes / 1024.0 / 1024.0)} MB"
    else -> "${"%.2f".format(bytes / 1024.0 / 1024.0 / 1024.0)} GB"
}
