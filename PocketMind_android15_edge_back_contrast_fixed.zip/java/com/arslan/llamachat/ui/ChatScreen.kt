package com.arslan.llamachat.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import com.arslan.llamachat.llm.CharacterManager
import com.arslan.llamachat.voice.VoiceInput
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(onBack: () -> Unit, vm: ChatViewModel) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var inputText by remember { mutableStateOf("") }
    var isListening by remember { mutableStateOf(false) }
    var showMenu by remember { mutableStateOf(false) }
    var showModelSettings by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val voiceInput = remember { VoiceInput(context) }
    val scope = rememberCoroutineScope()
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let { vm.attachFile(context, it) }
    }

    val allChars = remember(state.customCharacters) { CharacterManager.allCharacters(context) }
    val activeChar = allChars.find { it.id == state.activeCharacterId }

    val totalItems = state.messages.size +
        (if (state.streamingText.isNotEmpty()) 1 else 0) +
        (if (state.isThinking) 1 else 0)

    val showScrollButton by remember {
        derivedStateOf {
            val last = listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last < totalItems - 2
        }
    }

    LaunchedEffect(totalItems) {
        if (!showScrollButton) listState.animateScrollToItem(maxOf(0, totalItems))
    }

    DisposableEffect(Unit) { onDispose { voiceInput.stop() } }

    if (showModelSettings) {
        ModelSettingsSheet(vm = vm, onDismiss = { showModelSettings = false })
    }

    val modelTitle = when {
        state.activeOnlineProvider == "groq"   -> "Llama 3.1 70B"
        state.activeOnlineProvider == "gemini" -> "Gemini 1.5 Flash"
        state.customGgufName.isNotBlank()      -> state.customGgufName.take(20)
        else -> state.loadedModel?.displayName ?: "PocketMind"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (activeChar != null) {
                            Box(Modifier.size(32.dp).clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(0.15f)),
                                contentAlignment = Alignment.Center) {
                                Text(activeChar.avatarEmoji, fontSize = 16.sp)
                            }
                            Spacer(Modifier.width(8.dp))
                        }
                        TextButton(onClick = { showModelSettings = true },
                            contentPadding = PaddingValues(0.dp)) {
                            Column {
                                Text(activeChar?.name ?: modelTitle,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    style = MaterialTheme.typography.titleMedium)
                                Text("Tap to adjust settings",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = { vm.saveSession(); onBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    if (state.isSpeaking) {
                        IconButton(onClick = { vm.stopVoiceReply() }) {
                            Icon(Icons.Default.StopCircle, "Stop voice reply", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                    IconButton(onClick = { vm.toggleTts() }) {
                        Icon(
                            if (state.ttsEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            "TTS",
                            tint = if (state.ttsEnabled) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { showMenu = true }) {
                        Icon(Icons.Default.MoreVert, "Menu")
                    }
                    DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                        DropdownMenuItem(text = { Text("New chat") },
                            leadingIcon = { Icon(Icons.Default.Add, null) },
                            onClick = { vm.newChat(); showMenu = false })
                        DropdownMenuItem(text = { Text("Default persona") },
                            onClick = { vm.setPersona(false); showMenu = false })
                        HorizontalDivider()
                        DropdownMenuItem(text = { Text("Save chat") },
                            leadingIcon = { Icon(Icons.Default.Save, null) },
                            onClick = { vm.saveSession(); showMenu = false })
                        DropdownMenuItem(text = { Text("Clear chat") },
                            leadingIcon = { Icon(Icons.Default.DeleteSweep, null) },
                            onClick = { vm.clearHistory(); showMenu = false })
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = pocketMindTopBarInsets(extraTopPadding = 8.dp)
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Column {
                    if (state.error != null) {
                        Row(modifier = Modifier.fillMaxWidth()
                            .background(MaterialTheme.colorScheme.errorContainer)
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(state.error!!, Modifier.weight(1f),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onErrorContainer)
                            IconButton(onClick = { vm.dismissError() }, modifier = Modifier.size(24.dp)) {
                                Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp),
                                    tint = MaterialTheme.colorScheme.onErrorContainer)
                            }
                        }
                    }

                    state.currentAttachment?.let { attachment ->
                        AttachmentPreviewCard(
                            attachment = attachment,
                            onClear = { vm.clearAttachment() },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }

                    if (state.isReadingAttachment) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Reading attachment…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Row(modifier = Modifier.fillMaxWidth().padding(8.dp)
                        .navigationBarsPadding().imePadding(),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        IconButton(
                            onClick = { filePicker.launch(arrayOf("image/*", "application/pdf", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "text/*", "application/json", "application/xml", "*/*")) },
                            enabled = !state.isGenerating && !state.isThinking && !state.isReadingAttachment,
                            colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                        ) {
                            Icon(Icons.Default.AttachFile, "Attach file", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(
                            onClick = {
                                if (isListening) { voiceInput.stop(); isListening = false }
                                else {
                                    isListening = true
                                    voiceInput.start(
                                        onResult = { inputText = it; isListening = false },
                                        onError = { isListening = false })
                                }
                            },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = if (isListening) MaterialTheme.colorScheme.errorContainer
                                else MaterialTheme.colorScheme.surfaceVariant)) {
                            Icon(if (isListening) Icons.Default.MicOff else Icons.Default.Mic, "Voice",
                                tint = if (isListening) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        OutlinedTextField(value = inputText, onValueChange = { inputText = it },
                            modifier = Modifier.weight(1f),
                            placeholder = { Text(if (isListening) "Listening…" else "Message…") },
                            maxLines = 4, shape = RoundedCornerShape(24.dp))
                        if (state.isGenerating || state.isThinking) {
                            IconButton(onClick = { vm.stopGeneration() },
                                colors = IconButtonDefaults.iconButtonColors(
                                    containerColor = MaterialTheme.colorScheme.errorContainer)) {
                                Icon(Icons.Default.Stop, "Stop", tint = MaterialTheme.colorScheme.error)
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    if (inputText.isNotBlank() || state.currentAttachment != null) {
                                        vm.send(inputText.trim())
                                        inputText = ""
                                    }
                                },
                                enabled = (inputText.isNotBlank() || state.currentAttachment != null) &&
                                    !state.isReadingAttachment &&
                                    (state.loadedModel != null ||
                                    state.activeOnlineProvider.isNotBlank() ||
                                    state.customGgufName.isNotBlank()),
                                colors = IconButtonDefaults.iconButtonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                Icon(Icons.AutoMirrored.Filled.Send, "Send",
                                    tint = MaterialTheme.colorScheme.onPrimary)
                            }
                        }
                    }
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            LazyColumn(state = listState,
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 12.dp)) {

                if (state.messages.isEmpty() && !state.isGenerating && !state.isThinking) {
                    item {
                        Box(Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                if (activeChar != null) {
                                    Text(activeChar.avatarEmoji, fontSize = 52.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text(activeChar.name, style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface)
                                    Spacer(Modifier.height(4.dp))
                                    Text(activeChar.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                } else {
                                    Icon(Icons.Default.Chat, null, modifier = Modifier.size(56.dp),
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.25f))
                                    Spacer(Modifier.height(16.dp))
                                    Text("Start a conversation",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                val noModel = state.loadedModel == null &&
                                    state.activeOnlineProvider.isBlank() &&
                                    state.customGgufName.isBlank()
                                if (noModel) {
                                    Spacer(Modifier.height(8.dp))
                                    Text("No model loaded — go back and load one",
                                        color = MaterialTheme.colorScheme.error,
                                        style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }

                items(state.messages, key = { it.id }) { msg ->
                    val msgChar = allChars.find { it.id == msg.characterId }
                    Bubble(msg = msg, character = msgChar,
                        onCopy = {
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("PocketMind", msg.content))
                        },
                        onShare = {
                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"; putExtra(Intent.EXTRA_TEXT, msg.content)
                            }
                            context.startActivity(Intent.createChooser(intent, "Share via"))
                        },
                        onResend = if (msg.role == "user") ({ vm.resend(msg) }) else null
                    )
                }

                if (state.streamingText.isNotEmpty()) {
                    item {
                        Bubble(msg = Message(role = "assistant", content = state.streamingText,
                            characterId = state.activeCharacterId),
                            character = activeChar, streaming = true,
                            onCopy = {}, onShare = {}, onResend = null)
                    }
                }

                if (state.isThinking) {
                    item {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (activeChar != null) {
                                Text(activeChar.avatarEmoji, fontSize = 18.sp)
                                Spacer(Modifier.width(8.dp))
                            }
                            CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("${activeChar?.name ?: "Assistant"} is thinking…",
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            AnimatedVisibility(visible = showScrollButton,
                enter = fadeIn() + scaleIn(), exit = fadeOut() + scaleOut(),
                modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
                FloatingActionButton(
                    onClick = { scope.launch { listState.animateScrollToItem(totalItems) } },
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(40.dp)) {
                    Icon(Icons.Default.KeyboardArrowDown, "Scroll to bottom",
                        modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

@Composable
private fun AttachmentPreviewCard(
    attachment: ChatAttachment,
    onClear: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(18.dp),
        tonalElevation = 2.dp
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            val icon = when {
                attachment.isImage -> Icons.Default.Image
                attachment.mimeType.contains("pdf", ignoreCase = true) -> Icons.Default.PictureAsPdf
                attachment.mimeType.contains("word", ignoreCase = true) || attachment.name.endsWith(".docx", ignoreCase = true) -> Icons.Default.Description
                else -> Icons.Default.InsertDriveFile
            }
            Box(
                Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary.copy(0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(attachment.name, maxLines = 1, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                val detail = buildString {
                    append(if (attachment.isImage) "Image attached" else "File attached")
                    if (attachment.textPreview.isNotBlank()) append(" · text extracted")
                    if (attachment.warning.isNotBlank()) append(" · ${attachment.warning.take(80)}")
                }
                Text(detail, maxLines = 2, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onClear, modifier = Modifier.size(34.dp)) {
                Icon(Icons.Default.Close, "Remove attachment", modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun Bubble(
    msg: Message, character: com.arslan.llamachat.llm.Character? = null,
    streaming: Boolean = false,
    onCopy: () -> Unit, onShare: () -> Unit, onResend: (() -> Unit)?,
) {
    val isUser = msg.role == "user"
    var showActions by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start) {

        if (!isUser && character != null) {
            Row(verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)) {
                Box(Modifier.size(22.dp).clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(0.12f)),
                    contentAlignment = Alignment.Center) {
                    androidx.compose.material3.Text(character.avatarEmoji, fontSize = 12.sp)
                }
                Spacer(Modifier.width(4.dp))
                Text(character.name, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = FontWeight.SemiBold)
            }
        }

        Box(modifier = Modifier
            .widthIn(max = if (isUser) 320.dp else 360.dp)
            .clip(RoundedCornerShape(
                topStart = 16.dp, topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp))
            .background(if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant)
            .pointerInput(Unit) { detectTapGestures(onLongPress = { showActions = !showActions }) }
            .padding(12.dp)) {
            MarkdownMessageContent(
                text = cleanVisibleMessageText(msg.content) + if (streaming) "▌" else "",
                isUser = isUser
            )
        }

        AnimatedVisibility(visible = showActions) {
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.padding(top = 4.dp)) {
                SmallIconButton(Icons.Default.ContentCopy, "Copy") { onCopy(); showActions = false }
                SmallIconButton(Icons.Default.Share, "Share") { onShare(); showActions = false }
                if (onResend != null) {
                    SmallIconButton(Icons.Default.Refresh, "Re-ask") { onResend(); showActions = false }
                }
            }
        }
    }
}


private fun cleanVisibleMessageText(text: String): String {
    val extractedMarker = "\n\nFile content extracted for the model:\n```"
    val markerIndex = text.indexOf(extractedMarker)
    if (markerIndex < 0) return text

    val header = text.take(markerIndex).trim()
    val note = text.substring(markerIndex)
        .substringAfter("```", "")
        .substringAfter("```", "")
        .trim()
    return buildString {
        append(header)
        append("\n\n📎 Attached file content was included privately for the model.")
        if (note.isNotBlank()) append("\n\n").append(note)
    }.trim()
}

@Composable
private fun MarkdownMessageContent(text: String, isUser: Boolean) {
    val defaultColor = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
    val strongColor = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    val headingColor = if (isUser) MaterialTheme.colorScheme.onPrimary else Color(0xFF8AD7FF)
    val subHeadingColor = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.92f) else Color(0xFFA7F3D0)
    val listAccentColor = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.95f) else Color(0xFFF5C842)
    val listHeadingColor = if (isUser) MaterialTheme.colorScheme.onPrimary else Color(0xFFE9D5FF)
    val codeBg = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.12f) else Color(0xFF07111F)
    val codeHeaderBg = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.10f) else Color(0xFF0B1B31)
    val codeBorder = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.24f) else Color(0xFF2D7DBD).copy(alpha = 0.55f)
    val codeText = if (isUser) MaterialTheme.colorScheme.onPrimary else Color(0xFFEAF6FF)
    val inlineCodeBg = if (isUser) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.10f) else Color(0xFF11243A)
    val context = LocalContext.current

    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            parseMarkdownBlocks(text).forEach { block ->
                when (block) {
                    is MarkdownBlock.Heading -> {
                        val accent = when (block.level) {
                            1 -> headingColor
                            2 -> subHeadingColor
                            else -> listHeadingColor
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = if (block.level == 1) 4.dp else 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(if (block.level == 1) 4.dp else 3.dp)
                                    .height(if (block.level == 1) 26.dp else 20.dp)
                                    .clip(RoundedCornerShape(999.dp))
                                    .background(accent.copy(alpha = 0.95f))
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(
                                text = stripInlineMarkdown(block.text),
                                color = accent,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = when (block.level) { 1 -> 22.sp; 2 -> 19.sp; else -> 16.sp },
                                lineHeight = when (block.level) { 1 -> 28.sp; 2 -> 24.sp; else -> 21.sp },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    is MarkdownBlock.Code -> Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 2.dp, bottom = 2.dp),
                        color = codeBg,
                        shape = RoundedCornerShape(18.dp),
                        border = BorderStroke(1.dp, codeBorder),
                        tonalElevation = 2.dp,
                        shadowElevation = 4.dp
                    ) {
                        Column(Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(codeHeaderBg)
                                    .padding(start = 14.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFFFF5F57)))
                                    Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFFFFBD2E)))
                                    Box(Modifier.size(7.dp).clip(CircleShape).background(Color(0xFF28C840)))
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    text = block.language.ifBlank { "code" }.uppercase(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = headingColor.copy(alpha = 0.9f),
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.weight(1f),
                                )
                                TextButton(
                                    onClick = {
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        cm.setPrimaryClip(ClipData.newPlainText("PocketMind code", block.code))
                                    },
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                    colors = ButtonDefaults.textButtonColors(contentColor = headingColor)
                                ) { Text("Copy", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            }
                            Text(
                                text = block.code,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 14.dp),
                                color = codeText,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.5.sp,
                                lineHeight = 19.sp,
                            )
                        }
                    }

                    is MarkdownBlock.ListBlock -> Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        block.items.forEachIndexed { index, item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.Top
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(999.dp),
                                    color = listAccentColor.copy(alpha = if (isUser) 0.16f else 0.13f),
                                    border = BorderStroke(1.dp, listAccentColor.copy(alpha = 0.45f)),
                                    modifier = Modifier.padding(top = 1.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(if (block.ordered) 30.dp else 22.dp)
                                            .height(22.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (block.ordered) "${index + 1}" else "•",
                                            color = listAccentColor,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = if (block.ordered) 11.sp else 15.sp,
                                            lineHeight = 18.sp
                                        )
                                    }
                                }
                                Spacer(Modifier.width(9.dp))
                                Text(
                                    text = inlineMarkdown(
                                        text = item,
                                        strongColor = listHeadingColor,
                                        inlineCodeColor = headingColor,
                                        inlineCodeBg = inlineCodeBg
                                    ),
                                    color = defaultColor,
                                    style = MaterialTheme.typography.bodyMedium,
                                    lineHeight = 21.sp,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }

                    is MarkdownBlock.Paragraph -> Text(
                        text = inlineMarkdown(
                            text = block.text,
                            strongColor = strongColor,
                            inlineCodeColor = headingColor,
                            inlineCodeBg = inlineCodeBg
                        ),
                        color = defaultColor,
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 21.sp,
                    )
                }
            }
        }
    }
}

private sealed class MarkdownBlock {
    data class Heading(val level: Int, val text: String) : MarkdownBlock()
    data class Paragraph(val text: String) : MarkdownBlock()
    data class ListBlock(val ordered: Boolean, val items: List<String>) : MarkdownBlock()
    data class Code(val language: String, val code: String) : MarkdownBlock()
}

private fun parseMarkdownBlocks(input: String): List<MarkdownBlock> {
    val blocks = mutableListOf<MarkdownBlock>()
    val lines = input.replace("\r\n", "\n").lines()
    val paragraph = mutableListOf<String>()
    val bulletItems = mutableListOf<String>()
    val orderedItems = mutableListOf<String>()

    fun flushParagraph() {
        if (paragraph.isNotEmpty()) {
            blocks += MarkdownBlock.Paragraph(paragraph.joinToString("\n").trim())
            paragraph.clear()
        }
    }
    fun flushBullets() {
        if (bulletItems.isNotEmpty()) {
            blocks += MarkdownBlock.ListBlock(ordered = false, items = bulletItems.toList())
            bulletItems.clear()
        }
    }
    fun flushOrdered() {
        if (orderedItems.isNotEmpty()) {
            blocks += MarkdownBlock.ListBlock(ordered = true, items = orderedItems.toList())
            orderedItems.clear()
        }
    }
    fun flushLists() {
        flushBullets()
        flushOrdered()
    }

    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        val trimmed = line.trim()

        when {
            trimmed.startsWith("```") || trimmed.startsWith("~~~") -> {
                flushParagraph(); flushLists()
                val fence = trimmed.take(3)
                val language = trimmed.drop(3).trim()
                val codeLines = mutableListOf<String>()
                i++
                while (i < lines.size && !lines[i].trim().startsWith(fence)) {
                    codeLines += lines[i]
                    i++
                }
                blocks += MarkdownBlock.Code(language, codeLines.joinToString("\n").trimEnd())
            }
            trimmed.isBlank() -> {
                flushParagraph(); flushLists()
            }
            isMarkdownHeading(trimmed) -> {
                flushParagraph(); flushLists()
                val level = trimmed.takeWhile { it == '#' }.length.coerceIn(1, 3)
                blocks += MarkdownBlock.Heading(level, trimmed.drop(level).trim())
            }
            isStrongStandaloneHeading(trimmed) -> {
                flushParagraph(); flushLists()
                blocks += MarkdownBlock.Heading(3, trimmed.trim('*', ' ', ':'))
            }
            isBulletLine(trimmed) -> {
                flushParagraph(); flushOrdered()
                bulletItems += trimmed.replace(Regex("^[-*•]\\s+"), "").trim()
            }
            isOrderedLine(trimmed) -> {
                flushParagraph(); flushBullets()
                orderedItems += trimmed.replace(Regex("^\\d+[.)]\\s+"), "").trim()
            }
            else -> {
                flushLists()
                paragraph += line.trimEnd()
            }
        }
        i++
    }

    flushParagraph(); flushLists()
    return blocks.ifEmpty { listOf(MarkdownBlock.Paragraph(input)) }
}

private fun isMarkdownHeading(trimmed: String): Boolean {
    val level = trimmed.takeWhile { it == '#' }.length
    return level in 1..6 && trimmed.drop(level).let { it.startsWith(" ") || it.isNotBlank() }
}

private fun isStrongStandaloneHeading(trimmed: String): Boolean {
    if (!trimmed.startsWith("**")) return false
    val without = trimmed.removePrefix("**")
    val end = without.indexOf("**")
    if (end <= 0) return false
    val remainder = without.drop(end + 2).trim()
    return remainder.isBlank() || remainder == ":"
}

private fun isBulletLine(trimmed: String): Boolean = Regex("^[-*•]\\s+.+").matches(trimmed)

private fun isOrderedLine(trimmed: String): Boolean = Regex("^\\d+[.)]\\s+.+").matches(trimmed)

private fun stripInlineMarkdown(text: String): String = text
    .replace(Regex("`([^`]+)`"), "$1")
    .replace(Regex("\\*\\*([^*]+)\\*\\*"), "$1")
    .replace(Regex("__([^_]+)__"), "$1")
    .trim()

private fun inlineMarkdown(
    text: String,
    strongColor: androidx.compose.ui.graphics.Color,
    inlineCodeColor: androidx.compose.ui.graphics.Color = strongColor,
    inlineCodeBg: androidx.compose.ui.graphics.Color = androidx.compose.ui.graphics.Color.Transparent
): AnnotatedString {
    return buildAnnotatedString {
        var i = 0
        while (i < text.length) {
            when {
                text.startsWith("**", i) -> {
                    val end = text.indexOf("**", startIndex = i + 2)
                    if (end > i) {
                        withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold, color = strongColor)) {
                            append(text.substring(i + 2, end))
                        }
                        i = end + 2
                    } else {
                        append(text[i]); i++
                    }
                }
                text.startsWith("__", i) -> {
                    val end = text.indexOf("__", startIndex = i + 2)
                    if (end > i) {
                        withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold, color = strongColor)) {
                            append(text.substring(i + 2, end))
                        }
                        i = end + 2
                    } else {
                        append(text[i]); i++
                    }
                }
                text[i] == '`' -> {
                    val end = text.indexOf('`', startIndex = i + 1)
                    if (end > i) {
                        withStyle(
                            SpanStyle(
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                color = inlineCodeColor,
                                background = inlineCodeBg
                            )
                        ) {
                            append(" ")
                            append(text.substring(i + 1, end))
                            append(" ")
                        }
                        i = end + 1
                    } else {
                        append(text[i]); i++
                    }
                }
                else -> {
                    append(text[i])
                    i++
                }
            }
        }
    }
}

@Composable
fun SmallIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(32.dp),
        colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Icon(icon, label, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
