package com.arslan.llamachat.llm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Character(
    val id: String = System.currentTimeMillis().toString(),
    val name: String,
    val description: String,
    val systemPrompt: String,
    val avatarEmoji: String = "🤖",
    val voiceName: String = "",
    val isBuiltIn: Boolean = false,
)

val BUILT_IN_CHARACTERS = listOf(
    Character("assistant","Assistant","Helpful, friendly AI.","You are a helpful, friendly, and concise AI assistant. Answer questions accurately and conversationally.","🤖",isBuiltIn=true),
    Character("scientist","Dr. Nova","Brilliant scientist with genuine curiosity.","You are Dr. Nova, a brilliant scientist. Explain complex topics with precision, use real examples, and express excitement about discovery.","🔬",isBuiltIn=true),
    Character("tutor","Professor","Patient teacher who breaks down any subject.","You are a patient, encouraging professor. Break down complex subjects into simple steps, use analogies, and adapt to the student's level.","📚",isBuiltIn=true),
    Character("chef","Chef Marco","Passionate Italian chef with decades of experience.","You are Chef Marco, a passionate Italian chef with 30 years of experience. Share cooking tips generously, occasionally use Italian phrases.","👨‍🍳",isBuiltIn=true),
    Character("coder","Dev","Expert software engineer with clean code focus.","You are Dev, an expert software engineer. Write clean, efficient code, explain your reasoning, and always consider edge cases.","💻",isBuiltIn=true),
    Character("philosopher","Socrates","Uses questions to help discover truth.","You are a philosophical guide inspired by Socrates. Use the Socratic method — ask probing questions to help the user discover truth themselves.","🏛️",isBuiltIn=true),
    Character("therapist","Dr. Calm","Empathetic listener for thinking through problems.","You are Dr. Calm, an empathetic counselor. Listen carefully, reflect feelings accurately, help users gain insight. Do not diagnose.","🌿",isBuiltIn=true),
)

object CharacterManager {
    private fun prefs(context: Context) = context.getSharedPreferences("pocketmind_chars", Context.MODE_PRIVATE)

    fun loadCustom(context: Context): List<Character> {
        val raw = prefs(context).getString("characters", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Character(id=o.getString("id"), name=o.getString("name"), description=o.getString("description"),
                    systemPrompt=o.getString("systemPrompt"), avatarEmoji=o.optString("avatarEmoji","🤖"),
                    voiceName=o.optString("voiceName",""), isBuiltIn=false)
            }
        } catch (_: Exception) { emptyList() }
    }

    fun saveCustom(context: Context, characters: List<Character>) {
        val arr = JSONArray()
        characters.filter { !it.isBuiltIn }.forEach { c ->
            arr.put(JSONObject().apply {
                put("id",c.id); put("name",c.name); put("description",c.description)
                put("systemPrompt",c.systemPrompt); put("avatarEmoji",c.avatarEmoji); put("voiceName",c.voiceName)
            })
        }
        prefs(context).edit().putString("characters", arr.toString()).apply()
    }

    fun allCharacters(context: Context): List<Character> = BUILT_IN_CHARACTERS + loadCustom(context)
}
