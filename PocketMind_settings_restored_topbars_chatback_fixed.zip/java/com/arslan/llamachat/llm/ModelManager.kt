package com.arslan.llamachat.llm

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

data class ModelInfo(
    val key: String, val displayName: String,
    val repo: String, val file: String,
    val sizeDisplay: String, val ramNeededMb: Long,
    val description: String, val category: String,
    val isNew: Boolean = false, val isPopular: Boolean = false, val isTrending: Boolean = false,
)

val MODEL_CATEGORIES = listOf(
    "General", "Coding", "Study", "Medical", "Law", "Business", "Small", "Large"
)

val MODELS = listOf(
    // ------------------------------------------------------------
    // Small / test models
    // ------------------------------------------------------------
    ModelInfo(
        key = "tinyllama",
        displayName = "TinyLlama 1.1B",
        repo = "TheBloke/TinyLlama-1.1B-Chat-v1.0-GGUF",
        file = "tinyllama-1.1b-chat-v1.0.Q4_K_M.gguf",
        sizeDisplay = "0.6 GB",
        ramNeededMb = 1500,
        description = "Fastest test model. Good for checking custom loading, basic chat, and low-end phones.",
        category = "Small",
        isPopular = true,
    ),
    ModelInfo(
        key = "smollm2",
        displayName = "SmolLM2 1.7B",
        repo = "bartowski/SmolLM2-1.7B-Instruct-GGUF",
        file = "SmolLM2-1.7B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "1.1 GB",
        ramNeededMb = 2000,
        description = "Tiny but capable assistant. Strong first download for speed and battery-friendly testing.",
        category = "Small",
        isNew = true,
        isTrending = true,
    ),
    ModelInfo(
        key = "gemma2b",
        displayName = "Gemma 2B",
        repo = "bartowski/gemma-2-2b-it-GGUF",
        file = "gemma-2-2b-it-Q4_K_M.gguf",
        sizeDisplay = "1.5 GB",
        ramNeededMb = 2500,
        description = "Compact everyday assistant for explanations, summaries, and general tasks.",
        category = "Small",
        isNew = true,
        isTrending = true,
    ),
    ModelInfo(
        key = "phi35",
        displayName = "Phi-3.5 Mini 3.8B",
        repo = "bartowski/Phi-3.5-mini-instruct-GGUF",
        file = "Phi-3.5-mini-instruct-Q4_K_M.gguf",
        sizeDisplay = "2.2 GB",
        ramNeededMb = 3500,
        description = "Efficient reasoning model for study, writing, and compact offline intelligence.",
        category = "Small",
        isNew = true,
        isPopular = true,
    ),

    // ------------------------------------------------------------
    // General AI models
    // ------------------------------------------------------------
    ModelInfo(
        key = "llama32_3b",
        displayName = "Llama 3.2 3B",
        repo = "bartowski/Llama-3.2-3B-Instruct-GGUF",
        file = "Llama-3.2-3B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "1.9 GB",
        ramNeededMb = 3000,
        description = "Meta compact assistant. Great balance for chat, summaries, and everyday offline use.",
        category = "General",
        isNew = true,
        isTrending = true,
    ),
    ModelInfo(
        key = "qwen25_3b",
        displayName = "Qwen 2.5 3B",
        repo = "bartowski/Qwen2.5-3B-Instruct-GGUF",
        file = "Qwen2.5-3B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "2.0 GB",
        ramNeededMb = 3200,
        description = "Compact all-rounder with strong reasoning for its size.",
        category = "General",
        isNew = true,
        isPopular = true,
    ),
    ModelInfo(
        key = "mistral",
        displayName = "Mistral 7B",
        repo = "TheBloke/Mistral-7B-Instruct-v0.2-GGUF",
        file = "mistral-7b-instruct-v0.2.Q4_K_M.gguf",
        sizeDisplay = "4.1 GB",
        ramNeededMb = 6000,
        description = "Excellent all-rounder for writing, reasoning, and longer answers on stronger phones.",
        category = "General",
        isPopular = true,
    ),
    ModelInfo(
        key = "llama31_8b",
        displayName = "Llama 3.1 8B",
        repo = "bartowski/Meta-Llama-3.1-8B-Instruct-GGUF",
        file = "Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "4.7 GB",
        ramNeededMb = 7000,
        description = "High-quality general assistant for strong offline conversations.",
        category = "General",
        isPopular = true,
        isTrending = true,
    ),

    // ------------------------------------------------------------
    // Coding models
    // ------------------------------------------------------------
    ModelInfo(
        key = "qwen25_coder_1_5b",
        displayName = "Qwen2.5 Coder 1.5B",
        repo = "bartowski/Qwen2.5-Coder-1.5B-Instruct-GGUF",
        file = "Qwen2.5-Coder-1.5B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "1.1 GB",
        ramNeededMb = 2200,
        description = "Small coding model for quick snippets, syntax help, and lightweight debugging.",
        category = "Coding",
        isNew = true,
    ),
    ModelInfo(
        key = "codegemma_2b",
        displayName = "CodeGemma 2B",
        repo = "bartowski/codegemma-2b-GGUF",
        file = "codegemma-2b-Q4_K_M.gguf",
        sizeDisplay = "1.6 GB",
        ramNeededMb = 2800,
        description = "Compact code-focused model for completions, examples, and programming explanations.",
        category = "Coding",
        isPopular = true,
    ),
    ModelInfo(
        key = "qwen25_coder_3b",
        displayName = "Qwen2.5 Coder 3B",
        repo = "bartowski/Qwen2.5-Coder-3B-Instruct-GGUF",
        file = "Qwen2.5-Coder-3B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "1.9 GB",
        ramNeededMb = 3300,
        description = "Recommended coding model for Android, Kotlin, Java, Python, debugging, and code review.",
        category = "Coding",
        isPopular = true,
        isTrending = true,
    ),
    ModelInfo(
        key = "qwen25_7b",
        displayName = "Qwen 2.5 7B",
        repo = "bartowski/Qwen2.5-7B-Instruct-GGUF",
        file = "Qwen2.5-7B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "4.4 GB",
        ramNeededMb = 6500,
        description = "Strong coding and reasoning model for complex debugging and multi-step development tasks.",
        category = "Coding",
        isNew = true,
        isTrending = true,
    ),

    // ------------------------------------------------------------
    // Study, math, and academic models
    // ------------------------------------------------------------
    ModelInfo(
        key = "qwen25_math_1_5b",
        displayName = "Qwen2.5 Math 1.5B",
        repo = "bartowski/Qwen2.5-Math-1.5B-Instruct-GGUF",
        file = "Qwen2.5-Math-1.5B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "1.1 GB",
        ramNeededMb = 2200,
        description = "Small math-focused model for formula practice, step-by-step study, and quick checking.",
        category = "Study",
        isNew = true,
    ),
    ModelInfo(
        key = "qwen25_math_7b",
        displayName = "Qwen2.5 Math 7B",
        repo = "bartowski/Qwen2.5-Math-7B-Instruct-GGUF",
        file = "Qwen2.5-Math-7B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "4.4 GB",
        ramNeededMb = 6500,
        description = "Math-focused model for algebra, calculus, reasoning, and exam-style walkthroughs.",
        category = "Study",
        isPopular = true,
        isTrending = true,
    ),
    ModelInfo(
        key = "mathstral_7b",
        displayName = "Mathstral 7B",
        repo = "bartowski/Mathstral-7B-v0.1-GGUF",
        file = "Mathstral-7B-v0.1-Q4_K_M.gguf",
        sizeDisplay = "4.1 GB",
        ramNeededMb = 6200,
        description = "Specialized math model for structured problem solving and technical explanations.",
        category = "Study",
        isNew = true,
    ),
    ModelInfo(
        key = "deepseek_7b",
        displayName = "DeepSeek-R1 7B",
        repo = "bartowski/DeepSeek-R1-Distill-Qwen-7B-GGUF",
        file = "DeepSeek-R1-Distill-Qwen-7B-Q4_K_M.gguf",
        sizeDisplay = "4.4 GB",
        ramNeededMb = 6500,
        description = "Reasoning model for multi-step study questions, logic, and difficult problems.",
        category = "Study",
        isNew = true,
        isTrending = true,
    ),

    // ------------------------------------------------------------
    // Medical and biomedical models
    // ------------------------------------------------------------
    ModelInfo(
        key = "biomistral_7b",
        displayName = "BioMistral 7B",
        repo = "BioMistral/BioMistral-7B-GGUF",
        file = "ggml-model-Q4_K_M.gguf",
        sizeDisplay = "4.4 GB",
        ramNeededMb = 6500,
        description = "Biomedical model for medical literature, terminology, and study support. Not for diagnosis.",
        category = "Medical",
        isPopular = true,
    ),
    ModelInfo(
        key = "openbiollm_8b",
        displayName = "OpenBioLLM 8B",
        repo = "QuantFactory/OpenBioLLM-Llama3-8B-GGUF",
        file = "Llama3-OpenBioLLM-8B.Q4_K_M.gguf",
        sizeDisplay = "4.9 GB",
        ramNeededMb = 7200,
        description = "Biomedical assistant for literature review and health-science learning. Educational use only.",
        category = "Medical",
        isNew = true,
        isTrending = true,
    ),
    ModelInfo(
        key = "meditron_7b",
        displayName = "Meditron 7B",
        repo = "QuantFactory/meditron-7b-GGUF",
        file = "meditron-7b.Q4_K_M.gguf",
        sizeDisplay = "4.1 GB",
        ramNeededMb = 6200,
        description = "Medical-domain model for guidelines and biomedical text. Educational support, not medical advice.",
        category = "Medical",
    ),
    ModelInfo(
        key = "medicine_general_mistral",
        displayName = "Mistral 7B Medical Helper",
        repo = "TheBloke/Mistral-7B-Instruct-v0.2-GGUF",
        file = "mistral-7b-instruct-v0.2.Q4_K_M.gguf",
        sizeDisplay = "4.1 GB",
        ramNeededMb = 6000,
        description = "General model placed here for medical-study summaries when specialist models are too heavy.",
        category = "Medical",
    ),

    // ------------------------------------------------------------
    // Law models
    // ------------------------------------------------------------
    ModelInfo(
        key = "law_chat_7b",
        displayName = "Law Chat 7B",
        repo = "TheBloke/law-chat-GGUF",
        file = "law-chat.Q4_K_M.gguf",
        sizeDisplay = "4.1 GB",
        ramNeededMb = 6200,
        description = "Legal-domain chat model for legal text explanation and document study. Not legal advice.",
        category = "Law",
        isPopular = true,
    ),
    ModelInfo(
        key = "law_chat_7b_small",
        displayName = "Law Chat 7B Small",
        repo = "tensorblock/law-chat-GGUF",
        file = "law-chat-Q3_K_M.gguf",
        sizeDisplay = "3.3 GB",
        ramNeededMb = 5200,
        description = "Smaller legal-domain option for phones with less memory. Lower quality than Q4 models.",
        category = "Law",
        isNew = true,
    ),
    ModelInfo(
        key = "law_mistral_helper",
        displayName = "Mistral Legal Helper",
        repo = "TheBloke/Mistral-7B-Instruct-v0.2-GGUF",
        file = "mistral-7b-instruct-v0.2.Q4_K_M.gguf",
        sizeDisplay = "4.1 GB",
        ramNeededMb = 6000,
        description = "General model useful for legal summaries, contracts, and policy explanations. Verify with professionals.",
        category = "Law",
    ),
    ModelInfo(
        key = "qwen_law_reasoner",
        displayName = "Qwen 2.5 Legal Reasoner",
        repo = "bartowski/Qwen2.5-7B-Instruct-GGUF",
        file = "Qwen2.5-7B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "4.4 GB",
        ramNeededMb = 6500,
        description = "Strong general reasoner for legal-style analysis, clauses, and structured comparisons.",
        category = "Law",
        isTrending = true,
    ),

    // ------------------------------------------------------------
    // Business and productivity models
    // ------------------------------------------------------------
    ModelInfo(
        key = "business_phi35",
        displayName = "Phi-3.5 Business Mini",
        repo = "bartowski/Phi-3.5-mini-instruct-GGUF",
        file = "Phi-3.5-mini-instruct-Q4_K_M.gguf",
        sizeDisplay = "2.2 GB",
        ramNeededMb = 3500,
        description = "Compact model for emails, proposals, plans, sales messages, and productivity tasks.",
        category = "Business",
        isPopular = true,
    ),
    ModelInfo(
        key = "business_llama32",
        displayName = "Llama 3.2 Business 3B",
        repo = "bartowski/Llama-3.2-3B-Instruct-GGUF",
        file = "Llama-3.2-3B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "1.9 GB",
        ramNeededMb = 3000,
        description = "Fast business writing assistant for proposals, outreach, summaries, and planning.",
        category = "Business",
        isNew = true,
    ),
    ModelInfo(
        key = "business_qwen3b",
        displayName = "Qwen 2.5 Business 3B",
        repo = "bartowski/Qwen2.5-3B-Instruct-GGUF",
        file = "Qwen2.5-3B-Instruct-Q4_K_M.gguf",
        sizeDisplay = "2.0 GB",
        ramNeededMb = 3200,
        description = "Balanced assistant for business analysis, client communication, and structured documents.",
        category = "Business",
        isTrending = true,
    ),
    ModelInfo(
        key = "business_mistral",
        displayName = "Mistral Business 7B",
        repo = "TheBloke/Mistral-7B-Instruct-v0.2-GGUF",
        file = "mistral-7b-instruct-v0.2.Q4_K_M.gguf",
        sizeDisplay = "4.1 GB",
        ramNeededMb = 6000,
        description = "Stronger business model for proposals, strategy, reports, and longer professional writing.",
        category = "Business",
        isPopular = true,
    ),

    // ------------------------------------------------------------
    // Large premium offline option
    // ------------------------------------------------------------
    ModelInfo(
        key = "mistral_nemo",
        displayName = "Mistral Nemo 12B",
        repo = "bartowski/Mistral-Nemo-Instruct-2407-GGUF",
        file = "Mistral-Nemo-Instruct-2407-Q4_K_M.gguf",
        sizeDisplay = "7.1 GB",
        ramNeededMb = 10000,
        description = "Large high-quality offline model for stronger phones with plenty of RAM.",
        category = "Large",
        isNew = true,
        isPopular = true,
    ),
)

object ModelManager {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true).build()

    private val cancelFlags = mutableMapOf<String, AtomicBoolean>()

    fun modelsDir(context: Context): File = File(context.filesDir, "models").also { it.mkdirs() }
    fun modelFile(context: Context, info: ModelInfo): File = File(modelsDir(context), info.file)
    fun tmpFile(context: Context, info: ModelInfo): File = File(modelsDir(context), info.file + ".tmp")

    fun isDownloaded(context: Context, info: ModelInfo): Boolean {
        val f = modelFile(context, info)
        if (!f.exists() || f.length() < 1_000_000L) return false
        return try {
            val b = ByteArray(4); f.inputStream().use { it.read(b) }
            b[0] == 0x47.toByte() && b[1] == 0x47.toByte() &&
            b[2] == 0x55.toByte() && b[3] == 0x46.toByte()
        } catch (_: Exception) { false }
    }

    fun cancelDownload(key: String) { cancelFlags[key]?.set(true) }

    suspend fun download(
        context: Context,
        info: ModelInfo,
        onProgress: (Float, Long, Long) -> Unit,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val cancel = AtomicBoolean(false).also { cancelFlags[info.key] = it }
        val dest = modelFile(context, info)
        val tmp = tmpFile(context, info)
        var lastError: Exception = Exception("Unknown")

        for (attempt in 0..2) {
            if (cancel.get()) { cancelFlags.remove(info.key); return@withContext Result.failure(Exception("Cancelled")) }
            if (attempt > 0) delay(2000L * attempt)

            val resumeBytes = if (tmp.exists()) tmp.length() else 0L
            val req = Request.Builder()
                .url("https://huggingface.co/${info.repo}/resolve/main/${info.file}")
                .apply { if (resumeBytes > 0) header("Range", "bytes=$resumeBytes-") }
                .header("User-Agent", "PocketMind-Android")
                .build()

            try {
                client.newCall(req).execute().use { resp ->
                    val actualResume: Long = when (resp.code) {
                        206 -> resumeBytes
                        200 -> { tmp.delete(); 0L }
                        401, 403 -> { lastError = Exception("Access denied. This model may require accepting terms on Hugging Face or using manual import."); return@use }
                        404 -> { lastError = Exception("Model file not found on Hugging Face. Try manual import or another quant."); return@use }
                        else -> { lastError = Exception("HTTP ${resp.code}"); return@use }
                    }
                    val body = resp.body ?: run { lastError = Exception("Empty body"); return@use }
                    val contentLen = body.contentLength()
                    val total = if (contentLen > 0) contentLen + actualResume else -1L
                    var downloaded = actualResume

                    RandomAccessFile(tmp, "rw").use { raf ->
                        raf.seek(actualResume)
                        body.byteStream().use { inp ->
                            val buf = ByteArray(64 * 1024)
                            var n: Int
                            while (inp.read(buf).also { n = it } != -1) {
                                if (cancel.get()) {
                                    cancelFlags.remove(info.key)
                                    return@withContext Result.failure(Exception("Cancelled"))
                                }
                                raf.write(buf, 0, n)
                                downloaded += n
                                val progress = if (total > 0) downloaded.toFloat() / total else 0f
                                onProgress(progress.coerceIn(0f, 1f), downloaded, total)
                            }
                        }
                    }
                    if (dest.exists()) dest.delete()
                    tmp.renameTo(dest)
                    cancelFlags.remove(info.key)
                    return@withContext Result.success(Unit)
                }
            } catch (e: Exception) { lastError = e }
        }
        cancelFlags.remove(info.key)
        Result.failure(lastError)
    }

    fun delete(context: Context, info: ModelInfo) {
        modelFile(context, info).delete()
        tmpFile(context, info).delete()
    }
}
