package com.arslan.llamachat.llm

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

data class ImageModelInfo(
    val key: String,
    val displayName: String,
    val repo: String,
    val file: String,
    val sizeDisplay: String,
    val ramNeededMb: Long,
    val description: String,
    val bestSize: Int,
    val bestSteps: Int,
    val note: String,
    val isRecommended: Boolean = false,
)

data class ImageDownloadStats(
    val progress: Float = 0f,
    val speedBytesPerSec: Long = 0L,
    val downloadedBytes: Long = 0L,
    val totalBytes: Long = 0L,
)

enum class ImageSourceTier {
    OFFLINE,
    FREE_ONLINE,
    PREMIUM_ONLINE
}

data class OnlineImageModelInfo(
    val key: String,
    val displayName: String,
    val providerKey: String,
    val providerLabel: String,
    val remoteModelId: String,
    val tier: ImageSourceTier,
    val description: String,
    val note: String,
    val bestSize: Int = 512,
    val bestSteps: Int = 4,
    val requiresApiKey: Boolean = true,
    val apiKeyUrl: String = "",
    val isRecommended: Boolean = false,
)

val IMAGE_MODELS = listOf(
    ImageModelInfo(
        key = "dreamshaper8_lcm",
        displayName = "DreamShaper 8 LCM",
        repo = "Lykon/dreamshaper-8-lcm",
        file = "DreamShaper8_LCM.safetensors",
        sizeDisplay = "2.1 GB",
        ramNeededMb = 4500,
        description = "Fast SD 1.5-style model. Good first choice for phones because LCM works with fewer steps.",
        bestSize = 256,
        bestSteps = 8,
        note = "Recommended first test: 256×256, 8 steps, CFG 1–3.",
        isRecommended = true,
    ),
    ImageModelInfo(
        key = "dreamshaper8",
        displayName = "DreamShaper 8",
        repo = "Lykon/DreamShaper",
        file = "DreamShaper_8_pruned.safetensors",
        sizeDisplay = "2.1 GB",
        ramNeededMb = 5500,
        description = "Higher-quality SD 1.5 checkpoint for general creative images.",
        bestSize = 384,
        bestSteps = 12,
        note = "Use 256×256 or 384×384 on phones first. 512×512 can be slow or memory-heavy.",
    ),
    ImageModelInfo(
        key = "sd15_base",
        displayName = "Stable Diffusion 1.5",
        repo = "stable-diffusion-v1-5/stable-diffusion-v1-5",
        file = "v1-5-pruned-emaonly.safetensors",
        sizeDisplay = "4.0 GB",
        ramNeededMb = 6500,
        description = "Classic base SD 1.5 model. Reliable, but heavier than DreamShaper LCM.",
        bestSize = 256,
        bestSteps = 12,
        note = "If Hugging Face blocks access, import your own downloaded SD 1.5 file manually.",
    ),
)

val FREE_ONLINE_IMAGE_MODELS = listOf(
    OnlineImageModelInfo(
        key = "pollinations_flux",
        displayName = "Pollinations FLUX",
        providerKey = "pollinations",
        providerLabel = "Pollinations",
        remoteModelId = "flux",
        tier = ImageSourceTier.FREE_ONLINE,
        description = "Free-tier online image generation with no API key. Your prompt is sent to Pollinations when selected.",
        note = "No key required. Requires internet. Availability and provider behavior can vary because it is a public online service.",
        bestSize = 512,
        bestSteps = 4,
        requiresApiKey = false,
        isRecommended = true,
    ),
    OnlineImageModelInfo(
        key = "hf_flux_schnell",
        displayName = "FLUX.1 Schnell",
        providerKey = "huggingface",
        providerLabel = "Hugging Face",
        remoteModelId = "black-forest-labs/FLUX.1-schnell",
        tier = ImageSourceTier.FREE_ONLINE,
        description = "Good free-tier option with your own Hugging Face token. Prompts are sent directly to Hugging Face when selected.",
        note = "Requires a Hugging Face token with inference/provider access. Free-tier speed and availability may vary.",
        bestSize = 512,
        bestSteps = 4,
        requiresApiKey = true,
        apiKeyUrl = "https://huggingface.co/settings/tokens",
    ),
)

val PREMIUM_ONLINE_IMAGE_MODELS = listOf(
    OnlineImageModelInfo(
        key = "together_flux_schnell",
        displayName = "FLUX.1 Schnell",
        providerKey = "together",
        providerLabel = "Together AI",
        remoteModelId = "black-forest-labs/FLUX.1-schnell",
        tier = ImageSourceTier.PREMIUM_ONLINE,
        description = "Fast premium online generation. Prompts and settings are sent directly to Together AI when selected.",
        note = "Requires your Together AI API key. Use the same key entered in Online Models Setup.",
        bestSize = 512,
        bestSteps = 4,
        requiresApiKey = true,
        apiKeyUrl = "https://api.together.ai/settings/api-keys",
        isRecommended = true,
    ),
    OnlineImageModelInfo(
        key = "together_sdxl",
        displayName = "SDXL 1.0",
        providerKey = "together",
        providerLabel = "Together AI",
        remoteModelId = "stabilityai/stable-diffusion-xl-base-1.0",
        tier = ImageSourceTier.PREMIUM_ONLINE,
        description = "Balanced premium model for general creative images. Prompts and settings are sent directly to Together AI when selected.",
        note = "Requires your Together AI API key. Use the same key entered in Online Models Setup.",
        bestSize = 512,
        bestSteps = 8,
        requiresApiKey = true,
        apiKeyUrl = "https://api.together.ai/settings/api-keys",
    ),
)

fun allOnlineImageModels(): List<OnlineImageModelInfo> =
    FREE_ONLINE_IMAGE_MODELS + PREMIUM_ONLINE_IMAGE_MODELS

object ImageModelManager {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val cancelFlags = mutableMapOf<String, AtomicBoolean>()

    fun imageModelsDir(context: Context): File =
        File(context.filesDir, "image_models").also { it.mkdirs() }

    fun modelFile(context: Context, info: ImageModelInfo): File =
        File(imageModelsDir(context), safeFileName(info.file))

    fun tmpFile(context: Context, info: ImageModelInfo): File =
        File(imageModelsDir(context), safeFileName(info.file) + ".tmp")

    fun isDownloaded(context: Context, info: ImageModelInfo): Boolean {
        val f = modelFile(context, info)
        return f.exists() && f.length() > 100L * 1024L * 1024L
    }

    fun downloadedKeys(context: Context): Set<String> =
        IMAGE_MODELS.filter { isDownloaded(context, it) }.map { it.key }.toSet()

    fun delete(context: Context, info: ImageModelInfo) {
        runCatching { modelFile(context, info).delete() }
        runCatching { tmpFile(context, info).delete() }
    }

    fun cancelDownload(key: String) {
        cancelFlags[key]?.set(true)
    }

    suspend fun download(
        context: Context,
        info: ImageModelInfo,
        onProgress: (Float, Long, Long, Long) -> Unit,
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val cancel = AtomicBoolean(false).also { cancelFlags[info.key] = it }
        val dest = modelFile(context, info)
        val tmp = tmpFile(context, info)
        var lastError: Exception = Exception("Unknown download error")

        for (attempt in 0..2) {
            if (cancel.get()) {
                cancelFlags.remove(info.key)
                return@withContext Result.failure(Exception("Cancelled"))
            }
            if (attempt > 0) delay(2000L * attempt)

            val resumeBytes = if (tmp.exists()) tmp.length() else 0L
            val request = Request.Builder()
                .url("https://huggingface.co/${info.repo}/resolve/main/${info.file}")
                .apply {
                    if (resumeBytes > 0L) header("Range", "bytes=$resumeBytes-")
                    header("User-Agent", "PocketMind-Android")
                }
                .build()

            try {
                client.newCall(request).execute().use { response ->
                    val actualResume = when (response.code) {
                        206 -> resumeBytes
                        200 -> {
                            if (resumeBytes > 0L) tmp.delete()
                            0L
                        }
                        401, 403 -> {
                            lastError = Exception("Access denied by Hugging Face. Try manual import for this model.")
                            return@use
                        }
                        else -> {
                            lastError = Exception("HTTP ${response.code}")
                            return@use
                        }
                    }

                    val body = response.body ?: run {
                        lastError = Exception("Empty response body")
                        return@use
                    }

                    val contentLength = body.contentLength()
                    val total = if (contentLength > 0L) contentLength + actualResume else -1L
                    var downloaded = actualResume
                    var lastTime = System.currentTimeMillis()
                    var lastBytes = downloaded
                    var speed = 0L

                    RandomAccessFile(tmp, "rw").use { raf ->
                        raf.seek(actualResume)
                        body.byteStream().use { input ->
                            val buffer = ByteArray(1024 * 1024)
                            while (true) {
                                val read = input.read(buffer)
                                if (read <= 0) break

                                if (cancel.get()) {
                                    cancelFlags.remove(info.key)
                                    return@withContext Result.failure(Exception("Cancelled"))
                                }

                                raf.write(buffer, 0, read)
                                downloaded += read

                                val now = System.currentTimeMillis()
                                val deltaMs = (now - lastTime).coerceAtLeast(1L)
                                if (deltaMs >= 500L) {
                                    speed = ((downloaded - lastBytes) * 1000L) / deltaMs
                                    lastTime = now
                                    lastBytes = downloaded
                                }

                                val progress = if (total > 0L) downloaded.toFloat() / total else 0f
                                onProgress(progress.coerceIn(0f, 1f), downloaded, total, speed)
                            }
                        }
                    }

                    if (!tmp.exists() || tmp.length() <= 100L * 1024L * 1024L) {
                        lastError = Exception("Downloaded file is too small or incomplete")
                        return@use
                    }

                    if (dest.exists()) dest.delete()
                    if (!tmp.renameTo(dest)) {
                        tmp.copyTo(dest, overwrite = true)
                        tmp.delete()
                    }

                    cancelFlags.remove(info.key)
                    onProgress(1f, dest.length(), dest.length(), speed)
                    return@withContext Result.success(Unit)
                }
            } catch (e: Exception) {
                lastError = e
            }
        }

        cancelFlags.remove(info.key)
        Result.failure(lastError)
    }

    private fun safeFileName(name: String): String =
        name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "image-model.safetensors" }
}
