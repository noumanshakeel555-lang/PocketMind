package com.arslan.llamachat.llm

import android.content.Context
import androidx.core.content.edit
import com.arslan.llamachat.ui.ChatSession
import com.arslan.llamachat.ui.Message
import org.json.JSONArray
import org.json.JSONObject

object Prefs {
    private fun prefs(context: Context) =
        context.getSharedPreferences("pocketmind_prefs", Context.MODE_PRIVATE)

    fun saveInt(context: Context, key: String, value: Int) = prefs(context).edit { putInt(key, value) }
    fun getInt(context: Context, key: String, default: Int) = prefs(context).getInt(key, default)
    fun saveFloat(context: Context, key: String, value: Float) = prefs(context).edit { putFloat(key, value) }
    fun getFloat(context: Context, key: String, default: Float) = prefs(context).getFloat(key, default)
    fun saveBool(context: Context, key: String, value: Boolean) = prefs(context).edit { putBoolean(key, value) }
    fun getBool(context: Context, key: String, default: Boolean) = prefs(context).getBoolean(key, default)
    fun saveString(context: Context, key: String, value: String) = prefs(context).edit { putString(key, value) }
    fun getString(context: Context, key: String, default: String) = prefs(context).getString(key, default) ?: default
    fun saveBookmarks(context: Context, keys: Set<String>) = prefs(context).edit { putStringSet("bookmarks", keys) }
    fun loadBookmarks(context: Context): Set<String> = prefs(context).getStringSet("bookmarks", emptySet()) ?: emptySet()

    fun saveSessions(context: Context, sessions: List<ChatSession>) {
        val arr = JSONArray()
        sessions.takeLast(50).forEach { session ->
            arr.put(JSONObject().apply {
                put("id", session.id); put("modelKey", session.modelKey); put("title", session.title)
                put("isPinned", session.isPinned); put("updatedAt", session.updatedAt)
                val msgs = JSONArray()
                session.messages.forEach { msg ->
                    msgs.put(JSONObject().apply {
                        put("id", msg.id); put("role", msg.role)
                        put("content", msg.content); put("characterId", msg.characterId)
                    })
                }
                put("messages", msgs)
            })
        }
        prefs(context).edit { putString("sessions", arr.toString()) }
    }

    fun loadSessions(context: Context): List<ChatSession> {
        val raw = prefs(context).getString("sessions", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                val msgs = obj.getJSONArray("messages")
                ChatSession(
                    id = obj.getLong("id"), modelKey = obj.getString("modelKey"),
                    title = obj.optString("title", "Chat"),
                    messages = (0 until msgs.length()).map { j ->
                        val m = msgs.getJSONObject(j)
                        Message(id = m.optLong("id", System.nanoTime()),
                            role = m.getString("role"), content = m.getString("content"),
                            characterId = m.optString("characterId", ""))
                    },
                    isPinned = obj.optBoolean("isPinned", false),
                    updatedAt = obj.optLong("updatedAt", obj.getLong("id")),
                )
            }
        } catch (_: Exception) { emptyList() }
    }
}
