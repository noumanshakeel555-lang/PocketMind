package com.arslan.llamachat.llm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class OnlineResult {
    data class Token(val text: String) : OnlineResult()
    object Done : OnlineResult()
    data class Error(val message: String) : OnlineResult()
}

object OnlineEngine {

    private const val GROQ_TEXT_MODEL = "llama-3.3-70b-versatile"
    private const val GROQ_VISION_MODEL = "meta-llama/llama-4-scout-17b-16e-instruct"
    private const val GEMINI_MODEL = "gemini-2.5-flash"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private val JSON = "application/json".toMediaType()

    suspend fun streamGroq(
        apiKey: String,
        messages: List<Map<String, String>>,
        maxTokens: Int = 2048,
        imageMimeType: String? = null,
        imageBase64: String? = null,
        onToken: (String) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val hasImage = !imageMimeType.isNullOrBlank() && !imageBase64.isNullOrBlank()
        val lastUserIndex = messages.indexOfLast { it["role"] == "user" }

        val groqMessages = JSONArray()
        messages.forEachIndexed { index, m ->
            val role = m["role"] ?: "user"
            val content = m["content"] ?: ""
            val obj = JSONObject().put("role", role)

            if (hasImage && index == lastUserIndex && role == "user") {
                val parts = JSONArray()
                    .put(JSONObject().put("type", "text").put("text", content))
                    .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().apply {
                        put("url", "data:$imageMimeType;base64,$imageBase64")
                    }))
                obj.put("content", parts)
            } else {
                obj.put("content", content)
            }
            groqMessages.put(obj)
        }

        val body = JSONObject().apply {
            put("model", if (hasImage) GROQ_VISION_MODEL else GROQ_TEXT_MODEL)
            put("messages", groqMessages)
            put("stream", true)
            put("max_completion_tokens", maxTokens.coerceIn(64, if (hasImage) 8192 else 2048))
            put("temperature", 0.8)
            put("top_p", 1.0)
        }
        val req = Request.Builder()
            .url("https://api.groq.com/openai/v1/chat/completions")
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody(JSON))
            .build()

        try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string() ?: "HTTP ${resp.code}"
                    onError(parseApiError(err, resp.code))
                    return@withContext
                }
                resp.body?.source()?.let { source ->
                    while (!source.exhausted()) {
                        val line = source.readUtf8Line() ?: break
                        if (line.startsWith("data: ")) {
                            val data = line.removePrefix("data: ").trim()
                            if (data == "[DONE]") { onDone(); return@withContext }
                            try {
                                val chunk = JSONObject(data)
                                val content = chunk
                                    .getJSONArray("choices")
                                    .getJSONObject(0)
                                    .getJSONObject("delta")
                                    .optString("content", "")
                                if (content.isNotEmpty()) onToken(content)
                            } catch (_: Exception) {}
                        }
                    }
                }
                onDone()
            }
        } catch (e: Exception) {
            onError("Network error: ${e.message}")
        }
    }

    suspend fun streamGemini(
        apiKey: String,
        messages: List<Map<String, String>>,
        systemPrompt: String,
        maxTokens: Int = 2048,
        imageMimeType: String? = null,
        imageBase64: String? = null,
        onToken: (String) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val contents = JSONArray()
        val geminiMessages = messages.filter { it["role"] != "system" }
        val lastUserIndex = geminiMessages.indexOfLast { it["role"] == "user" }
        geminiMessages.forEachIndexed { index, m ->
            val role = if (m["role"] == "user") "user" else "model"
            val parts = JSONArray().put(JSONObject().put("text", m["content"] ?: ""))

            if (index == lastUserIndex && !imageMimeType.isNullOrBlank() && !imageBase64.isNullOrBlank()) {
                parts.put(JSONObject().put("inline_data", JSONObject().apply {
                    put("mime_type", imageMimeType)
                    put("data", imageBase64)
                }))
            }

            contents.put(JSONObject().apply {
                put("role", role)
                put("parts", parts)
            })
        }
        val body = JSONObject().apply {
            put("system_instruction", JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", systemPrompt))))
            put("contents", contents)
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", maxTokens.coerceIn(64, 2048))
                put("temperature", 0.8)
            })
        }
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
            "$GEMINI_MODEL:streamGenerateContent?alt=sse&key=$apiKey"
        val req = Request.Builder()
            .url(url)
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody(JSON))
            .build()

        try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string() ?: "HTTP ${resp.code}"
                    onError(parseApiError(err, resp.code))
                    return@withContext
                }
                resp.body?.source()?.let { source ->
                    while (!source.exhausted()) {
                        val line = source.readUtf8Line() ?: break
                        if (line.startsWith("data: ")) {
                            val data = line.removePrefix("data: ").trim()
                            try {
                                val chunk = JSONObject(data)
                                val parts = chunk
                                    .optJSONArray("candidates")
                                    ?.optJSONObject(0)
                                    ?.optJSONObject("content")
                                    ?.optJSONArray("parts")
                                if (parts != null) {
                                    for (i in 0 until parts.length()) {
                                        val text = parts.optJSONObject(i)?.optString("text", "").orEmpty()
                                        if (text.isNotEmpty()) onToken(text)
                                    }
                                }
                            } catch (_: Exception) {}
                        }
                    }
                }
                onDone()
            }
        } catch (e: Exception) {
            onError("Network error: ${e.message}")
        }
    }


    suspend fun streamHuggingFaceChat(
        apiKey: String,
        providerKey: String,
        messages: List<Map<String, String>>,
        systemPrompt: String,
        maxTokens: Int = 2048,
        onToken: (String) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit,
    ) = streamOpenAICompatibleChat(
        baseUrl = "https://router.huggingface.co/v1/chat/completions",
        apiKey = apiKey,
        model = huggingFaceModelFor(providerKey),
        messages = messages,
        systemPrompt = systemPrompt,
        maxTokens = maxTokens,
        onToken = onToken,
        onDone = onDone,
        onError = onError,
    )

    suspend fun streamTogetherChat(
        apiKey: String,
        providerKey: String,
        messages: List<Map<String, String>>,
        systemPrompt: String,
        maxTokens: Int = 2048,
        onToken: (String) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit,
    ) = streamOpenAICompatibleChat(
        baseUrl = "https://api.together.xyz/v1/chat/completions",
        apiKey = apiKey,
        model = togetherModelFor(providerKey),
        messages = messages,
        systemPrompt = systemPrompt,
        maxTokens = maxTokens,
        onToken = onToken,
        onDone = onDone,
        onError = onError,
    )

    private suspend fun streamOpenAICompatibleChat(
        baseUrl: String,
        apiKey: String,
        model: String,
        messages: List<Map<String, String>>,
        systemPrompt: String,
        maxTokens: Int,
        onToken: (String) -> Unit,
        onDone: () -> Unit,
        onError: (String) -> Unit,
    ) = withContext(Dispatchers.IO) {
        val outMessages = JSONArray()
        if (systemPrompt.isNotBlank()) {
            outMessages.put(JSONObject().put("role", "system").put("content", systemPrompt))
        }
        messages.filter { it["role"] != "system" }.forEach { m ->
            outMessages.put(JSONObject()
                .put("role", m["role"] ?: "user")
                .put("content", m["content"] ?: ""))
        }

        val body = JSONObject().apply {
            put("model", model)
            put("messages", outMessages)
            put("stream", true)
            put("max_tokens", maxTokens.coerceIn(64, 2048))
            put("temperature", 0.8)
            put("top_p", 1.0)
        }

        val req = Request.Builder()
            .url(baseUrl)
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody(JSON))
            .build()

        try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) {
                    val err = resp.body?.string() ?: "HTTP ${resp.code}"
                    onError(parseApiError(err, resp.code))
                    return@withContext
                }

                val source = resp.body?.source()
                if (source == null) {
                    onError("Empty response from online provider.")
                    return@withContext
                }

                while (!source.exhausted()) {
                    val line = source.readUtf8Line() ?: break
                    if (!line.startsWith("data: ")) continue
                    val data = line.removePrefix("data: ").trim()
                    if (data == "[DONE]") {
                        onDone()
                        return@withContext
                    }
                    try {
                        val chunk = JSONObject(data)
                        val delta = chunk
                            .optJSONArray("choices")
                            ?.optJSONObject(0)
                            ?.optJSONObject("delta")
                        val text = delta?.optString("content", "").orEmpty()
                        if (text.isNotEmpty()) onToken(text)
                    } catch (_: Exception) {}
                }
                onDone()
            }
        } catch (e: Exception) {
            onError("Network error: ${e.message}")
        }
    }

    private fun huggingFaceModelFor(providerKey: String): String = when (providerKey) {
        "hf_qwen_coder" -> "Qwen/Qwen2.5-Coder-7B-Instruct"
        "hf_mistral" -> "mistralai/Mistral-7B-Instruct-v0.3"
        else -> "Qwen/Qwen2.5-Coder-7B-Instruct"
    }

    private fun togetherModelFor(providerKey: String): String = when (providerKey) {
        "together_qwen" -> "Qwen/Qwen2.5-72B-Instruct-Turbo"
        "together_mixtral" -> "mistralai/Mixtral-8x7B-Instruct-v0.1"
        "together_llama" -> "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free"
        else -> "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free"
    }

    suspend fun validateHuggingFaceKey(apiKey: String): Boolean = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext false
        try {
            val req = Request.Builder()
                .url("https://huggingface.co/api/whoami-v2")
                .header("Authorization", "Bearer $apiKey")
                .get()
                .build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (_: Exception) { false }
    }

    suspend fun validateTogetherKey(apiKey: String): Boolean = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext false
        try {
            val req = Request.Builder()
                .url("https://api.together.xyz/v1/models")
                .header("Authorization", "Bearer $apiKey")
                .get()
                .build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (_: Exception) { false }
    }

    private fun parseApiError(body: String, code: Int): String = when (code) {
        400 -> try {
            val msg = JSONObject(body).optJSONObject("error")?.optString("message") ?: body.take(300)
            "Bad request: $msg"
        } catch (_: Exception) { "Bad request. Check model support and attached file size." }
        401 -> "Invalid API key. Please check your key in Settings."
        403 -> "API key denied. Check that this key is enabled for this provider/project."
        404 -> "Selected model was not found. Update the app's online model setting or try again later."
        413 -> "Image is too large for the online vision API. Try a smaller photo."
        429 -> "Rate limit reached. Wait a minute and try again."
        503 -> "Service temporarily unavailable. Try again shortly."
        else -> try {
            val msg = JSONObject(body)
                .optJSONObject("error")?.optString("message") ?: "Unknown error"
            "API error: $msg"
        } catch (_: Exception) { "HTTP $code error" }
    }

    suspend fun validateGroqKey(apiKey: String): Boolean = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext false
        try {
            val req = Request.Builder()
                .url("https://api.groq.com/openai/v1/models")
                .header("Authorization", "Bearer $apiKey")
                .get().build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (_: Exception) { false }
    }

    suspend fun validateGeminiKey(apiKey: String): Boolean = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext false
        try {
            val body = JSONObject().put("contents", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", "ping")))
            }))
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$GEMINI_MODEL:generateContent?key=$apiKey")
                .header("Content-Type", "application/json")
                .post(body.toString().toRequestBody(JSON))
                .build()
            client.newCall(req).execute().use { it.isSuccessful }
        } catch (_: Exception) { false }
    }
}
