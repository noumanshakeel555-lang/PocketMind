package com.arslan.llamachat.llm

import com.arslan.llamachat.ui.Message

enum class ChatTemplate {
    TINYLLAMA, LLAMA3, MISTRAL, CHATML, GEMMA
}

fun modelTemplate(key: String): ChatTemplate = when (key) {
    "llama31_8b", "llama32_3b", "openbiollm_8b", "business_llama32" -> ChatTemplate.LLAMA3

    "mistral", "mistral_nemo", "mathstral_7b", "biomistral_7b", "meditron_7b",
    "law_chat_7b", "law_chat_7b_small", "law_mistral_helper", "medicine_general_mistral",
    "business_mistral" -> ChatTemplate.MISTRAL

    "gemma2b", "codegemma_2b" -> ChatTemplate.GEMMA

    "qwen25_7b", "qwen25_3b", "deepseek_7b", "qwen25_coder_1_5b", "qwen25_coder_3b",
    "qwen25_math_1_5b", "qwen25_math_7b", "qwen_law_reasoner", "business_qwen3b" -> ChatTemplate.CHATML

    else -> ChatTemplate.TINYLLAMA
}

fun buildPrompt(
    modelKey: String,
    system: String,
    messages: List<Message>,
): String = when (modelTemplate(modelKey)) {

    ChatTemplate.LLAMA3 -> buildString {
        append("<|begin_of_text|>")
        append("<|start_header_id|>system<|end_header_id|>\n\n")
        append(system)
        append("<|eot_id|>")
        for (msg in messages) {
            val role = if (msg.role == "user") "user" else "assistant"
            append("<|start_header_id|>$role<|end_header_id|>\n\n")
            append(msg.content)
            append("<|eot_id|>")
        }
        append("<|start_header_id|>assistant<|end_header_id|>\n\n")
    }

    ChatTemplate.MISTRAL -> buildString {
        var first = true
        for (msg in messages) {
            if (msg.role == "user") {
                if (first) {
                    append("<s>[INST] $system\n${msg.content} [/INST]")
                    first = false
                } else {
                    append("[INST] ${msg.content} [/INST]")
                }
            } else {
                append(" ${msg.content}</s>")
            }
        }
        if (messages.none { it.role == "user" }) {
            append("<s>[INST] $system [/INST]")
        }
    }

    ChatTemplate.GEMMA -> buildString {
        append("<start_of_turn>system\n$system<end_of_turn>\n")
        for (msg in messages) {
            val role = if (msg.role == "user") "user" else "model"
            append("<start_of_turn>$role\n${msg.content}<end_of_turn>\n")
        }
        append("<start_of_turn>model\n")
    }

    ChatTemplate.CHATML -> buildString {
        append("<|im_start|>system\n$system<|im_end|>\n")
        for (msg in messages) {
            val role = if (msg.role == "user") "user" else "assistant"
            append("<|im_start|>$role\n${msg.content}<|im_end|>\n")
        }
        append("<|im_start|>assistant\n")
    }

    ChatTemplate.TINYLLAMA -> buildString {
        append("<|system|>\n$system\n")
        for (msg in messages) {
            val tag = if (msg.role == "user") "<|user|>" else "<|assistant|>"
            append("$tag\n${msg.content}\n")
        }
        append("<|assistant|>\n")
    }
}
