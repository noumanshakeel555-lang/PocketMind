package com.arslan.llamachat.llm

import android.app.ActivityManager
import android.content.Context
import android.os.Build

data class DeviceSpec(
    val totalRamMb: Long,
    val freeRamMb: Long,
    val abi: String,
)

enum class Compatibility {
    GREAT, OK, TIGHT, TOO_LARGE
}

fun getDeviceSpec(context: Context): DeviceSpec {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val info = ActivityManager.MemoryInfo()
    am.getMemoryInfo(info)
    val totalMb = info.totalMem / 1024 / 1024
    val freeMb = info.availMem / 1024 / 1024
    val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
    return DeviceSpec(totalMb, freeMb, abi)
}

fun getCompatibility(spec: DeviceSpec, model: ModelInfo): Compatibility {
    val free = spec.freeRamMb
    val needed = model.ramNeededMb
    return when {
        free >= needed * 1.4 -> Compatibility.GREAT
        free >= needed * 1.1 -> Compatibility.OK
        free >= needed * 0.85 -> Compatibility.TIGHT
        else -> Compatibility.TOO_LARGE
    }
}

fun compatibilityLabel(c: Compatibility): String = when (c) {
    Compatibility.GREAT -> "Runs great on your device"
    Compatibility.OK -> "Runs fine on your device"
    Compatibility.TIGHT -> "Tight on RAM — may be slow"
    Compatibility.TOO_LARGE -> "Not enough RAM"
}
