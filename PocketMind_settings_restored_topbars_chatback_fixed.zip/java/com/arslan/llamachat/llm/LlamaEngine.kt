package com.arslan.llamachat.llm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

interface TokenCallback {
    fun onToken(token: String)
    fun onDone()
}

data class LoadResult(
    val ok: Boolean,
    val error: String = "",
    val threads: Int = 0,
    val gpu: String = "cpu",
    val ctx: Int = 0,
)

object LlamaEngine {

    init { System.loadLibrary("llamachat") }

    private external fun loadModel(path: String, nCtx: Int, nThreads: Int, nBatch: Int, nGpuLayers: Int): String
    private external fun generate(prompt: String, maxTokens: Int, temperature: Float, topK: Int, topP: Float, callback: TokenCallback)
    private external fun setContextSize(nCtx: Int): String
    external fun stop()
    external fun freeModel()
    external fun getContextSize(): Int
    external fun getOptimalThreads(): Int
    external fun isVulkanAvailable(): Boolean

    suspend fun load(path: String, nCtx: Int = 2048, nBatch: Int = 512, nGpuLayers: Int = 64): LoadResult =
        withContext(Dispatchers.IO) {
            val raw = loadModel(path, nCtx, 0, nBatch, nGpuLayers)
            if (raw.startsWith("ok")) {
                val parts = raw.split("|").drop(1).associate {
                    val kv = it.split("="); kv[0] to kv.getOrElse(1) { "" }
                }
                LoadResult(
                    ok = true,
                    threads = parts["threads"]?.toIntOrNull() ?: 0,
                    gpu = parts["gpu"] ?: "cpu",
                    ctx = parts["ctx"]?.toIntOrNull() ?: nCtx,
                )
            } else {
                LoadResult(ok = false, error = raw)
            }
        }

    suspend fun changeContextSize(nCtx: Int): String =
        withContext(Dispatchers.IO) { setContextSize(nCtx) }

    suspend fun infer(
        prompt: String,
        maxTokens: Int = 2048,
        temperature: Float = 0.8f,
        topK: Int = 50,
        topP: Float = 0.95f,
        onToken: (String) -> Unit,
        onDone: () -> Unit,
    ) = withContext(Dispatchers.IO) {
        generate(prompt, maxTokens, temperature, topK, topP, object : TokenCallback {
            override fun onToken(token: String) = onToken(token)
            override fun onDone() = onDone()
        })
    }
}
