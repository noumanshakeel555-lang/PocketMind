package com.arslan.llamachat.image

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object ImageEngine {
    private val nativeLoadError: Throwable? = runCatching {
        System.loadLibrary("pocketmindimage")
    }.exceptionOrNull()

    private fun ensureNativeReady() {
        nativeLoadError?.let { error("Offline image engine is not available in this build: ${it.message ?: it::class.java.simpleName}") }
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private external fun generatePreviewNative(
        prompt: String,
        modelPath: String,
        width: Int,
        height: Int,
        seed: Int,
    ): IntArray?

    private external fun generateStableDiffusionNative(
        prompt: String,
        negativePrompt: String,
        modelPath: String,
        width: Int,
        height: Int,
        steps: Int,
        cfgScale: Float,
        seed: Int,
    ): IntArray?

    private external fun engineInfoNative(): String
    private external fun lastImageErrorNative(): String
    private external fun freeImageEngineNative()

    fun engineInfo(): String = nativeLoadError?.let {
        "Offline image engine unavailable: ${it.message ?: it::class.java.simpleName}"
    } ?: runCatching { engineInfoNative() }
        .getOrElse { "Image engine unavailable: ${it.message}" }

    fun lastError(): String = runCatching { lastImageErrorNative() }
        .getOrDefault("")
        .trim()

    fun free() {
        if (nativeLoadError == null) runCatching { freeImageEngineNative() }
    }

    suspend fun generatePreview(
        prompt: String,
        modelPath: String,
        size: Int,
        seed: Int,
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        runCatching {
            ensureNativeReady()
            val safeSize = size.coerceIn(128, 768)
            val pixels = generatePreviewNative(prompt, modelPath, safeSize, safeSize, seed)
                ?: error("Native image preview returned no pixels${lastError().toDisplaySuffix()}")
            Bitmap.createBitmap(pixels, safeSize, safeSize, Bitmap.Config.ARGB_8888)
        }
    }

    suspend fun generateImage(
        prompt: String,
        negativePrompt: String,
        modelPath: String,
        size: Int,
        steps: Int,
        cfgScale: Float,
        seed: Int,
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        runCatching {
            ensureNativeReady()
            val modelFile = File(modelPath)
            if (modelPath.isBlank()) error("No image model selected.")
            if (!modelFile.exists()) error("Selected image model file was not found. Re-select or re-import the model.")
            if (modelFile.length() <= 0L) error("Selected image model file is empty.")

            val safeSize = size.coerceIn(128, 384)
            val safeSteps = steps.coerceIn(1, 16)
            val safeCfg = cfgScale.coerceIn(1f, 12f)
            val safeSeed = if (seed <= 0) 42 else seed

            val pixels = generateStableDiffusionNative(
                prompt = prompt,
                negativePrompt = negativePrompt,
                modelPath = modelPath,
                width = safeSize,
                height = safeSize,
                steps = safeSteps,
                cfgScale = safeCfg,
                seed = safeSeed,
            ) ?: error("Image generation returned no image${lastError().toDisplaySuffix()}")

            Bitmap.createBitmap(pixels, safeSize, safeSize, Bitmap.Config.ARGB_8888)
        }
    }

    suspend fun generateOnlineImage(
        providerKey: String,
        remoteModelId: String,
        apiKey: String,
        prompt: String,
        negativePrompt: String,
        size: Int,
        steps: Int,
        seed: Int,
    ): Result<Bitmap> = withContext(Dispatchers.IO) {
        runCatching {
            when (providerKey.lowercase()) {
                "pollinations" -> generateViaPollinations(
                    model = remoteModelId,
                    prompt = prompt,
                    size = size,
                    seed = seed,
                )
                "huggingface" -> generateViaHuggingFace(
                    model = remoteModelId,
                    apiKey = apiKey,
                    prompt = prompt,
                    negativePrompt = negativePrompt,
                    size = size,
                    steps = steps,
                )
                "together" -> generateViaTogether(
                    model = remoteModelId,
                    apiKey = apiKey,
                    prompt = prompt,
                    negativePrompt = negativePrompt,
                    size = size,
                    steps = steps,
                    seed = seed,
                )
                else -> error("Unsupported image provider: $providerKey")
            }
        }
    }

    private fun generateViaPollinations(
        model: String,
        prompt: String,
        size: Int,
        seed: Int,
    ): Bitmap {
        val safeSize = size.coerceIn(256, 1024)
        val encodedPrompt = URLEncoder.encode(prompt, "UTF-8")
        val url = "https://image.pollinations.ai/prompt/$encodedPrompt?width=$safeSize&height=$safeSize&seed=$seed&nologo=true&model=$model"

        val request = Request.Builder()
            .url(url)
            .header("User-Agent", "PocketMind-Android")
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Pollinations failed: HTTP ${response.code}")
            val bytes = response.body?.bytes() ?: error("Pollinations returned empty response")
            return decodeBitmap(bytes)
        }
    }

    private fun generateViaHuggingFace(
        model: String,
        apiKey: String,
        prompt: String,
        negativePrompt: String,
        size: Int,
        steps: Int,
    ): Bitmap {
        if (apiKey.isBlank()) error("Hugging Face API key is required.")

        val safeSize = size.coerceIn(256, 1024)
        val safeSteps = steps.coerceIn(1, 12)

        val payload = JSONObject().apply {
            put("inputs", prompt)
            put("parameters", JSONObject().apply {
                put("width", safeSize)
                put("height", safeSize)
                put("num_inference_steps", safeSteps)
                if (negativePrompt.isNotBlank()) put("negative_prompt", negativePrompt)
            })
        }

        val request = Request.Builder()
            .url("https://router.huggingface.co/hf-inference/models/$model")
            .header("Authorization", "Bearer $apiKey")
            .header("Accept", "image/png")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val bodyBytes = response.body?.bytes() ?: error("Hugging Face returned empty response")

            if (!response.isSuccessful) {
                val text = runCatching { String(bodyBytes) }.getOrDefault("Unknown error")
                error("Hugging Face failed: HTTP ${response.code} - $text")
            }

            return decodeBitmap(bodyBytes)
        }
    }

    private fun generateViaTogether(
        model: String,
        apiKey: String,
        prompt: String,
        negativePrompt: String,
        size: Int,
        steps: Int,
        seed: Int,
    ): Bitmap {
        if (apiKey.isBlank()) error("Together AI API key is required.")

        val safeSize = size.coerceIn(256, 1024)
        val safeSteps = steps.coerceIn(1, 12)

        val payload = JSONObject().apply {
            put("model", model)
            put("prompt", prompt)
            if (model.contains("FLUX.1-schnell", ignoreCase = true)) {
                put("aspect_ratio", "1:1")
            } else {
                put("width", safeSize)
                put("height", safeSize)
            }
            put("steps", safeSteps)
            put("seed", seed)
            put("n", 1)
            put("response_format", "base64")
            if (negativePrompt.isNotBlank()) put("negative_prompt", negativePrompt)
        }

        val request = Request.Builder()
            .url("https://api.together.xyz/v1/images/generations")
            .header("Authorization", "Bearer $apiKey")
            .post(payload.toString().toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(request).execute().use { response ->
            val bodyText = response.body?.string() ?: error("Together AI returned empty response")

            if (!response.isSuccessful) {
                error("Together AI failed: HTTP ${response.code} - $bodyText")
            }

            val json = JSONObject(bodyText)
            val data = json.optJSONArray("data") ?: error("Together AI returned no image data")
            if (data.length() == 0) error("Together AI returned an empty image list")

            val item = data.getJSONObject(0)
            val b64 = item.optString("b64_json").ifBlank { item.optString("b64") }
            if (b64.isBlank()) error("Together AI response did not include image data")

            val bytes = Base64.decode(b64, Base64.DEFAULT)
            return decodeBitmap(bytes)
        }
    }

    private fun decodeBitmap(bytes: ByteArray): Bitmap {
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            ?: error("Could not decode generated image")
    }

    private fun String.toDisplaySuffix(): String {
        return if (isBlank()) "." else ": $this"
    }
}
