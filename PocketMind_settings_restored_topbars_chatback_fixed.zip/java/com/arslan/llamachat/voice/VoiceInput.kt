package com.arslan.llamachat.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

class VoiceInput(private val context: Context) {

    private var recognizer: SpeechRecognizer? = null
    private var isActive = false

    fun start(onResult: (String) -> Unit, onError: (String) -> Unit) {
        if (isActive) return
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            onError("Speech recognition not available on this device")
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        isActive = true

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle) {
                isActive = false
                val matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = matches?.firstOrNull { it.isNotBlank() } ?: ""
                if (text.isNotBlank()) onResult(text)
                else onError("No speech detected")
            }
            override fun onError(error: Int) {
                isActive = false
                onError(when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH        -> "No speech detected"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT  -> "Listening timed out"
                    SpeechRecognizer.ERROR_NETWORK         -> "Network error — check speech input availability"
                    SpeechRecognizer.ERROR_AUDIO           -> "Microphone error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission denied"
                    else -> "Speech error ($error)"
                })
            }
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })

        recognizer?.startListening(intent)
    }

    fun stop() {
        isActive = false
        recognizer?.stopListening()
        recognizer?.destroy()
        recognizer = null
    }
}
