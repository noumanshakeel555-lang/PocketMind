package com.arslan.llamachat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arslan.llamachat.llm.LlamaEngine
import com.arslan.llamachat.llm.ModelManager
import com.arslan.llamachat.llm.MODELS

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    vm: ChatViewModel,
    onSetupKeys: () -> Unit,
    onOpenCharacters: () -> Unit,
    onOpenStorage: () -> Unit = {},
    onOpenHelp: () -> Unit = {},
    onOpenHelpdesk: () -> Unit = {},
    onOpenSetupWizard: () -> Unit = {},
    onOpenStatus: () -> Unit = {},
    onOpenBackupRestore: () -> Unit = {},
    onOpenAbout: () -> Unit = {},
    onOpenWhatsNew: () -> Unit = {},
    onOpenPrivacy: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var showSystemPromptDialog by remember { mutableStateOf(false) }
    var systemPromptDraft by remember { mutableStateOf(state.systemPrompt) }
    val vulkanAvailable = remember { LlamaEngine.isVulkanAvailable() }

    if (showSystemPromptDialog) {
        AlertDialog(onDismissRequest = { showSystemPromptDialog = false },
            title = { Text("Custom System Prompt") },
            text = {
                OutlinedTextField(value = systemPromptDraft, onValueChange = { systemPromptDraft = it },
                    modifier = Modifier.fillMaxWidth().height(160.dp), label = { Text("System prompt") })
            },
            confirmButton = { Button(onClick = { vm.setCustomSystemPrompt(systemPromptDraft); showSystemPromptDialog = false }) { Text("Apply") } },
            dismissButton = { TextButton(onClick = { showSystemPromptDialog = false }) { Text("Cancel") } }
        )
    }

    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(title = { Text("Settings", fontWeight = FontWeight.Bold, fontSize = 20.sp) },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            windowInsets = WindowInsets(0))

        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                SettingsSection("Active Model") {
                    when {
                        state.activeOnlineProvider == "groq" -> ModelStatusRow("⚡", "Llama 3.1 70B via Groq", "Online · Instant", Color(0xFF00A67E))
                        state.activeOnlineProvider == "gemini" -> ModelStatusRow("⚡", "Gemini 1.5 Flash", "Online · Instant", Color(0xFF4285F4))
                        state.customGgufName.isNotBlank() -> ModelStatusRow("📁", state.customGgufName, state.loadInfo, MaterialTheme.colorScheme.primary)
                        state.loadedModel != null -> ModelStatusRow("✓", state.loadedModel!!.displayName, state.loadInfo, MaterialTheme.colorScheme.primary)
                        else -> Text("No model loaded. Go to Models tab.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            item {
                SettingsSection("Characters") {
                    Text("Characters give the AI a custom personality and voice.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = onOpenCharacters, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Person, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Manage Characters")
                    }
                }
            }

            item {
                SettingsSection("Online Models (Instant)") {
                    Text("Use online providers for fast responses. Requires internet and your provider API key; request content is sent directly to the provider you select.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("groq" to Pair("Groq", Color(0xFF00A67E)), "gemini" to Pair("Gemini", Color(0xFF4285F4))).forEach { (key, info) ->
                            val (label, color) = info
                            val active = state.activeOnlineProvider == key
                            val hasKey = if (key == "groq") state.groqApiKey.isNotBlank() else state.geminiApiKey.isNotBlank()
                            OutlinedButton(
                                onClick = { if (hasKey) vm.setOnlineProvider(if (active) "" else key) else onSetupKeys() },
                                modifier = Modifier.weight(1f),
                                colors = if (active) ButtonDefaults.outlinedButtonColors(containerColor = color.copy(0.12f)) else ButtonDefaults.outlinedButtonColors()
                            ) { Text(if (active) "✓ $label" else label, color = color, fontWeight = FontWeight.SemiBold) }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onSetupKeys, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Key, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Manage API Keys")
                    }
                }
            }

            item {
                SettingsSection("GPU Acceleration") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Vulkan GPU", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            Text(if (vulkanAvailable) "Supported on your device. Faster inference." else "Not supported on your device.",
                                style = MaterialTheme.typography.bodySmall, color = if (vulkanAvailable) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error)
                        }
                        Switch(checked = state.useVulkan && vulkanAvailable, onCheckedChange = { vm.setUseVulkan(it) }, enabled = vulkanAvailable)
                    }
                    if (state.useVulkan && vulkanAvailable) {
                        Spacer(Modifier.height(12.dp))
                        Text("GPU Layers: ${state.gpuLayers}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Text("More layers on GPU = faster but uses more VRAM. Start with 20.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Slider(value = state.gpuLayers.toFloat(), onValueChange = { vm.setGpuLayers(it.toInt()) },
                            valueRange = 0f..64f, steps = 63, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("0 (CPU only)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("64 (all GPU)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("Reload the model after changing GPU settings.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                }
            }

            item {
                SettingsSection("Memory & Context") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Low RAM Mode", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            Text("Forces 512 context. Helps 7B models on 4–6 GB phones.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = state.lowRamMode, onCheckedChange = { vm.setLowRamMode(it) })
                    }
                    if (!state.lowRamMode) {
                        Spacer(Modifier.height(16.dp))
                        Text("Context Size: ${state.contextSize} tokens", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Text("Larger = more conversation memory. Uses more RAM.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(512, 1024, 2048, 4096).forEach { size ->
                                FilterChip(selected = state.contextSize == size, onClick = { vm.setContextSize(size) }, label = { Text("$size") })
                            }
                        }
                    }
                }
            }

            item {
                SettingsSection("Response Length") {
                    Text("Max tokens: ${state.maxTokens}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Text("Higher = longer answers. Slower on local models.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Slider(value = state.maxTokens.toFloat(), onValueChange = { vm.setMaxTokens(it.toInt()) }, valueRange = 64f..2048f, steps = 30, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("64 (short)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("2048 (long)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            item {
                SettingsSection("Creativity") {
                    Text("Temperature: ${"%.2f".format(state.temperature)}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Text("Lower = focused. Higher = creative.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Slider(value = state.temperature, onValueChange = { vm.setTemperature(it) }, valueRange = 0.1f..2.0f, steps = 18, modifier = Modifier.fillMaxWidth())
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("0.1 (precise)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("2.0 (creative)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }

            item {
                SettingsSection("Voice & TTS") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Read responses aloud", style = MaterialTheme.typography.bodyMedium)
                            Text("Uses your device's TTS engine.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = state.ttsEnabled, onCheckedChange = { vm.toggleTts() })
                    }
                    if (state.ttsEnabled && state.availableVoices.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        Text("Voice: ${state.selectedVoiceName.ifBlank { "Default" }}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(6.dp))
                        var expanded by remember { mutableStateOf(false) }
                        ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                            OutlinedTextField(
                                value = state.selectedVoiceName.ifBlank { "Default" },
                                onValueChange = {},
                                readOnly = true,
                                modifier = Modifier.menuAnchor().fillMaxWidth(),
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                                shape = RoundedCornerShape(12.dp),
                            )
                            ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                DropdownMenuItem(text = { Text("Default") }, onClick = { vm.setVoice(""); expanded = false })
                                state.availableVoices.take(30).forEach { v ->
                                    DropdownMenuItem(text = { Text(v, style = MaterialTheme.typography.bodySmall) },
                                        onClick = { vm.setVoice(v); expanded = false })
                                }
                            }
                        }
                    }
                }
            }

            item {
                SettingsSection("Notifications") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Notify when response is ready", style = MaterialTheme.typography.bodyMedium)
                            Text("Get a notification when the AI finishes responding.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = state.notifyOnDone, onCheckedChange = { vm.setNotifyOnDone(it) })
                    }
                }
            }


            item {
                SettingsSection("System Prompt") {
                    Text("Customize the assistant instructions used for new responses.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = { systemPromptDraft = state.systemPrompt; showSystemPromptDialog = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Edit, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Edit System Prompt")
                    }
                }
            }

            item {
                SettingsSection("Storage") {
                    val downloaded = MODELS.filter { ModelManager.isDownloaded(context, it) }
                    val totalMb = downloaded.sumOf { ModelManager.modelFile(context, it).length() / 1024 / 1024 }
                    Text("Downloaded: ${if (totalMb > 1024) "${"%.1f".format(totalMb / 1024.0)} GB" else "$totalMb MB"}", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    downloaded.forEach { model ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(model.displayName, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                            Text(model.sizeDisplay, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }

            item {
                SettingsSection("Chat") {
                    Button(onClick = { vm.clearHistory() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.DeleteSweep, null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(8.dp))
                        Text("Clear current chat", color = MaterialTheme.colorScheme.error)
                    }
                }
            }


            item {
                SettingsSection("Help & App") {
                    OutlinedButton(onClick = onOpenSetupWizard, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Setup Wizard")
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onOpenHelp, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Help, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Use Cases & Help")
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onOpenHelpdesk, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.SupportAgent, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Helpdesk Assistant")
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onOpenStorage, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Storage, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Storage Manager")
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onOpenStatus, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.CheckCircle, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("App Status & Safety")
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = onOpenBackupRestore, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.SaveAlt, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Backup & Restore")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = onOpenAbout, modifier = Modifier.weight(1f)) { Text("About") }
                        OutlinedButton(onClick = onOpenPrivacy, modifier = Modifier.weight(1f)) { Text("Privacy") }
                        OutlinedButton(onClick = onOpenWhatsNew, modifier = Modifier.weight(1f)) { Text("What's New") }
                    }
                }
            }

            item {
                SettingsSection("About") {
                    Text("PocketMind", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                    Text("Offline AI — powered by llama.cpp${if (vulkanAvailable) " + Vulkan" else ""}",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("Online AI — Groq & Google Gemini", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}

@Composable
fun ModelStatusRow(icon: String, name: String, info: String, color: androidx.compose.ui.graphics.Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 18.sp)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            if (info.isNotBlank()) Text(info, style = MaterialTheme.typography.labelSmall, color = color)
        }
    }
}

@Composable
fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall,
                color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(bottom = 10.dp))
            content()
        }
    }
}
