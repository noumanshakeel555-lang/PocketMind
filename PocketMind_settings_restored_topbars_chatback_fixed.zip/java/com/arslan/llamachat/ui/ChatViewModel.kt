package com.arslan.llamachat.ui

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Base64
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.InputStream
import java.util.zip.ZipInputStream
import androidx.core.app.NotificationCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.arslan.llamachat.MainActivity
import com.arslan.llamachat.llm.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import org.json.JSONArray
import org.json.JSONObject

data class Message(val id: Long = System.nanoTime(), val role: String, val content: String, val characterId: String = "")
data class ChatSession(
    val id: Long,
    val modelKey: String,
    val title: String,
    val messages: List<Message>,
    val isPinned: Boolean = false,
    val updatedAt: Long = id,
)
data class DownloadStats(val progress: Float = 0f, val speedBytesPerSec: Long = 0L, val downloadedBytes: Long = 0L, val totalBytes: Long = 0L)

data class ChatAttachment(
    val name: String,
    val mimeType: String,
    val sizeBytes: Long = -1L,
    val textPreview: String = "",
    val isImage: Boolean = false,
    val imageBase64: String = "",
    val warning: String = "",
)

data class ChatState(
    val messages: List<Message> = emptyList(),
    val isGenerating: Boolean = false,
    val isThinking: Boolean = false,
    val streamingText: String = "",
    val loadedModel: ModelInfo? = null,
    val loadingModelKey: String? = null,
    val error: String? = null,
    val systemPrompt: String = DEFAULT_SYSTEM,
    val downloadingKeys: Set<String> = emptySet(),
    val downloadProgress: Map<String, Float> = emptyMap(),
    val downloadStats: Map<String, DownloadStats> = emptyMap(),
    val bookmarkedKeys: Set<String> = emptySet(),
    val chatSessions: List<ChatSession> = emptyList(),
    val ttsEnabled: Boolean = false,
    val isSpeaking: Boolean = false,
    val notifyOnDone: Boolean = false,
    val contextSize: Int = 2048,
    val maxTokens: Int = 2048,
    val temperature: Float = 0.8f,
    val topK: Int = 50,
    val topP: Float = 0.95f,
    val lowRamMode: Boolean = false,
    val downloadedKeys: Set<String> = emptySet(),
    val groqApiKey: String = "",
    val geminiApiKey: String = "",
    val huggingFaceApiKey: String = "",
    val togetherApiKey: String = "",
    val activeOnlineProvider: String = "",
    val activeCharacterId: String = "assistant",
    val customCharacters: List<Character> = emptyList(),
    val customGgufPaths: List<String> = emptyList(),
    val customGgufName: String = "",
    val availableVoices: List<String> = emptyList(),
    val selectedVoiceName: String = "",
    val useVulkan: Boolean = true,
    val gpuLayers: Int = 64,
    val loadInfo: String = "",
    val currentAttachment: ChatAttachment? = null,
    val isReadingAttachment: Boolean = false,
)

const val DEFAULT_SYSTEM = "You are a helpful, friendly, and concise AI assistant. Answer questions accurately and conversationally."

private const val NOTIF_CHANNEL = "pocketmind_ch"
private const val NOTIF_DOWNLOAD = 2001
private const val NOTIF_RESPONSE = 3001
private const val MAX_ATTACHMENT_CHARS = 24_000
private const val HEALTH_CHECK_PROMPT = "PocketMind quick health check: introduce yourself in 3 short bullet points, confirm this model is responding correctly, and mention one thing you can help me with."

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val _state = MutableStateFlow(ChatState())
    val state = _state.asStateFlow()

    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val historyMutex = Mutex()
    private val history = mutableListOf<Message>()
    private val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
    private var wakeLock: PowerManager.WakeLock? = null
    private var currentSessionId = System.currentTimeMillis()
    private val generationGate = AtomicBoolean(false)

    init {
        nm.createNotificationChannel(NotificationChannel(NOTIF_CHANNEL, "PocketMind", NotificationManager.IMPORTANCE_DEFAULT))
        tts = TextToSpeech(app) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _state.update { it.copy(isSpeaking = true) }
                    }

                    override fun onDone(utteranceId: String?) {
                        _state.update { it.copy(isSpeaking = false) }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        _state.update { it.copy(isSpeaking = false) }
                    }
                })
                ttsReady = true
                val voices = tts?.voices?.map { it.name }?.sorted() ?: emptyList()
                _state.update { it.copy(availableVoices = voices) }
            }
        }
        loadPersistedState(app)
    }

    private fun mainActivityIntent(): PendingIntent {
        val intent = Intent(getApplication(), MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        return PendingIntent.getActivity(getApplication(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun loadPersistedState(app: Application) {
        val ctx = app.applicationContext
        val customChars = CharacterManager.loadCustom(ctx)
        val savedPaths = Prefs.getString(ctx, "customGgufPaths", "")
            .split("|").filter { it.isNotBlank() && File(it).exists() }
        val savedSystemPrompt = Prefs.getString(ctx, "systemPrompt", DEFAULT_SYSTEM).let { saved ->
            if (saved.contains("Shakespeare", ignoreCase = true)) DEFAULT_SYSTEM else saved
        }
        val savedCharacterId = Prefs.getString(ctx, "activeCharacterId", "assistant").let { saved ->
            if (saved == "shakespeare") "assistant" else saved
        }
        if (savedSystemPrompt == DEFAULT_SYSTEM) Prefs.saveString(ctx, "systemPrompt", DEFAULT_SYSTEM)
        if (savedCharacterId == "assistant") Prefs.saveString(ctx, "activeCharacterId", "assistant")
        migrateMaxTokensTo2048(ctx)
        _state.update { it.copy(
            contextSize      = Prefs.getInt(ctx, "contextSize", 2048),
            maxTokens        = Prefs.getInt(ctx, "maxTokens", 2048).coerceIn(64, 2048),
            temperature      = Prefs.getFloat(ctx, "temperature", 0.8f),
            topK             = Prefs.getInt(ctx, "topK", 50),
            topP             = Prefs.getFloat(ctx, "topP", 0.95f),
            lowRamMode       = Prefs.getBool(ctx, "lowRamMode", false),
            ttsEnabled       = Prefs.getBool(ctx, "ttsEnabled", false),
            notifyOnDone     = Prefs.getBool(ctx, "notifyOnDone", false),
            bookmarkedKeys   = Prefs.loadBookmarks(ctx),
            chatSessions     = Prefs.loadSessions(ctx),
            systemPrompt     = savedSystemPrompt,
            downloadedKeys   = refreshDownloaded(ctx),
            groqApiKey       = Prefs.getString(ctx, "groqApiKey", ""),
            geminiApiKey     = Prefs.getString(ctx, "geminiApiKey", ""),
            huggingFaceApiKey = Prefs.getString(ctx, "hfImageApiKey", ""),
            togetherApiKey   = Prefs.getString(ctx, "togetherImageApiKey", ""),
            activeCharacterId = savedCharacterId,
            customCharacters = customChars,
            customGgufPaths  = savedPaths,
            selectedVoiceName = Prefs.getString(ctx, "selectedVoice", ""),
            useVulkan        = Prefs.getBool(ctx, "useVulkan", true),
            gpuLayers        = Prefs.getInt(ctx, "gpuLayers", 64),
        )}
    }


    private fun migrateMaxTokensTo2048(ctx: Context) {
        val migrationKey = "maxTokens2048MigrationDone"
        if (!Prefs.getBool(ctx, migrationKey, false)) {
            val saved = Prefs.getInt(ctx, "maxTokens", 1024)
            if (saved <= 1024) Prefs.saveInt(ctx, "maxTokens", 2048)
            Prefs.saveBool(ctx, migrationKey, true)
        }
    }

    private fun refreshDownloaded(ctx: Context): Set<String> =
        MODELS.filter { ModelManager.isDownloaded(ctx, it) }.map { it.key }.toSet()

    fun refreshDownloadedModels() {
        val ctx = getApplication<Application>().applicationContext
        _state.update { it.copy(downloadedKeys = refreshDownloaded(ctx)) }
    }

    fun startDownload(model: ModelInfo) {
        if (_state.value.downloadingKeys.contains(model.key)) return
        _state.update { it.copy(
            downloadingKeys = it.downloadingKeys + model.key,
            downloadProgress = it.downloadProgress + (model.key to 0f),
            downloadStats = it.downloadStats + (model.key to DownloadStats()),
            error = null, downloadedKeys = it.downloadedKeys - model.key,
        )}
        if (wakeLock?.isHeld != true) {
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "PocketMind::Download")
            wakeLock?.acquire(6 * 60 * 60 * 1000L)
        }
        viewModelScope.launch(Dispatchers.IO) {
            var lastTime = System.currentTimeMillis(); var lastBytes = 0L
            val result = ModelManager.download(getApplication(), model) { progress, downloaded, total ->
                val now = System.currentTimeMillis(); val dt = (now - lastTime).coerceAtLeast(1)
                val speed = if (dt > 300) { val s = (downloaded - lastBytes) * 1000L / dt; lastTime = now; lastBytes = downloaded; s }
                else _state.value.downloadStats[model.key]?.speedBytesPerSec ?: 0L
                _state.update { it.copy(
                    downloadProgress = it.downloadProgress + (model.key to progress),
                    downloadStats = it.downloadStats + (model.key to DownloadStats(progress, speed, downloaded, total)),
                )}
                showDownloadNotif(model.displayName, progress, speed)
            }
            val ctx = getApplication<Application>().applicationContext
            _state.update { it.copy(
                downloadingKeys = it.downloadingKeys - model.key,
                downloadProgress = it.downloadProgress - model.key,
                downloadStats = it.downloadStats - model.key,
                downloadedKeys = refreshDownloaded(ctx),
                error = result.exceptionOrNull()?.message?.let { m -> if (m == "Cancelled") null else "Download failed: $m" },
            )}
            nm.cancel(NOTIF_DOWNLOAD)
            if (_state.value.downloadingKeys.isEmpty()) { wakeLock?.release(); wakeLock = null }
        }
    }

    fun cancelDownload(key: String) { ModelManager.cancelDownload(key) }

    private fun showDownloadNotif(name: String, progress: Float, speedBps: Long) {
        val notif = NotificationCompat.Builder(getApplication(), NOTIF_CHANNEL)
            .setContentTitle("Downloading $name")
            .setContentText("${(progress * 100).toInt()}%  ·  ${formatSpeed(speedBps)}")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setProgress(100, (progress * 100).toInt(), false)
            .setContentIntent(mainActivityIntent()).setOngoing(true).setOnlyAlertOnce(true).build()
        nm.notify(NOTIF_DOWNLOAD, notif)
    }

    private fun showResponseNotif() {
        val notif = NotificationCompat.Builder(getApplication(), NOTIF_CHANNEL)
            .setContentTitle("PocketMind").setContentText("Response ready — tap to view")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(mainActivityIntent()).setAutoCancel(true).build()
        nm.notify(NOTIF_RESPONSE, notif)
    }

    private fun beginFreshConversation() {
        stopVoiceReply()
        if (history.isNotEmpty()) autoSaveSession()
        history.clear()
        currentSessionId = System.currentTimeMillis()
        _state.update {
            it.copy(
                messages = emptyList(),
                streamingText = "",
                isGenerating = false,
                isThinking = false,
            )
        }
    }

    private suspend fun loadWithSafeGpuFallback(path: String, ctx: Int, requestedGpuLayers: Int): LoadResult {
        val first = LlamaEngine.load(path, ctx, 512, requestedGpuLayers)
        if (first.ok || requestedGpuLayers <= 0) return first
        val fallback = LlamaEngine.load(path, ctx, 512, 0)
        return if (fallback.ok) fallback.copy(gpu = "cpu (GPU fallback)") else first
    }

    fun loadModel(model: ModelInfo) {
        _state.update { it.copy(activeOnlineProvider = "") }
        viewModelScope.launch {
            _state.update { it.copy(loadingModelKey = model.key, error = null) }
            val ctx = if (_state.value.lowRamMode) 512 else _state.value.contextSize
            val gpu = if (_state.value.useVulkan && LlamaEngine.isVulkanAvailable()) _state.value.gpuLayers else 0
            val path = ModelManager.modelFile(getApplication(), model).absolutePath
            val result = loadWithSafeGpuFallback(path, ctx, gpu)
            if (result.ok) {
                beginFreshConversation()
                _state.update { it.copy(loadingModelKey = null, loadedModel = model, customGgufName = "",
                    loadInfo = "Threads: ${result.threads} · GPU: ${result.gpu} · Ctx: ${result.ctx}") }
            } else {
                val friendly = when {
                    result.error.startsWith("CORRUPT") -> "File corrupt — deleted. Re-download."
                    result.error.startsWith("OOM")     -> "Not enough RAM. Enable Low RAM Mode."
                    result.error.startsWith("BUSY")    -> "Stop current response first."
                    else -> result.error
                }
                if (result.error.startsWith("CORRUPT")) { ModelManager.delete(getApplication(), model); refreshDownloadedModels() }
                _state.update { it.copy(loadingModelKey = null, error = friendly) }
            }
        }
    }

    fun loadCustomGguf(context: Context, uri: Uri, name: String, onProgress: (Float) -> Unit, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val dest = File(context.filesDir, "models/$name")
                dest.parentFile?.mkdirs()
                val input = context.contentResolver.openInputStream(uri) ?: run { onDone(false, "Cannot open file"); return@launch }
                val total = context.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val idx = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    c.moveToFirst(); if (idx >= 0) c.getLong(idx) else -1L
                } ?: -1L
                var written = 0L
                input.use { inp -> dest.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024); var n: Int
                    while (inp.read(buf).also { n = it } != -1) {
                        out.write(buf, 0, n); written += n
                        if (total > 0) onProgress(written.toFloat() / total)
                    }
                }}
                val paths = (_state.value.customGgufPaths + dest.absolutePath).distinct().takeLast(10)
                _state.update { it.copy(customGgufPaths = paths) }
                Prefs.saveString(context, "customGgufPaths", paths.joinToString("|"))
                loadCustomGgufDirect(dest.absolutePath)
                onDone(true, "")
            } catch (e: Exception) { onDone(false, e.message ?: "Copy failed") }
        }
    }

    fun loadCustomGgufDirect(path: String) {
        viewModelScope.launch {
            _state.update { it.copy(loadingModelKey = "custom", error = null, activeOnlineProvider = "") }
            val ctx = if (_state.value.lowRamMode) 512 else _state.value.contextSize
            val gpu = if (_state.value.useVulkan && LlamaEngine.isVulkanAvailable()) _state.value.gpuLayers else 0
            val result = loadWithSafeGpuFallback(path, ctx, gpu)
            if (result.ok) {
                beginFreshConversation()
                _state.update { it.copy(loadingModelKey = null, loadedModel = null,
                    customGgufName = File(path).name,
                    loadInfo = "Threads: ${result.threads} · GPU: ${result.gpu} · Ctx: ${result.ctx}") }
            } else {
                _state.update { it.copy(loadingModelKey = null, error = result.error) }
            }
        }
    }

    fun setOnlineProvider(provider: String) {
        if (provider != _state.value.activeOnlineProvider) {
            beginFreshConversation()
        }
        LlamaEngine.freeModel()
        _state.update { it.copy(activeOnlineProvider = provider, loadedModel = null, customGgufName = "") }
    }


    fun testActiveModel() {
        val snap = _state.value
        if (snap.isGenerating) {
            _state.update { it.copy(error = "A response is already running. Stop it before testing another model.") }
            return
        }
        val ready = snap.activeOnlineProvider.isNotBlank() || snap.loadedModel != null || snap.customGgufName.isNotBlank()
        if (!ready) {
            _state.update { it.copy(error = "Choose an online model or load an offline model before running a health check.") }
            return
        }
        send(HEALTH_CHECK_PROMPT)
    }

    fun testOnlineProvider(provider: String) {
        refreshOnlineProviderKeys()
        val key = onlineApiKeyFor(provider)
        if (key.isBlank()) {
            _state.update { it.copy(error = "Add the ${onlineProviderLabel(provider)} API key before testing this online model.") }
            return
        }
        if (_state.value.isGenerating) {
            _state.update { it.copy(error = "A response is already running. Stop it before testing another model.") }
            return
        }
        if (_state.value.activeOnlineProvider != provider) {
            setOnlineProvider(provider)
        }
        send(HEALTH_CHECK_PROMPT)
    }

    private fun onlineApiKeyFor(provider: String): String = when (provider) {
        "groq" -> _state.value.groqApiKey
        "gemini" -> _state.value.geminiApiKey
        "hf_qwen_coder", "hf_mistral" -> _state.value.huggingFaceApiKey.ifBlank { Prefs.getString(getApplication(), "hfImageApiKey", "") }
        "together_llama", "together_qwen", "together_mixtral" -> _state.value.togetherApiKey.ifBlank { Prefs.getString(getApplication(), "togetherImageApiKey", "") }
        else -> ""
    }

    private fun onlineProviderLabel(provider: String): String = when (provider) {
        "groq" -> "Groq"
        "gemini" -> "Gemini"
        "hf_qwen_coder", "hf_mistral" -> "Hugging Face"
        "together_llama", "together_qwen", "together_mixtral" -> "Together AI"
        else -> provider.replaceFirstChar { ch -> ch.uppercase() }
    }

    private fun isHuggingFaceProvider(provider: String): Boolean = provider == "hf_qwen_coder" || provider == "hf_mistral"
    private fun isTogetherProvider(provider: String): Boolean = provider == "together_llama" || provider == "together_qwen" || provider == "together_mixtral"

    fun loadAndTestModel(model: ModelInfo) {
        if (_state.value.isGenerating) {
            _state.update { it.copy(error = "A response is already running. Stop it before testing another model.") }
            return
        }
        _state.update { it.copy(activeOnlineProvider = "", loadingModelKey = model.key, error = null) }
        viewModelScope.launch {
            val ctx = if (_state.value.lowRamMode) 512 else _state.value.contextSize
            val gpu = if (_state.value.useVulkan && LlamaEngine.isVulkanAvailable()) _state.value.gpuLayers else 0
            val path = ModelManager.modelFile(getApplication(), model).absolutePath
            val result = loadWithSafeGpuFallback(path, ctx, gpu)
            if (result.ok) {
                beginFreshConversation()
                _state.update { it.copy(
                    loadingModelKey = null,
                    loadedModel = model,
                    customGgufName = "",
                    activeOnlineProvider = "",
                    loadInfo = "Threads: ${result.threads} · GPU: ${result.gpu} · Ctx: ${result.ctx}"
                ) }
                send(HEALTH_CHECK_PROMPT)
            } else {
                val friendly = when {
                    result.error.startsWith("CORRUPT") -> "File corrupt — deleted. Re-download."
                    result.error.startsWith("OOM")     -> "Not enough RAM. Enable Low RAM Mode."
                    result.error.startsWith("BUSY")    -> "Stop current response first."
                    else -> result.error
                }
                if (result.error.startsWith("CORRUPT")) {
                    ModelManager.delete(getApplication(), model)
                    refreshDownloadedModels()
                }
                _state.update { it.copy(loadingModelKey = null, error = "Health check failed: $friendly") }
            }
        }
    }

    fun setCharacter(character: Character) {
        Prefs.saveString(getApplication(), "activeCharacterId", character.id)
        Prefs.saveString(getApplication(), "systemPrompt", character.systemPrompt)
        _state.update { it.copy(activeCharacterId = character.id, systemPrompt = character.systemPrompt) }
        beginFreshConversation()
        if (character.voiceName.isNotBlank()) setVoice(character.voiceName)
    }

    fun saveCharacter(character: Character) {
        val existing = _state.value.customCharacters.toMutableList()
        val idx = existing.indexOfFirst { it.id == character.id }
        if (idx >= 0) existing[idx] = character else existing.add(character)
        _state.update { it.copy(customCharacters = existing) }
        CharacterManager.saveCustom(getApplication(), existing)
    }

    fun deleteCharacter(id: String) {
        val updated = _state.value.customCharacters.filter { it.id != id }
        _state.update { it.copy(customCharacters = updated) }
        CharacterManager.saveCustom(getApplication(), updated)
    }

    fun setVoice(voiceName: String) {
        Prefs.saveString(getApplication(), "selectedVoice", voiceName)
        _state.update { it.copy(selectedVoiceName = voiceName) }
        if (ttsReady && voiceName.isNotBlank()) {
            val voice = tts?.voices?.find { it.name == voiceName }
            if (voice != null) tts?.voice = voice
        }
    }

    fun setUseVulkan(on: Boolean) {
        Prefs.saveBool(getApplication(), "useVulkan", on)
        _state.update { it.copy(useVulkan = on) }
    }

    fun setGpuLayers(n: Int) {
        Prefs.saveInt(getApplication(), "gpuLayers", n)
        _state.update { it.copy(gpuLayers = n) }
    }

    fun validateAndSaveGroqKey(key: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val ok = OnlineEngine.validateGroqKey(key)
            if (ok) { Prefs.saveString(getApplication(), "groqApiKey", key); _state.update { it.copy(groqApiKey = key) } }
            onResult(ok)
        }
    }

    fun validateAndSaveGeminiKey(key: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val clean = key.trim()
            val ok = OnlineEngine.validateGeminiKey(clean)
            if (ok) { Prefs.saveString(getApplication(), "geminiApiKey", clean); _state.update { it.copy(geminiApiKey = clean) } }
            onResult(ok)
        }
    }

    fun validateAndSaveHuggingFaceKey(key: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val clean = key.trim()
            val ok = OnlineEngine.validateHuggingFaceKey(clean)
            if (ok) { Prefs.saveString(getApplication(), "hfImageApiKey", clean); _state.update { it.copy(huggingFaceApiKey = clean) } }
            onResult(ok)
        }
    }

    fun validateAndSaveTogetherKey(key: String, onResult: (Boolean) -> Unit) {
        viewModelScope.launch {
            val clean = key.trim()
            val ok = OnlineEngine.validateTogetherKey(clean)
            if (ok) { Prefs.saveString(getApplication(), "togetherImageApiKey", clean); _state.update { it.copy(togetherApiKey = clean) } }
            onResult(ok)
        }
    }

    fun clearGroqKey() { Prefs.saveString(getApplication(), "groqApiKey", ""); _state.update { it.copy(groqApiKey = "") } }
    fun clearGeminiKey() { Prefs.saveString(getApplication(), "geminiApiKey", ""); _state.update { it.copy(geminiApiKey = "") } }

    fun refreshOnlineProviderKeys() {
        _state.update { it.copy(
            huggingFaceApiKey = Prefs.getString(getApplication(), "hfImageApiKey", ""),
            togetherApiKey = Prefs.getString(getApplication(), "togetherImageApiKey", ""),
        ) }
    }

    fun saveHuggingFaceKey(key: String) {
        val clean = key.trim()
        Prefs.saveString(getApplication(), "hfImageApiKey", clean)
        _state.update { it.copy(huggingFaceApiKey = clean) }
    }

    fun saveTogetherKey(key: String) {
        val clean = key.trim()
        Prefs.saveString(getApplication(), "togetherImageApiKey", clean)
        _state.update { it.copy(togetherApiKey = clean) }
    }

    fun setContextSize(size: Int) {
        Prefs.saveInt(getApplication(), "contextSize", size)
        _state.update { it.copy(contextSize = size) }
        if (_state.value.loadedModel != null || _state.value.customGgufName.isNotBlank())
            viewModelScope.launch { LlamaEngine.changeContextSize(size) }
    }

    fun setMaxTokens(n: Int) {
        val safe = n.coerceIn(64, 2048)
        Prefs.saveInt(getApplication(), "maxTokens", safe)
        _state.update { it.copy(maxTokens = safe) }
    }
    fun setTemperature(t: Float) { Prefs.saveFloat(getApplication(), "temperature", t); _state.update { it.copy(temperature = t) } }
    fun setTopK(k: Int) { Prefs.saveInt(getApplication(), "topK", k); _state.update { it.copy(topK = k) } }
    fun setTopP(p: Float) { Prefs.saveFloat(getApplication(), "topP", p); _state.update { it.copy(topP = p) } }

    fun setLowRamMode(on: Boolean) {
        Prefs.saveBool(getApplication(), "lowRamMode", on)
        _state.update { it.copy(lowRamMode = on) }
        if (_state.value.loadedModel != null)
            viewModelScope.launch { LlamaEngine.changeContextSize(if (on) 512 else _state.value.contextSize) }
    }

    fun toggleTts() {
        val v = !_state.value.ttsEnabled
        if (!v) stopVoiceReply()
        Prefs.saveBool(getApplication(), "ttsEnabled", v)
        _state.update { it.copy(ttsEnabled = v) }
    }

    fun stopVoiceReply() {
        tts?.stop()
        _state.update { it.copy(isSpeaking = false) }
    }
    fun setNotifyOnDone(on: Boolean) { Prefs.saveBool(getApplication(), "notifyOnDone", on); _state.update { it.copy(notifyOnDone = on) } }
    fun dismissError() = _state.update { it.copy(error = null) }


    fun attachFile(context: Context, uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            _state.update { it.copy(isReadingAttachment = true, error = null) }
            val attachment = readAttachment(context, uri)
            _state.update { it.copy(currentAttachment = attachment, isReadingAttachment = false) }
        }
    }

    fun clearAttachment() {
        _state.update { it.copy(currentAttachment = null, isReadingAttachment = false) }
    }

    private fun readAttachment(context: Context, uri: Uri): ChatAttachment {
        val resolver = context.contentResolver
        var name = "attachment"
        var size = -1L

        resolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIndex >= 0) name = cursor.getString(nameIndex) ?: name
                if (sizeIndex >= 0) size = cursor.getLong(sizeIndex)
            }
        }

        val mime = resolver.getType(uri) ?: guessMimeFromName(name)
        val lower = name.lowercase()
        val isImage = mime.startsWith("image/") ||
            lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg") ||
            lower.endsWith(".webp") || lower.endsWith(".gif")

        if (isImage) {
            return try {
                val maxImageBytes = 4 * 1024 * 1024
                val bytes = resolver.openInputStream(uri)?.use { input ->
                    val output = ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val read = input.read(buffer)
                        if (read == -1) break
                        total += read
                        if (total > maxImageBytes) break
                        output.write(buffer, 0, read)
                    }
                    if (total > maxImageBytes) null else output.toByteArray()
                }

                ChatAttachment(
                    name = name,
                    mimeType = mime,
                    sizeBytes = size,
                    isImage = true,
                    imageBase64 = bytes?.let { Base64.encodeToString(it, Base64.NO_WRAP) } ?: "",
                    warning = if (bytes == null) {
                        "Image is larger than 4 MB, so it will be attached as a note only. Use a smaller image for Gemini vision analysis."
                    } else {
                        when (_state.value.activeOnlineProvider) {
                            "gemini" -> "Image ready. Gemini 2.5 Flash can analyze this photo directly."
                            "groq" -> "Image ready. Groq will automatically use Llama 4 Scout Vision for this photo."
                            else -> "Image attached, but this offline text model cannot see image pixels yet. It will receive only this attachment note. Offline photo understanding needs a local vision model phase; PDF, DOCX, and text files already work."
                        }
                    }
                )
            } catch (e: Exception) {
                ChatAttachment(
                    name = name,
                    mimeType = mime,
                    sizeBytes = size,
                    isImage = true,
                    warning = "Could not read this image: ${e.message ?: "unknown error"}"
                )
            }
        }

        val isPdf = mime == "application/pdf" || lower.endsWith(".pdf")
        val isDocx = mime == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" || lower.endsWith(".docx")

        if (isPdf) {
            return try {
                val text = resolver.openInputStream(uri)?.use { input ->
                    extractPdfText(context, input)
                }.orEmpty()
                ChatAttachment(
                    name = name,
                    mimeType = mime,
                    sizeBytes = size,
                    textPreview = trimAttachmentText(text),
                    warning = pdfDocWarning(text, size)
                )
            } catch (e: Exception) {
                ChatAttachment(
                    name = name,
                    mimeType = mime,
                    sizeBytes = size,
                    warning = "Could not extract PDF text: ${e.message ?: "unknown error"}. Scanned/image-only PDFs need OCR, which is a later phase."
                )
            }
        }

        if (isDocx) {
            return try {
                val text = resolver.openInputStream(uri)?.use { input ->
                    extractDocxText(input)
                }.orEmpty()
                ChatAttachment(
                    name = name,
                    mimeType = mime,
                    sizeBytes = size,
                    textPreview = trimAttachmentText(text),
                    warning = docxWarning(text, size)
                )
            } catch (e: Exception) {
                ChatAttachment(
                    name = name,
                    mimeType = mime,
                    sizeBytes = size,
                    warning = "Could not extract DOCX text: ${e.message ?: "unknown error"}."
                )
            }
        }

        val canReadText = mime.startsWith("text/") ||
            lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".csv") ||
            lower.endsWith(".json") || lower.endsWith(".xml") || lower.endsWith(".html") ||
            lower.endsWith(".kt") || lower.endsWith(".java") || lower.endsWith(".py") ||
            lower.endsWith(".js") || lower.endsWith(".ts") || lower.endsWith(".cpp") ||
            lower.endsWith(".c") || lower.endsWith(".h") || lower.endsWith(".log")

        if (!canReadText) {
            return ChatAttachment(
                name = name,
                mimeType = mime,
                sizeBytes = size,
                warning = "File attached, but text extraction is not enabled for this file type yet. TXT, MD, CSV, JSON, code, log, PDF, and DOCX files work now."
            )
        }

        return try {
            val text = resolver.openInputStream(uri)?.use { input ->
                readPlainTextAttachment(input)
            }.orEmpty()

            ChatAttachment(
                name = name,
                mimeType = mime,
                sizeBytes = size,
                textPreview = trimAttachmentText(text),
                warning = if (text.length > MAX_ATTACHMENT_CHARS) "Large file attached. I included the first ${MAX_ATTACHMENT_CHARS / 1000}K characters so the model stays stable." else ""
            )
        } catch (e: Exception) {
            ChatAttachment(
                name = name,
                mimeType = mime,
                sizeBytes = size,
                warning = "Could not read this file: ${e.message ?: "unknown error"}"
            )
        }
    }

    private fun readPlainTextAttachment(input: InputStream): String {
        val maxBytes = MAX_ATTACHMENT_CHARS * 2
        val buffer = ByteArray(4096)
        val output = ByteArrayOutputStream()
        var total = 0
        while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            val allowed = minOf(read, maxBytes - total)
            if (allowed > 0) output.write(buffer, 0, allowed)
            total += read
            if (total >= maxBytes) break
        }
        return output.toString(Charsets.UTF_8.name())
    }

    private fun extractPdfText(context: Context, input: InputStream): String {
        PDFBoxResourceLoader.init(context.applicationContext)
        PDDocument.load(input).use { document ->
            val stripper = PDFTextStripper()
            stripper.sortByPosition = true
            stripper.startPage = 1
            stripper.endPage = minOf(document.numberOfPages, 40)
            return stripper.getText(document).orEmpty()
        }
    }

    private fun extractDocxText(input: InputStream): String {
        val out = StringBuilder()
        ZipInputStream(input).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (!entry.isDirectory && entry.name == "word/document.xml") {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    out.append(docxXmlToText(xml))
                    break
                }
                zip.closeEntry()
            }
        }
        return out.toString()
    }

    private fun docxXmlToText(xml: String): String {
        return xml
            .replace("</w:p>", "\n")
            .replace("</w:tr>", "\n")
            .replace("</w:tc>", "\t")
            .replace(Regex("<[^>]+>"), "")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace("&quot;", "\"")
            .replace("&apos;", "'")
            .lines()
            .joinToString("\n") { it.trim() }
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()
    }

    private fun trimAttachmentText(text: String): String {
        val cleaned = text.replace("\u0000", "").trim()
        return if (cleaned.length <= MAX_ATTACHMENT_CHARS) cleaned else cleaned.take(MAX_ATTACHMENT_CHARS)
    }

    private fun pdfDocWarning(text: String, size: Long): String {
        if (text.isBlank()) return "No readable text was found in this PDF. It may be scanned/image-only, which needs OCR in a later phase."
        return buildString {
            append("PDF text extracted. Offline and online text models can analyze it now.")
            if (text.length > MAX_ATTACHMENT_CHARS) append(" Large PDF: included the first ${MAX_ATTACHMENT_CHARS / 1000}K characters for stability.")
            if (size > 0) append(" File size: ${formatAttachmentBytes(size)}.")
        }
    }

    private fun docxWarning(text: String, size: Long): String {
        if (text.isBlank()) return "No readable text was found in this DOCX."
        return buildString {
            append("DOCX text extracted. Offline and online text models can analyze it now.")
            if (text.length > MAX_ATTACHMENT_CHARS) append(" Large DOCX: included the first ${MAX_ATTACHMENT_CHARS / 1000}K characters for stability.")
            if (size > 0) append(" File size: ${formatAttachmentBytes(size)}.")
        }
    }

    private fun guessMimeFromName(name: String): String {
        val lower = name.lowercase()
        return when {
            lower.endsWith(".txt") -> "text/plain"
            lower.endsWith(".md") -> "text/markdown"
            lower.endsWith(".csv") -> "text/csv"
            lower.endsWith(".json") -> "application/json"
            lower.endsWith(".xml") -> "text/xml"
            lower.endsWith(".png") -> "image/png"
            lower.endsWith(".jpg") || lower.endsWith(".jpeg") -> "image/jpeg"
            lower.endsWith(".webp") -> "image/webp"
            lower.endsWith(".pdf") -> "application/pdf"
            lower.endsWith(".docx") -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            else -> "application/octet-stream"
        }
    }

    private fun buildUserTextWithAttachment(userText: String, attachment: ChatAttachment?): String {
        val cleanText = userText.trim()
        if (attachment == null) return cleanText

        val sizeLabel = if (attachment.sizeBytes > 0) " · ${formatAttachmentBytes(attachment.sizeBytes)}" else ""
        val header = buildString {
            append(cleanText.ifBlank { "Please analyze the attached file." })
            append("\n\n[Attached file: ${attachment.name} (${attachment.mimeType}$sizeLabel)]")
        }

        return when {
            attachment.textPreview.isNotBlank() -> header +
                "\n\nFile content extracted for the model:\n```\n${attachment.textPreview}\n```" +
                if (attachment.warning.isNotBlank()) "\n\nNote: ${attachment.warning}" else ""
            attachment.isImage -> header +
                "\n\nImage attachment note: ${attachment.warning}"
            else -> header +
                "\n\nAttachment note: ${attachment.warning.ifBlank { "No readable text was extracted from this file." }}"
        }
    }


    private fun sanitizeGeneratedResponse(raw: String): String {
        if (raw.isBlank()) return raw.trim()

        var text = raw
            .replace("\u0000", "")
            .replace("<|eot_id|>", "")
            .replace("<|im_end|>", "")
            .replace("<end_of_turn>", "")
            .replace("</s>", "")
            .trim()

        val assistantMarkers = listOf(
            "<|assistant|>", "<|ASSISTANT|>", "<|asssistant|>",
            "<|im_start|>assistant",
            "<|start_header_id|>assistant<|end_header_id|>",
            "<start_of_turn>model", "<start_of_turn>assistant"
        )
        val userOrSystemMarkers = listOf(
            "<|user|>", "<|USER|>", "<|human|>", "<|system|>", "<|SYSTEM|>",
            "<|im_start|>user", "<|im_start|>system",
            "<|start_header_id|>user<|end_header_id|>",
            "<|start_header_id|>system<|end_header_id|>",
            "<start_of_turn>user", "<start_of_turn>system"
        )

        // Some small local models echo the whole prompt first, for example:
        // <|USER|> question ... <|ASSISTANT|> answer.
        // Keep only the content after the last assistant marker instead of showing the prompt back to the user.
        val lastAssistantMarker = assistantMarkers
            .map { marker -> text.indexOf(marker, ignoreCase = true).let { if (it >= 0) it to marker.length else null } }
            .filterNotNull()
            .maxByOrNull { it.first }
        if (lastAssistantMarker != null) {
            text = text.substring(lastAssistantMarker.first + lastAssistantMarker.second).trim()
        }

        // Strip repeated leading role labels without deleting the actual answer.
        repeat(4) {
            text = text
                .replace(Regex("(?is)^\\s*(assistant|asssistant|ai|model)\\s*:\\s*"), "")
                .replace(Regex("(?is)^\\s*<\\|assistant\\|>\\s*"), "")
                .replace(Regex("(?is)^\\s*<start_of_turn>\\s*(assistant|model)\\s*"), "")
                .trimStart()
        }

        // If the model starts a new turn after answering, cut there.
        val stopRegexes = listOf(
            Regex("(?is)\\n\\s*(user|human|system)\\s*:\\s*"),
            Regex("(?is)<\\|\\s*(user|human|system)\\s*\\|>"),
            Regex("(?is)<\\|im_start\\|>\\s*(user|system)"),
            Regex("(?is)<\\|start_header_id\\|>\\s*(user|system)\\s*<\\|end_header_id\\|>"),
            Regex("(?is)<start_of_turn>\\s*(user|system)")
        )
        val stopIndex = stopRegexes.mapNotNull { it.find(text)?.range?.first }.minOrNull()
        if (stopIndex != null && stopIndex >= 0) text = text.take(stopIndex)

        // Remove any leftover special-token lines.
        text = text.lines()
            .filterNot { line ->
                val t = line.trim()
                t.equals("<|USER|>", true) || t.equals("<|ASSISTANT|>", true) ||
                    t.equals("<|user|>", true) || t.equals("<|assistant|>", true) ||
                    t.equals("<|system|>", true)
            }
            .joinToString("\n")

        userOrSystemMarkers.forEach { marker ->
            val index = text.indexOf(marker, ignoreCase = true)
            if (index > 0) text = text.take(index)
        }

        return text.replace(Regex("\\n{4,}"), "\n\n\n").trim()
    }


    private fun isFormattingOnlyResponse(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.isBlank()) return true
        val meaningful = trimmed.replace(Regex("""[\s*_`~•\-]+"""), "")
        return meaningful.isBlank()
    }

    private fun failGeneration(message: String) {
        generationGate.set(false)
        _state.update { it.copy(isGenerating = false, isThinking = false, streamingText = "", error = message) }
    }

    private fun shouldStopAfterAnswer(raw: String, cleaned: String): Boolean {
        if (cleaned.isBlank()) return false
        val start = raw.indexOf(cleaned)
        if (start < 0) return false
        val afterAnswer = raw.substring((start + cleaned.length).coerceAtMost(raw.length))
        return listOf(
            Regex("(?is)<\\|\\s*(user|human|system)\\s*\\|>"),
            Regex("(?is)<\\|im_start\\|>\\s*(user|system)"),
            Regex("(?is)<\\|start_header_id\\|>\\s*(user|system)\\s*<\\|end_header_id\\|>"),
            Regex("(?is)<start_of_turn>\\s*(user|system)"),
            Regex("(?is)\\n\\s*(user|human|system)\\s*:\\s*")
        ).any { it.containsMatchIn(afterAnswer) }
    }

    private fun appendGeneratedToken(
        buffer: StringBuilder,
        token: String,
        stoppedByMarker: java.util.concurrent.atomic.AtomicBoolean,
        stopNativeGeneration: Boolean,
        charId: String,
    ) {
        if (stoppedByMarker.get()) return

        buffer.append(token)
        val current = buffer.toString()
        val cleaned = sanitizeGeneratedResponse(current)

        if (shouldStopAfterAnswer(current, cleaned)) {
            stoppedByMarker.set(true)
            buffer.clear()
            buffer.append(cleaned)
            if (stopNativeGeneration) {
                runCatching { LlamaEngine.stop() }
            }
            finishResponse(cleaned, charId)
        } else {
            val visibleText = if (isFormattingOnlyResponse(cleaned)) "" else cleaned
            _state.update { it.copy(streamingText = visibleText, isThinking = visibleText.isBlank()) }
        }
    }

    fun send(userText: String) {
        val snap = _state.value
        if (snap.activeOnlineProvider.isNotBlank()) { sendOnline(userText); return }
        val finalUserText = buildUserTextWithAttachment(userText, snap.currentAttachment)
        if (finalUserText.isBlank() || snap.isGenerating) return
        if (!generationGate.compareAndSet(false, true)) return
        val charId = snap.activeCharacterId
        val userMsg = Message(role = "user", content = finalUserText, characterId = charId)
        viewModelScope.launch {
            try {
                historyMutex.withLock { history.add(userMsg) }
                _state.update { it.copy(messages = it.messages + userMsg, isGenerating = true, isThinking = true, streamingText = "", currentAttachment = null) }
                val historySnapshot = historyMutex.withLock { history.toList() }
                val modelKey = snap.loadedModel?.key ?: "tinyllama"
                val buf = StringBuilder()
                val stoppedByMarker = AtomicBoolean(false)
                LlamaEngine.infer(
                    prompt = buildPrompt(modelKey, snap.systemPrompt, historySnapshot),
                    maxTokens = snap.maxTokens, temperature = snap.temperature, topK = snap.topK, topP = snap.topP,
                    onToken = { tok -> appendGeneratedToken(buf, tok, stoppedByMarker, true, charId) },
                    onDone = { if (!stoppedByMarker.get()) finishResponse(buf.toString(), charId) }
                )
                if (generationGate.get()) finishResponse(buf.toString(), charId)
            } catch (t: Throwable) {
                failGeneration("Generation failed: ${t.message ?: "Unknown error"}")
            }
        }
    }

    private fun sendOnline(userText: String) {
        refreshOnlineProviderKeys()
        val snap = _state.value
        val apiKey = onlineApiKeyFor(snap.activeOnlineProvider)
        if (apiKey.isBlank()) { _state.update { it.copy(error = "No ${onlineProviderLabel(snap.activeOnlineProvider)} API key set. Go to Settings → Online Models.") }; return }
        val finalUserText = buildUserTextWithAttachment(userText, snap.currentAttachment)
        if (finalUserText.isBlank() || snap.isGenerating) return
        if (!generationGate.compareAndSet(false, true)) return
        val charId = snap.activeCharacterId
        val userMsg = Message(role = "user", content = finalUserText, characterId = charId)
        viewModelScope.launch {
            historyMutex.withLock { history.add(userMsg) }
            _state.update { it.copy(messages = it.messages + userMsg, isGenerating = true, isThinking = true, streamingText = "", currentAttachment = null) }
            val historySnapshot = historyMutex.withLock { history.toList() }
            val msgs = mutableListOf<Map<String, String>>()
            if ((snap.activeOnlineProvider == "groq" || isHuggingFaceProvider(snap.activeOnlineProvider) || isTogetherProvider(snap.activeOnlineProvider)) && snap.systemPrompt.isNotBlank()) {
                msgs.add(mapOf("role" to "system", "content" to snap.systemPrompt))
            }
            msgs.addAll(historySnapshot.map { mapOf("role" to it.role, "content" to it.content) })
            val buf = StringBuilder()
            val stoppedByMarker = AtomicBoolean(false)
            val onTok: (String) -> Unit = { tok -> appendGeneratedToken(buf, tok, stoppedByMarker, false, charId) }
            val onDone: () -> Unit = { if (!stoppedByMarker.get()) finishResponse(buf.toString(), charId) }
            val onError: (String) -> Unit = { err -> failGeneration(err) }
            when (snap.activeOnlineProvider) {
                "groq" -> OnlineEngine.streamGroq(
                    apiKey = apiKey,
                    messages = msgs,
                    maxTokens = snap.maxTokens,
                    imageMimeType = snap.currentAttachment?.takeIf { it.isImage && it.imageBase64.isNotBlank() }?.mimeType,
                    imageBase64 = snap.currentAttachment?.takeIf { it.isImage && it.imageBase64.isNotBlank() }?.imageBase64,
                    onToken = onTok,
                    onDone = onDone,
                    onError = onError,
                )
                "gemini" -> OnlineEngine.streamGemini(
                    apiKey = apiKey,
                    messages = msgs,
                    systemPrompt = snap.systemPrompt,
                    maxTokens = snap.maxTokens,
                    imageMimeType = snap.currentAttachment?.takeIf { it.isImage && it.imageBase64.isNotBlank() }?.mimeType,
                    imageBase64 = snap.currentAttachment?.takeIf { it.isImage && it.imageBase64.isNotBlank() }?.imageBase64,
                    onToken = onTok,
                    onDone = onDone,
                    onError = onError,
                )
                else -> when {
                    isHuggingFaceProvider(snap.activeOnlineProvider) -> OnlineEngine.streamHuggingFaceChat(
                        apiKey = apiKey,
                        providerKey = snap.activeOnlineProvider,
                        messages = msgs,
                        systemPrompt = snap.systemPrompt,
                        maxTokens = snap.maxTokens,
                        onToken = onTok,
                        onDone = onDone,
                        onError = onError,
                    )
                    isTogetherProvider(snap.activeOnlineProvider) -> OnlineEngine.streamTogetherChat(
                        apiKey = apiKey,
                        providerKey = snap.activeOnlineProvider,
                        messages = msgs,
                        systemPrompt = snap.systemPrompt,
                        maxTokens = snap.maxTokens,
                        onToken = onTok,
                        onDone = onDone,
                        onError = onError,
                    )
                    else -> onError("Unsupported online model selected.")
                }
            }
        }
    }

    private fun finishResponse(raw: String, charId: String) {
        if (!generationGate.getAndSet(false)) return
        val response = sanitizeGeneratedResponse(raw)
        if (isFormattingOnlyResponse(response)) {
            _state.update { it.copy(
                isGenerating = false,
                isThinking = false,
                streamingText = "",
                error = "The model returned an empty response. Please try again or choose another model."
            ) }
            return
        }
        val assistantMsg = Message(role = "assistant", content = response, characterId = charId)
        viewModelScope.launch {
            historyMutex.withLock {
                history.add(assistantMsg)
                if (history.size > 40) { history.removeAt(0); history.removeAt(0) }
            }
            _state.update { it.copy(messages = it.messages + assistantMsg, isGenerating = false, isThinking = false, streamingText = "") }
            if (_state.value.ttsEnabled && ttsReady && response.isNotBlank()) {
                if (_state.value.selectedVoiceName.isNotBlank()) {
                    val voice = tts?.voices?.find { it.name == _state.value.selectedVoiceName }
                    if (voice != null) tts?.voice = voice
                }
                val speakResult = tts?.speak(response, TextToSpeech.QUEUE_FLUSH, null, "msg_${assistantMsg.id}")
                if (speakResult == TextToSpeech.SUCCESS) {
                    _state.update { it.copy(isSpeaking = true) }
                }
            }
            if (_state.value.notifyOnDone) showResponseNotif()
            if (_state.value.messages.size % 4 == 0) autoSaveSession()
        }
    }

    fun resend(message: Message) { if (!_state.value.isGenerating) send(message.content) }

    fun regenerateLastResponse() {
        val snap = _state.value
        if (snap.isGenerating) {
            _state.update { it.copy(error = "A response is already running. Stop it before regenerating.") }
            return
        }
        viewModelScope.launch {
            val lastUser = historyMutex.withLock {
                while (history.lastOrNull()?.role == "assistant") { history.removeAt(history.lastIndex) }
                history.lastOrNull { it.role == "user" }
            }
            if (lastUser == null) {
                _state.update { it.copy(error = "Send a message first, then you can regenerate the response.") }
                return@launch
            }
            _state.update { current ->
                val trimmed = current.messages.dropLastWhile { it.role == "assistant" }
                current.copy(messages = trimmed, streamingText = "", isGenerating = false, isThinking = false)
            }
            generateResponseFromCurrentHistory(lastUser.characterId)
        }
    }

    private fun generateResponseFromCurrentHistory(charId: String) {
        val snap = _state.value
        if (snap.isGenerating) return
        if (!generationGate.compareAndSet(false, true)) return
        viewModelScope.launch {
            _state.update { it.copy(isGenerating = true, isThinking = true, streamingText = "", currentAttachment = null) }
            val historySnapshot = historyMutex.withLock { history.toList() }
            val buf = StringBuilder()
            val stoppedByMarker = AtomicBoolean(false)
            if (snap.activeOnlineProvider.isNotBlank()) {
                val apiKey = when (snap.activeOnlineProvider) {
                    "groq" -> snap.groqApiKey
                    "gemini" -> snap.geminiApiKey
                    else -> ""
                }
                if (apiKey.isBlank()) {
                    failGeneration("No API key set. Go to Settings → Online Models.")
                    return@launch
                }
                val msgs = mutableListOf<Map<String, String>>()
                if (snap.activeOnlineProvider == "groq" && snap.systemPrompt.isNotBlank()) {
                    msgs.add(mapOf("role" to "system", "content" to snap.systemPrompt))
                }
                msgs.addAll(historySnapshot.map { mapOf("role" to it.role, "content" to it.content) })
                val onTok: (String) -> Unit = { tok ->
                    appendGeneratedToken(buf, tok, stoppedByMarker, false, charId)
                }
                val onDone: () -> Unit = { if (!stoppedByMarker.get()) finishResponse(buf.toString(), charId) }
                val onError: (String) -> Unit = { err ->
                    failGeneration(err)
                }
                when (snap.activeOnlineProvider) {
                    "groq" -> OnlineEngine.streamGroq(
                        apiKey = apiKey, messages = msgs, maxTokens = snap.maxTokens,
                        imageMimeType = null, imageBase64 = null,
                        onToken = onTok, onDone = onDone, onError = onError,
                    )
                    "gemini" -> OnlineEngine.streamGemini(
                        apiKey = apiKey, messages = msgs, systemPrompt = snap.systemPrompt, maxTokens = snap.maxTokens,
                        imageMimeType = null, imageBase64 = null,
                        onToken = onTok, onDone = onDone, onError = onError,
                    )
                }
            } else {
                val modelKey = snap.loadedModel?.key ?: "tinyllama"
                LlamaEngine.infer(
                    prompt = buildPrompt(modelKey, snap.systemPrompt, historySnapshot),
                    maxTokens = snap.maxTokens, temperature = snap.temperature, topK = snap.topK, topP = snap.topP,
                    onToken = { tok ->
                        appendGeneratedToken(buf, tok, stoppedByMarker, true, charId)
                    },
                    onDone = { if (!stoppedByMarker.get()) finishResponse(buf.toString(), charId) }
                )
            }
        }
    }

    fun exportConversationText(): String {
        val msgs = _state.value.messages
        if (msgs.isEmpty()) return "PocketMind chat is empty."
        return buildString {
            appendLine("PocketMind Chat Export")
            appendLine("======================")
            appendLine()
            msgs.forEach { msg ->
                val role = if (msg.role == "user") "You" else "PocketMind"
                appendLine("$role:")
                appendLine(msg.content.trim())
                appendLine()
            }
        }.trim()
    }

    fun stopGeneration() {
        stopVoiceReply()
        LlamaEngine.stop()
        generationGate.set(false)
        val partial = sanitizeGeneratedResponse(_state.value.streamingText)
        _state.update { it.copy(
            isGenerating = false, isThinking = false,
            messages = if (!isFormattingOnlyResponse(partial)) it.messages + Message(role = "assistant", content = partial) else it.messages,
            streamingText = ""
        )}
    }

    fun clearHistory() {
        stopVoiceReply()
        viewModelScope.launch { historyMutex.withLock { history.clear() } }
        generationGate.set(false)
        _state.update { it.copy(messages = emptyList(), streamingText = "", isGenerating = false, isThinking = false, currentAttachment = null) }
    }

    fun setPersona(shakespeare: Boolean) {
        val prompt = DEFAULT_SYSTEM
        Prefs.saveString(getApplication(), "systemPrompt", prompt)
        Prefs.saveString(getApplication(), "activeCharacterId", "assistant")
        _state.update { it.copy(systemPrompt = prompt, activeCharacterId = "assistant") }
        clearHistory()
    }

    fun setCustomSystemPrompt(prompt: String) {
        Prefs.saveString(getApplication(), "systemPrompt", prompt)
        _state.update { it.copy(systemPrompt = prompt) }
        clearHistory()
    }

    fun toggleBookmark(key: String) {
        _state.update { val bk = it.bookmarkedKeys.toMutableSet(); if (key in bk) bk.remove(key) else bk.add(key); it.copy(bookmarkedKeys = bk) }
        Prefs.saveBookmarks(getApplication(), _state.value.bookmarkedKeys)
    }

    private fun autoSaveSession() {
        if (history.isEmpty()) return
        val existing = _state.value.chatSessions.firstOrNull { it.id == currentSessionId }
        val modelKey = _state.value.loadedModel?.key ?: _state.value.activeOnlineProvider.ifBlank { "custom" }
        val title = existing?.title?.takeIf { it.isNotBlank() } ?: generateSessionTitle(history)
        val session = ChatSession(
            id = currentSessionId,
            modelKey = modelKey,
            title = title,
            messages = history.toList(),
            isPinned = existing?.isPinned ?: false,
            updatedAt = System.currentTimeMillis(),
        )
        val sessions = if (existing != null) {
            _state.value.chatSessions.map { if (it.id == currentSessionId) session else it }
        } else {
            (_state.value.chatSessions + session).takeLast(80)
        }
        _state.update { it.copy(chatSessions = sessions) }
        Prefs.saveSessions(getApplication(), sessions)
    }

    private fun generateSessionTitle(messages: List<Message>): String {
        val firstUser = messages.firstOrNull { it.role == "user" }?.content.orEmpty()
        val cleaned = firstUser
            .substringBefore("[Attached file:")
            .replace(Regex("\\s+"), " ")
            .trim()
        return cleaned.ifBlank { "New chat" }.take(55)
    }

    fun saveSession() { viewModelScope.launch { historyMutex.withLock { autoSaveSession() } } }

    fun loadSession(session: ChatSession) {
        stopVoiceReply()
        viewModelScope.launch {
            historyMutex.withLock { history.clear(); history.addAll(session.messages) }
            currentSessionId = session.id
            _state.update { it.copy(messages = session.messages, streamingText = "", currentAttachment = null) }
        }
    }

    fun renameSession(id: Long, title: String) {
        val safeTitle = title.trim().take(80).ifBlank { "Chat" }
        val sessions = _state.value.chatSessions.map {
            if (it.id == id) it.copy(title = safeTitle, updatedAt = System.currentTimeMillis()) else it
        }
        _state.update { it.copy(chatSessions = sessions) }
        Prefs.saveSessions(getApplication(), sessions)
    }

    fun togglePinSession(id: Long) {
        val sessions = _state.value.chatSessions.map {
            if (it.id == id) it.copy(isPinned = !it.isPinned, updatedAt = System.currentTimeMillis()) else it
        }
        _state.update { it.copy(chatSessions = sessions) }
        Prefs.saveSessions(getApplication(), sessions)
    }

    fun deleteSession(id: Long) {
        val sessions = _state.value.chatSessions.filter { it.id != id }
        _state.update { it.copy(chatSessions = sessions) }
        Prefs.saveSessions(getApplication(), sessions)
    }


    fun exportBackupJson(): String {
        if (history.isNotEmpty()) autoSaveSession()
        val snap = _state.value
        val sessionsJson = JSONArray()
        snap.chatSessions.forEach { session ->
            val messagesJson = JSONArray()
            session.messages.forEach { msg ->
                messagesJson.put(JSONObject().apply {
                    put("id", msg.id)
                    put("role", msg.role)
                    put("content", msg.content)
                    put("characterId", msg.characterId)
                })
            }
            sessionsJson.put(JSONObject().apply {
                put("id", session.id)
                put("modelKey", session.modelKey)
                put("title", session.title)
                put("isPinned", session.isPinned)
                put("updatedAt", session.updatedAt)
                put("messages", messagesJson)
            })
        }

        val charactersJson = JSONArray()
        snap.customCharacters.filter { !it.isBuiltIn }.forEach { c ->
            charactersJson.put(JSONObject().apply {
                put("id", c.id)
                put("name", c.name)
                put("description", c.description)
                put("systemPrompt", c.systemPrompt)
                put("avatarEmoji", c.avatarEmoji)
                put("voiceName", c.voiceName)
            })
        }

        return JSONObject().apply {
            put("app", "PocketMind")
            put("version", 1)
            put("exportedAt", System.currentTimeMillis())
            put("sessions", sessionsJson)
            put("customCharacters", charactersJson)
            put("systemPrompt", snap.systemPrompt)
            put("activeCharacterId", snap.activeCharacterId)
            put("themeMode", Prefs.getString(getApplication(), "themeMode", "dark"))
        }.toString(2)
    }

    fun importBackupJson(raw: String): Result<String> {
        return try {
            val root = JSONObject(raw)
            val importedSessions = mutableListOf<ChatSession>()
            val sessionsArray = root.optJSONArray("sessions") ?: JSONArray()
            for (i in 0 until sessionsArray.length()) {
                val obj = sessionsArray.getJSONObject(i)
                val msgsArray = obj.optJSONArray("messages") ?: JSONArray()
                val msgs = mutableListOf<Message>()
                for (j in 0 until msgsArray.length()) {
                    val m = msgsArray.getJSONObject(j)
                    msgs += Message(
                        id = m.optLong("id", System.nanoTime()),
                        role = m.optString("role", "user"),
                        content = m.optString("content", ""),
                        characterId = m.optString("characterId", "")
                    )
                }
                if (msgs.isNotEmpty()) {
                    importedSessions += ChatSession(
                        id = obj.optLong("id", System.currentTimeMillis() + i),
                        modelKey = obj.optString("modelKey", "custom"),
                        title = obj.optString("title", "Imported chat"),
                        messages = msgs,
                        isPinned = obj.optBoolean("isPinned", false),
                        updatedAt = obj.optLong("updatedAt", obj.optLong("id", System.currentTimeMillis()))
                    )
                }
            }

            val importedCharacters = mutableListOf<Character>()
            val charsArray = root.optJSONArray("customCharacters") ?: JSONArray()
            for (i in 0 until charsArray.length()) {
                val c = charsArray.getJSONObject(i)
                val name = c.optString("name", "").trim()
                val prompt = c.optString("systemPrompt", "").trim()
                if (name.isNotBlank() && prompt.isNotBlank()) {
                    importedCharacters += Character(
                        id = c.optString("id", System.currentTimeMillis().toString() + i),
                        name = name,
                        description = c.optString("description", "Custom imported character"),
                        systemPrompt = prompt,
                        avatarEmoji = c.optString("avatarEmoji", "🤖"),
                        voiceName = c.optString("voiceName", ""),
                        isBuiltIn = false
                    )
                }
            }

            val mergedSessions = (_state.value.chatSessions + importedSessions)
                .distinctBy { it.id }
                .sortedBy { it.updatedAt }
                .takeLast(80)
            val mergedCharacters = (_state.value.customCharacters + importedCharacters)
                .filter { !it.isBuiltIn }
                .distinctBy { it.id }

            Prefs.saveSessions(getApplication(), mergedSessions)
            CharacterManager.saveCustom(getApplication(), mergedCharacters)

            root.optString("systemPrompt").takeIf { it.isNotBlank() }?.let {
                Prefs.saveString(getApplication(), "systemPrompt", it)
            }
            root.optString("activeCharacterId").takeIf { it.isNotBlank() }?.let {
                Prefs.saveString(getApplication(), "activeCharacterId", it)
            }
            root.optString("themeMode").takeIf { it.isNotBlank() }?.let {
                Prefs.saveString(getApplication(), "themeMode", normalizeThemeMode(it))
            }

            _state.update { current ->
                current.copy(
                    chatSessions = mergedSessions,
                    customCharacters = mergedCharacters,
                    systemPrompt = root.optString("systemPrompt", current.systemPrompt).ifBlank { current.systemPrompt },
                    activeCharacterId = root.optString("activeCharacterId", current.activeCharacterId).ifBlank { current.activeCharacterId }
                )
            }

            Result.success("Imported ${importedSessions.size} chats and ${importedCharacters.size} characters.")
        } catch (e: Exception) {
            Result.failure(IllegalArgumentException("Backup import failed: ${e.message ?: "Invalid backup file"}"))
        }
    }

    fun newChat() { currentSessionId = System.currentTimeMillis(); clearHistory() }

    private fun buildPrompt(modelKey: String, system: String, messages: List<Message>): String =
        com.arslan.llamachat.llm.buildPrompt(modelKey, system, messages)

    override fun onCleared() {
        super.onCleared()
        LlamaEngine.freeModel()
        stopVoiceReply(); tts?.shutdown()
        if (wakeLock?.isHeld == true) wakeLock?.release()
    }
}

fun formatSpeed(bps: Long): String = when {
    bps <= 0 -> ""; bps < 1024 -> "$bps B/s"
    bps < 1024 * 1024 -> "${"%.1f".format(bps / 1024.0)} KB/s"
    else -> "${"%.1f".format(bps / 1024.0 / 1024.0)} MB/s"
}


private fun formatAttachmentBytes(bytes: Long): String = when {
    bytes <= 0 -> ""
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "${"%.1f".format(bytes / 1024.0)} KB"
    bytes < 1024 * 1024 * 1024 -> "${"%.1f".format(bytes / 1024.0 / 1024.0)} MB"
    else -> "${"%.2f".format(bytes / 1024.0 / 1024.0 / 1024.0)} GB"
}
