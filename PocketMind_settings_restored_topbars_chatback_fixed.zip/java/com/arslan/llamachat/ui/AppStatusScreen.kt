package com.arslan.llamachat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class StatusItem(
    val title: String,
    val body: String,
    val ready: Boolean,
    val icon: ImageVector,
    val actionLabel: String,
    val target: HelpTarget? = null,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppStatusScreen(
    vm: ChatViewModel,
    onBack: () -> Unit,
    onNavigate: (HelpTarget) -> Unit,
    onOpenBackupRestore: () -> Unit,
) {
    val context = LocalContext.current
    val state by vm.state.collectAsState()
    val appVersion = remember {
        runCatching {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "Local build"
        }.getOrDefault("Local build")
    }

    val aiReady = state.loadedModel != null || state.activeOnlineProvider.isNotBlank() || state.customGgufName.isNotBlank()
    val onlineReady = state.groqApiKey.isNotBlank() || state.geminiApiKey.isNotBlank()
    val chatsReady = state.chatSessions.isNotEmpty()
    val downloadedReady = state.downloadedKeys.isNotEmpty() || state.customGgufName.isNotBlank()
    val offlineImageModelReady = runCatching {
        com.arslan.llamachat.llm.Prefs.getString(context, "imageGenModelPath", "").isNotBlank()
    }.getOrDefault(false)
    val imageStudioReady = true

    val items = listOf(
        StatusItem(
            title = "Core AI model",
            body = if (aiReady) "A model is selected or loaded and chat can start." else "Choose an online model, download an offline model, or load a custom GGUF before chatting.",
            ready = aiReady,
            icon = Icons.Default.Psychology,
            actionLabel = if (aiReady) "Open Chat" else "Choose Model",
            target = if (aiReady) HelpTarget.Chat else HelpTarget.Models,
        ),
        StatusItem(
            title = "Online keys",
            body = if (onlineReady) "At least one online provider key is saved for fast cloud replies and photo vision." else "Add provider keys to enable online responses or photo understanding. Online request content is sent to the selected provider.",
            ready = onlineReady,
            icon = Icons.Default.Key,
            actionLabel = "API Keys",
            target = HelpTarget.ApiKeys,
        ),
        StatusItem(
            title = "Offline models",
            body = if (downloadedReady) "Offline model files or a custom GGUF are available on this device." else "Download a GGUF model for on-device chatting after the model is available locally.",
            ready = downloadedReady,
            icon = Icons.Default.Memory,
            actionLabel = "Models",
            target = HelpTarget.Models,
        ),
        StatusItem(
            title = "Image Studio",
            body = if (offlineImageModelReady) "Offline image generation is configured, and online image modes are available from Image Studio." else "Image Studio is ready. Online generation sends prompts to the selected provider, and an offline image model can be added for private on-device creation.",
            ready = imageStudioReady,
            icon = Icons.Default.Image,
            actionLabel = "Image Studio",
            target = HelpTarget.ImageStudio,
        ),
        StatusItem(
            title = "Saved workspace",
            body = if (chatsReady) "Saved chats are available and can be backed up." else "Start and save a chat to initialize the workspace.",
            ready = chatsReady,
            icon = Icons.Default.Chat,
            actionLabel = if (chatsReady) "Backup" else "Start Chat",
            target = if (chatsReady) null else HelpTarget.Chat,
        ),
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("App Status & Safety", fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = pocketMindTopBarInsets(),
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                StatusHeroCard(
                    readyCount = items.count { it.ready },
                    totalCount = items.size,
                    version = appVersion,
                )
            }

            items.forEach { item ->
                item {
                    StatusCheckCard(
                        item = item,
                        onClick = {
                            if (item.target == null) onOpenBackupRestore() else onNavigate(item.target)
                        },
                    )
                }
            }

            item {
                SafetyNotesCard(onOpenBackupRestore = onOpenBackupRestore)
            }
        }
    }
}

@Composable
private fun StatusHeroCard(readyCount: Int, totalCount: Int, version: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        elevation = CardDefaults.cardElevation(3.dp),
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Default.HealthAndSafety, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("PocketMind readiness", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(
                    "$readyCount of $totalCount core areas ready · version $version",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f),
                )
            }
        }
    }
}

@Composable
private fun StatusCheckCard(item: StatusItem, onClick: () -> Unit) {
    val color = if (item.ready) Color(0xFF00A67E) else MaterialTheme.colorScheme.error
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(color.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(item.icon, null, tint = color)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text(item.body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(if (item.ready) Icons.Default.CheckCircle else Icons.Default.Warning, null, tint = color)
            }
            FilledTonalButton(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Text(item.actionLabel)
            }
        }
    }
}

@Composable
private fun SafetyNotesCard(onOpenBackupRestore: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.width(8.dp))
                Text("Safety and reliability", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            }
            Text("For the smoothest experience, keep backups of important chats, use offline mode for private work, and enable online providers only when you are comfortable sending that request to the selected provider.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.82f))
            OutlinedButton(onClick = onOpenBackupRestore, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Save, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Open Backup & Restore")
            }
        }
    }
}
