package com.arslan.llamachat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    vm: ChatViewModel,
    onStartChat: () -> Unit,
    onOpenModels: () -> Unit,
    onOpenChats: () -> Unit,
    onOpenImageStudio: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenCharacters: () -> Unit,
    onOpenCustomModel: () -> Unit,
    onSetupKeys: () -> Unit,
    onOpenStorage: () -> Unit,
    onOpenSession: (ChatSession) -> Unit,
    onRunHealthCheck: () -> Unit,
    onOpenHelp: () -> Unit,
    onOpenHelpdesk: () -> Unit,
    onOpenSetupWizard: () -> Unit = {},
    onOpenStatus: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
    val state by vm.state.collectAsState()
    val latestSession = remember(state.chatSessions) { state.chatSessions.maxByOrNull { it.updatedAt } }
    val pinnedCount = remember(state.chatSessions) { state.chatSessions.count { it.isPinned } }
    val fmt = remember { SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()) }

    val activeModelTitle = when {
        state.activeOnlineProvider == "groq" -> "Groq Online · Text + Vision"
        state.activeOnlineProvider == "gemini" -> "Gemini 2.5 Flash · Vision"
        state.customGgufName.isNotBlank() -> state.customGgufName
        state.loadedModel != null -> state.loadedModel!!.displayName
        else -> "No model selected"
    }
    val activeModelSubtitle = when {
        state.activeOnlineProvider.isNotBlank() -> "Online provider selected; requests go to that provider"
        state.customGgufName.isNotBlank() || state.loadedModel != null -> "Offline model ready on this device"
        else -> "Choose an online or offline model to start"
    }
    val isReady = state.loadedModel != null || state.activeOnlineProvider.isNotBlank() || state.customGgufName.isNotBlank()

    val recommendationTitle: String
    val recommendationBody: String
    val recommendationAction: String
    val recommendationClick: () -> Unit
    when {
        state.groqApiKey.isBlank() && state.geminiApiKey.isBlank() -> {
            recommendationTitle = "Set up instant online AI"
            recommendationBody = "Add your provider key to enable online chat and photo understanding. Online requests are sent to the selected provider."
            recommendationAction = "Add keys"
            recommendationClick = onSetupKeys
        }
        !isReady -> {
            recommendationTitle = "Choose a first model"
            recommendationBody = "Pick an online provider or download an offline GGUF model. Offline models stay on-device; online requests go to the selected provider."
            recommendationAction = "Open models"
            recommendationClick = onOpenModels
        }
        state.chatSessions.isEmpty() -> {
            recommendationTitle = "Start a first saved chat"
            recommendationBody = "Ask a question, attach a document, or create a character conversation."
            recommendationAction = "Start chat"
            recommendationClick = onStartChat
        }
        else -> {
            recommendationTitle = "Keep building the workspace"
            recommendationBody = "Manage saved chats, create images, organize storage, and switch characters anytime."
            recommendationAction = "View chats"
            recommendationClick = onOpenChats
        }
    }

    Box(modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopAppBar(
            title = { Text("PocketMind", fontWeight = FontWeight.Bold, fontSize = 20.sp) },
            actions = {
                FilledTonalIconButton(onClick = onOpenSettings) {
                    Icon(Icons.Default.Settings, "Settings")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            windowInsets = WindowInsets(0),
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                HomeHeroCard(
                    ready = isReady,
                    activeModelTitle = activeModelTitle,
                    activeModelSubtitle = activeModelSubtitle,
                    onPrimary = if (isReady) onStartChat else onOpenModels,
                    primaryLabel = if (isReady) "Start chat" else "Choose model",
                    onSecondary = onOpenImageStudio,
                    onHealthCheck = onRunHealthCheck,
                )
            }
            item {
                SetupShortcutCard(onOpenSetupWizard = onOpenSetupWizard)
            }
            item {
                StatusShortcutCard(isReady = isReady, onOpenStatus = onOpenStatus)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    HomeStatCard("Saved chats", state.chatSessions.size.toString(), Icons.Default.Chat, Modifier.weight(1f), onOpenChats)
                    HomeStatCard("Pinned", pinnedCount.toString(), Icons.Default.PushPin, Modifier.weight(1f), onOpenChats)
                }
            }
            item {
                RecommendationCard(title = recommendationTitle, body = recommendationBody, action = recommendationAction, onClick = recommendationClick)
            }
            item {
                Text("Quick actions", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        QuickActionCard("Chat", "Ask anything", Icons.Default.Chat, Modifier.weight(1f), onStartChat, enabled = isReady)
                        QuickActionCard("Models", "Download or switch", Icons.Default.GridView, Modifier.weight(1f), onOpenModels)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        QuickActionCard("Characters", "Personas & voices", Icons.Default.Person, Modifier.weight(1f), onOpenCharacters)
                        QuickActionCard("Image Studio", "Create visuals", Icons.Default.Image, Modifier.weight(1f), onOpenImageStudio)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        QuickActionCard("Custom GGUF", "Import GGUF", Icons.Default.FolderOpen, Modifier.weight(1f), onOpenCustomModel)
                        QuickActionCard("Storage", "Manage space", Icons.Default.Storage, Modifier.weight(1f), onOpenStorage)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        QuickActionCard("Setup Wizard", "Choose a goal", Icons.Default.RocketLaunch, Modifier.weight(1f), onOpenSetupWizard)
                        QuickActionCard("Status", "Health & safety", Icons.Default.HealthAndSafety, Modifier.weight(1f), onOpenStatus)
                    }
                }
            }
            item {
                Text("Continue", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                if (latestSession == null) {
                    EmptyHomeCard(
                        title = "No saved chats yet",
                        body = "Start a conversation and PocketMind will save it here for quick access.",
                        action = "Start chat",
                        onClick = if (isReady) onStartChat else onOpenModels,
                    )
                } else {
                    ContinueChatCard(
                        session = latestSession,
                        updated = fmt.format(Date(latestSession.updatedAt)),
                        onClick = { onOpenSession(latestSession) },
                    )
                }
            }
        }
        }
    
        FloatingActionButton(
            onClick = onOpenHelpdesk,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 20.dp, bottom = 24.dp),
            containerColor = MaterialTheme.colorScheme.primary,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            shape = CircleShape,
            elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
        ) {
            Icon(
                Icons.Default.HeadsetMic,
                contentDescription = "PocketMind helpdesk",
                modifier = Modifier.size(28.dp),
            )
        }
    }
}

@Composable
private fun HomeHeroCard(
    ready: Boolean,
    activeModelTitle: String,
    activeModelSubtitle: String,
    primaryLabel: String,
    onPrimary: () -> Unit,
    onSecondary: () -> Unit,
    onHealthCheck: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(4.dp),
    ) {
        Box(
            modifier = Modifier.fillMaxWidth()
                .background(Brush.linearGradient(listOf(MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.secondaryContainer, MaterialTheme.colorScheme.tertiaryContainer)))
                .padding(20.dp),
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(56.dp).clip(RoundedCornerShape(18.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Welcome back", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        Text("AI command center", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.82f)), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(12.dp).clip(CircleShape).background(if (ready) Color(0xFF00A67E) else MaterialTheme.colorScheme.error))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(activeModelTitle, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(activeModelSubtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = onPrimary, shape = RoundedCornerShape(16.dp)) {
                        Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(primaryLabel)
                    }
                    OutlinedButton(onClick = onSecondary, shape = RoundedCornerShape(16.dp)) {
                        Icon(Icons.Default.Image, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Create")
                    }
                    if (ready) {
                        FilledTonalButton(onClick = onHealthCheck, shape = RoundedCornerShape(16.dp)) {
                            Icon(Icons.Default.HealthAndSafety, null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Test")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SetupShortcutCard(onOpenSetupWizard: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenSetupWizard),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(MaterialTheme.colorScheme.secondary.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.RocketLaunch, null, tint = MaterialTheme.colorScheme.secondary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Setup Wizard", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text("Pick a task, then jump to the right screen.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.78f))
            }
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.secondary)
        }
    }
}

@Composable
private fun HelpShortcutCard(onOpenHelp: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenHelp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.HelpOutline, null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("What can I do with PocketMind?", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(
                    "Open guided use cases for PDFs, photos, offline chat, online AI, characters, image generation, and storage.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.78f),
                )
            }
            Icon(Icons.Default.ArrowForward, null, tint = MaterialTheme.colorScheme.secondary)
        }
    }
}


@Composable
private fun StatusShortcutCard(isReady: Boolean, onOpenStatus: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpenStatus),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(1.dp),
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(48.dp).clip(RoundedCornerShape(16.dp))
                    .background(if (isReady) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.error.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (isReady) Icons.Default.CheckCircle else Icons.Default.Warning,
                    null,
                    tint = if (isReady) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("App status & safety", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(
                    if (isReady) "Core AI is ready. Review keys, backups, storage, and image setup."
                    else "Finish setup so chat, files, images, and backups are ready for real use.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HomeStatCard(title: String, value: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier = modifier.clickable(onClick = onClick), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
            Text(title, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun RecommendationCard(title: String, body: String, action: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.TipsAndUpdates, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Spacer(Modifier.height(4.dp))
                Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f))
            }
            Spacer(Modifier.width(10.dp))
            FilledTonalButton(onClick = onClick, shape = RoundedCornerShape(14.dp)) { Text(action) }
        }
    }
}

@Composable
private fun QuickActionCard(title: String, subtitle: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit, enabled: Boolean = true) {
    Card(
        modifier = modifier.clickable(enabled = enabled, onClick = onClick),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = if (enabled) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)),
        elevation = CardDefaults.cardElevation(1.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, null, tint = if (enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f))
            Text(title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (enabled) subtitle else "Load a model first",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

@Composable
private fun ContinueChatCard(session: ChatSession, updated: String, onClick: () -> Unit) {
    val firstUser = session.messages.firstOrNull { it.role == "user" }?.content ?: "Saved conversation"
    val lastAssistant = session.messages.lastOrNull { it.role == "assistant" }?.content ?: "Tap to continue this chat."
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (session.isPinned) Icons.Default.PushPin else Icons.Default.Chat, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(session.title.ifBlank { firstUser }, Modifier.weight(1f), fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(lastAssistant, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                AssistChip(onClick = {}, label = { Text(modelLabelForHome(session.modelKey)) })
                Text(updated, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun EmptyHomeCard(title: String, body: String, action: String, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onClick, shape = RoundedCornerShape(14.dp)) { Text(action) }
        }
    }
}

private fun modelLabelForHome(key: String): String = when {
    key == "groq" -> "Groq"
    key == "gemini" -> "Gemini"
    key == "custom" -> "Custom GGUF"
    key.contains("tiny", ignoreCase = true) -> "TinyLlama"
    key.contains("qwen", ignoreCase = true) -> "Qwen"
    key.contains("llama", ignoreCase = true) -> "Llama"
    key.contains("mistral", ignoreCase = true) -> "Mistral"
    key.contains("gemma", ignoreCase = true) -> "Gemma"
    else -> key.ifBlank { "Chat" }
}
