package com.arslan.llamachat.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.with
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

private data class OnboardingSlide(
    val icon: ImageVector,
    val eyebrow: String,
    val title: String,
    val body: String,
    val chips: List<String>,
    val accent: Color,
)

private val onboardingSlides = listOf(
    OnboardingSlide(Icons.Default.AutoAwesome, "Welcome to PocketMind", "Your private AI workspace", "Chat with local and online models, understand documents, create images, use characters, and keep your AI workflow organized.", listOf("Offline AI", "Online AI", "Documents"), Color(0xFF7C4DFF)),
    OnboardingSlide(Icons.Default.Memory, "Offline models", "Download once. Chat anywhere.", "Run GGUF models directly on your phone with CPU or Vulkan acceleration. Your local chats can work without internet.", listOf("GGUF", "Vulkan", "Private"), Color(0xFF00A67E)),
    OnboardingSlide(Icons.Default.Cloud, "Online models", "Instant cloud intelligence", "Use your own Groq and Gemini keys for fast replies, longer answers, and online vision when you need extra power.", listOf("Groq", "Gemini", "Fast"), Color(0xFF4285F4)),
    OnboardingSlide(Icons.Default.AttachFile, "Files and photos", "Ask questions about your content", "Attach PDFs, DOCX, text, code, logs, and photos. Text files work with local and online models; photos work with vision-capable online models.", listOf("PDF", "DOCX", "Photos"), Color(0xFFFF9800)),
    OnboardingSlide(Icons.Default.Person, "Characters", "Build AI personalities", "Switch between tutors, coders, storytellers, assistants, and your own custom characters with unique prompts and voices.", listOf("Personas", "Voices", "Prompts"), Color(0xFFE91E63)),
    OnboardingSlide(Icons.Default.Image, "Image Studio", "Offline, free-tier online, or premium", "Generate visuals with private offline models or online providers. Online image prompts are sent to the provider you select.", listOf("Offline", "Free-tier", "Premium"), Color(0xFF009688)),
    OnboardingSlide(Icons.Default.Lock, "Privacy-first design", "You choose what leaves the device", "Offline chat and document reading stay on your phone. Online requests are sent only to the provider you select.", listOf("Local files", "Your keys", "Clear control"), Color(0xFF5B35F2)),
)

@OptIn(ExperimentalFoundationApi::class, ExperimentalAnimationApi::class)
@Composable
fun OnboardingScreen(onFinished: () -> Unit) {
    val pagerState = rememberPagerState(pageCount = { onboardingSlides.size })
    val scope = rememberCoroutineScope()
    val isLast = pagerState.currentPage == onboardingSlides.lastIndex

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f),
                        MaterialTheme.colorScheme.surface,
                        MaterialTheme.colorScheme.surface,
                    )
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 22.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.primary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Psychology, null, tint = MaterialTheme.colorScheme.onPrimary)
                    }
                    Spacer(Modifier.width(10.dp))
                    Text("PocketMind", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                }
                TextButton(onClick = onFinished) { Text("Skip") }
            }

            Spacer(Modifier.height(10.dp))

            HorizontalPager(
                state = pagerState,
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) { page ->
                OnboardingSlideCard(
                    slide = onboardingSlides[page],
                    active = pagerState.currentPage == page
                )
            }

            PageIndicators(
                pageCount = onboardingSlides.size,
                selectedPage = pagerState.currentPage,
                modifier = Modifier.padding(top = 12.dp, bottom = 18.dp)
            )

            AnimatedContent(
                targetState = isLast,
                transitionSpec = {
                    (slideInHorizontally { it / 2 } + fadeIn()) with
                        (slideOutHorizontally { -it / 2 } + fadeOut())
                },
                label = "onboardingButton"
            ) { lastPage ->
                Button(
                    onClick = {
                        if (lastPage) {
                            onFinished()
                        } else {
                            scope.launch {
                                pagerState.animateScrollToPage(
                                    pagerState.currentPage + 1,
                                    animationSpec = tween(350)
                                )
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Text(if (lastPage) "Get Started" else "Next", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(8.dp))
                    Icon(if (lastPage) Icons.Default.RocketLaunch else Icons.Default.ArrowForward, null)
                }
            }
        }
    }
}

@Composable
private fun OnboardingSlideCard(slide: OnboardingSlide, active: Boolean) {
    val scale by animateFloatAsState(
        targetValue = if (active) 1f else 0.96f,
        animationSpec = tween(350),
        label = "slideScale"
    )
    val alpha by animateFloatAsState(
        targetValue = if (active) 1f else 0.75f,
        animationSpec = tween(350),
        label = "slideAlpha"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .scale(scale)
            .alpha(alpha),
        shape = RoundedCornerShape(34.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(
                            slide.accent.copy(alpha = 0.23f),
                            MaterialTheme.colorScheme.surfaceVariant,
                            MaterialTheme.colorScheme.surfaceVariant,
                        )
                    )
                )
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(32.dp))
                    .background(slide.accent),
                contentAlignment = Alignment.Center
            ) {
                Icon(slide.icon, null, tint = Color.White, modifier = Modifier.size(48.dp))
            }

            Spacer(Modifier.height(28.dp))

            Text(
                slide.eyebrow.uppercase(),
                color = slide.accent,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center
            )

            Spacer(Modifier.height(8.dp))

            Text(
                slide.title,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(12.dp))

            Text(
                slide.body,
                style = MaterialTheme.typography.bodyMedium,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.82f),
                lineHeight = 21.sp
            )

            Spacer(Modifier.height(22.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                slide.chips.chunked(2).forEach { rowItems ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        rowItems.forEach { chip ->
                            FeatureChip(text = chip, accent = slide.accent)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureChip(text: String, accent: Color) {
    Surface(
        shape = RoundedCornerShape(50),
        color = accent.copy(alpha = 0.12f),
        contentColor = accent
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold
        )
    }
}

@Composable
private fun PageIndicators(pageCount: Int, selectedPage: Int, modifier: Modifier = Modifier) {
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        repeat(pageCount) { index ->
            val selected = index == selectedPage
            Box(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .height(8.dp)
                    .width(if (selected) 24.dp else 8.dp)
                    .clip(CircleShape)
                    .background(
                        if (selected) MaterialTheme.colorScheme.primary
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.22f)
                    )
            )
        }
    }
}
