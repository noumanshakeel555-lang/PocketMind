package com.arslan.llamachat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WhatsNewScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("What's New", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = pocketMindTopBarInsets(),
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(56.dp).clip(RoundedCornerShape(18.dp))
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Update, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("PocketMind keeps getting better", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                            Text("Recent improvements focused on privacy, speed, clarity, and a more polished AI workspace.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f))
                        }
                    }
                }
            }

            item { ChangeItem(Icons.Default.AutoAwesome, "Refined premium interface", "A sharper light/dark design, richer cards, clearer hierarchy, and a more confident first-run experience.") }
            item { ChangeItem(Icons.Default.RocketLaunch, "Setup Wizard", "Guided paths for offline AI, online AI, image generation, PDFs, characters, and custom GGUF models.") }
            item { ChangeItem(Icons.Default.Lightbulb, "Prompt Library", "Ready-made prompts for study, coding, business, image creation, and general tasks.") }
            item { ChangeItem(Icons.Default.HealthAndSafety, "App Status & Safety", "A quick readiness checklist for models, API keys, backups, storage, and image setup.") }
            item { ChangeItem(Icons.Default.Save, "Backup & Restore", "Export and import saved chats, custom characters, active prompt settings, and theme preference.") }
            item { ChangeItem(Icons.Default.AttachFile, "Files and photo support", "PDF, DOCX, text/code files, logs, JSON/CSV, and online photo vision workflows now clarify when content stays local and when it goes to a selected provider.") }
            item { ChangeItem(Icons.Default.Image, "Image Studio flow", "Import/download image models, test them safely, and save generated images to gallery.") }
            item { ChangeItem(Icons.Default.Info, "Trust and transparency", "About, What's New, and Privacy screens explain how PocketMind works and how your data is handled.") }
        }
    }
}

@Composable
private fun ChangeItem(icon: ImageVector, title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(15.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
