package com.arslan.llamachat.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupWizardScreen(
    onBack: () -> Unit,
    onNavigate: (HelpTarget) -> Unit,
) {
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Setup Wizard",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                    Text(
                        text = "Choose how you want to use PocketMind",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Set up an offline GGUF model for private on-device chat, or add API keys for online models and image generation. Online requests go directly to the provider you select."
                    )
                }
            }

            SetupWizardOption(
                icon = Icons.Default.Memory,
                title = "Load an offline model",
                description = "Import or download a GGUF model and chat privately on your device.",
                buttonText = "Open custom model",
                onClick = { onNavigate(HelpTarget.CustomModel) }
            )

            SetupWizardOption(
                icon = Icons.Default.Cloud,
                title = "Use online AI",
                description = "Add your own API keys for Groq, Gemini, Hugging Face, or Together AI. Keys stay on-device and requests go directly to the selected provider.",
                buttonText = "Set up API keys",
                onClick = { onNavigate(HelpTarget.ApiKeys) }
            )

            SetupWizardOption(
                icon = Icons.Default.Image,
                title = "Create images",
                description = "Open Image Studio for offline on-device generation, free-tier online options, and premium provider image tools.",
                buttonText = "Open Image Studio",
                onClick = { onNavigate(HelpTarget.ImageStudio) }
            )

            SetupWizardOption(
                icon = Icons.Default.Person,
                title = "Customize assistant behavior",
                description = "Choose characters and system prompts for different use cases.",
                buttonText = "Open characters",
                onClick = { onNavigate(HelpTarget.Characters) }
            )

            SetupWizardOption(
                icon = Icons.Default.Storage,
                title = "Manage storage",
                description = "Review downloaded models, cache files, and local app storage.",
                buttonText = "Open storage",
                onClick = { onNavigate(HelpTarget.Storage) }
            )

            SetupWizardOption(
                icon = Icons.Default.Settings,
                title = "Tune app settings",
                description = "Adjust model behavior, response length, voice, GPU options, and safety settings.",
                buttonText = "Open settings",
                onClick = { onNavigate(HelpTarget.Settings) }
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                AssistChip(
                    onClick = { onNavigate(HelpTarget.Chat) },
                    label = { Text("Start chat") },
                    leadingIcon = { Icon(Icons.Default.AutoAwesome, contentDescription = null) }
                )
                AssistChip(
                    onClick = { onNavigate(HelpTarget.Models) },
                    label = { Text("Browse models") },
                    leadingIcon = { Icon(Icons.Default.FolderOpen, contentDescription = null) }
                )
            }
        }
    }
}

@Composable
private fun SetupWizardOption(
    icon: ImageVector,
    title: String,
    description: String,
    buttonText: String,
    onClick: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Button(onClick = onClick) {
                Text(buttonText)
            }
        }
    }
}
