package com.arslan.llamachat.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arslan.llamachat.llm.OnlineEngine
import kotlinx.coroutines.launch

private data class HelpdeskMessage(
    val id: Long = System.nanoTime(),
    val role: String,
    val content: String,
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpdeskScreen(
    vm: ChatViewModel,
    onBack: () -> Unit,
    onSetupKeys: () -> Unit,
) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    var selectedProvider by remember(state.groqApiKey, state.geminiApiKey) {
        mutableStateOf(
            when {
                state.groqApiKey.isNotBlank() -> "groq"
                state.geminiApiKey.isNotBlank() -> "gemini"
                else -> ""
            }
        )
    }
    var input by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(
            listOf(
                HelpdeskMessage(
                    role = "assistant",
                    content = "Hi, I’m PocketMind Helpdesk. Ask me how to use models, API keys, PDF uploads, Image Studio, privacy, chats, characters, or troubleshooting."
                )
            )
        )
    }
    var streamingText by remember { mutableStateOf("") }
    var isGenerating by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val hasGroq = state.groqApiKey.isNotBlank()
    val hasGemini = state.geminiApiKey.isNotBlank()
    val canSend = input.trim().isNotBlank() && selectedProvider.isNotBlank() && !isGenerating

    LaunchedEffect(messages.size, streamingText) {
        listState.animateScrollToItem(maxOf(0, messages.size + if (streamingText.isNotBlank()) 1 else 0))
    }

    fun askHelpdesk() {
        val question = input.trim()
        if (question.isBlank() || isGenerating) return
        val provider = selectedProvider
        val apiKey = when (provider) {
            "groq" -> state.groqApiKey
            "gemini" -> state.geminiApiKey
            else -> ""
        }
        if (apiKey.isBlank()) {
            error = "Add a Groq or Gemini API key to use the online helpdesk."
            return
        }

        val userMessage = HelpdeskMessage(role = "user", content = question)
        messages = messages + userMessage
        input = ""
        streamingText = ""
        error = null
        isGenerating = true

        val helpContext = buildPocketMindHelpContext(question)
        val systemPrompt = pocketMindHelpSystemPrompt() + "\n\n" + helpContext
        val onlineMessages = mutableListOf<Map<String, String>>()
        if (provider == "groq") {
            onlineMessages += mapOf("role" to "system", "content" to systemPrompt)
        }
        onlineMessages += messages
            .takeLast(8)
            .map { mapOf("role" to it.role, "content" to it.content) }
        onlineMessages += mapOf("role" to "user", "content" to question)

        val buffer = StringBuilder()
        scope.launch {
            val onToken: (String) -> Unit = { token ->
                buffer.append(token)
                streamingText = buffer.toString()
            }
            val onDone: () -> Unit = {
                val reply = buffer.toString().trim().ifBlank { "I could not generate a helpdesk response. Please try again." }
                messages = messages + HelpdeskMessage(role = "assistant", content = reply)
                streamingText = ""
                isGenerating = false
            }
            val onError: (String) -> Unit = { msg ->
                error = msg
                streamingText = ""
                isGenerating = false
            }

            when (provider) {
                "groq" -> OnlineEngine.streamGroq(
                    apiKey = apiKey,
                    messages = onlineMessages,
                    maxTokens = 700,
                    onToken = onToken,
                    onDone = onDone,
                    onError = onError,
                )
                "gemini" -> OnlineEngine.streamGemini(
                    apiKey = apiKey,
                    messages = onlineMessages.filter { it["role"] != "system" },
                    systemPrompt = systemPrompt,
                    maxTokens = 700,
                    onToken = onToken,
                    onDone = onDone,
                    onError = onError,
                )
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(38.dp).clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Default.HeadsetMic, null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Helpdesk", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                            Text("PocketMind app support", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { messages = messages.take(1); streamingText = "" }, enabled = messages.size > 1 && !isGenerating) {
                        Icon(Icons.Default.DeleteSweep, "Clear helpdesk chat")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = pocketMindTopBarInsets(),
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Column(Modifier.navigationBarsPadding().imePadding()) {
                    error?.let { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.errorContainer).padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(msg, modifier = Modifier.weight(1f), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall)
                            TextButton(onClick = onSetupKeys) { Text("Keys") }
                            IconButton(onClick = { error = null }, modifier = Modifier.size(30.dp)) {
                                Icon(Icons.Default.Close, null, tint = MaterialTheme.colorScheme.onErrorContainer, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    if (!hasGroq && !hasGemini) {
                        Card(
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                        ) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Key, null, tint = MaterialTheme.colorScheme.secondary)
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Online helpdesk needs an API key", fontWeight = FontWeight.Bold)
                                    Text("Add a Groq or Gemini key to ask questions about PocketMind usage.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.78f))
                                }
                                FilledTonalButton(onClick = onSetupKeys, shape = RoundedCornerShape(14.dp)) { Text("Add") }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedTextField(
                            value = input,
                            onValueChange = { input = it },
                            modifier = Modifier.weight(1f),
                            enabled = !isGenerating,
                            placeholder = { Text("Ask about using PocketMind…") },
                            minLines = 1,
                            maxLines = 4,
                            shape = RoundedCornerShape(24.dp),
                        )
                        if (isGenerating) {
                            IconButton(
                                onClick = { error = "Stopping is not available for the current online request. Please wait for the provider response." },
                                colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                            ) {
                                Icon(Icons.Default.HourglassTop, "Generating", tint = MaterialTheme.colorScheme.error)
                            }
                        } else {
                            IconButton(
                                onClick = { askHelpdesk() },
                                enabled = canSend,
                                colors = IconButtonDefaults.iconButtonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                ),
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = MaterialTheme.colorScheme.onPrimary)
                            }
                        }
                    }
                }
            }
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            ProviderSelector(
                selectedProvider = selectedProvider,
                hasGroq = hasGroq,
                hasGemini = hasGemini,
                onSelect = { selectedProvider = it },
                onSetupKeys = onSetupKeys,
            )

            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                contentPadding = PaddingValues(top = 10.dp, bottom = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                item {
                    HelpdeskWelcomeCard(onSetupKeys = onSetupKeys)
                }
                items(messages, key = { it.id }) { msg ->
                    HelpdeskBubble(msg = msg)
                }
                if (streamingText.isNotBlank()) {
                    item { HelpdeskBubble(msg = HelpdeskMessage(role = "assistant", content = streamingText + "▌")) }
                }
                if (isGenerating && streamingText.isBlank()) {
                    item {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Helpdesk is thinking…", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProviderSelector(
    selectedProvider: String,
    hasGroq: Boolean,
    hasGemini: Boolean,
    onSelect: (String) -> Unit,
    onSetupKeys: () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.SupportAgent, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("Online support assistant", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = onSetupKeys) { Text("Keys") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = selectedProvider == "groq",
                    onClick = { if (hasGroq) onSelect("groq") else onSetupKeys() },
                    label = { Text(if (hasGroq) "Groq" else "Groq key") },
                    leadingIcon = if (selectedProvider == "groq") {{ Icon(Icons.Default.Check, null, Modifier.size(16.dp)) }} else null,
                )
                FilterChip(
                    selected = selectedProvider == "gemini",
                    onClick = { if (hasGemini) onSelect("gemini") else onSetupKeys() },
                    label = { Text(if (hasGemini) "Gemini" else "Gemini key") },
                    leadingIcon = if (selectedProvider == "gemini") {{ Icon(Icons.Default.Check, null, Modifier.size(16.dp)) }} else null,
                )
            }
            Text(
                "Ask about setup, models, files, privacy, Image Studio, characters, storage, or troubleshooting.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun HelpdeskWelcomeCard(onSetupKeys: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.HeadsetMic, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Ask the PocketMind Helpdesk", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                    Text("Online answers for app setup and usage", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f))
                }
            }
            Text(
                "Examples: How do I upload a PDF? Which model should I use for coding? Why is image generation slow? What stays private in offline mode?",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.82f),
            )
            OutlinedButton(onClick = onSetupKeys, shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Default.Key, null, Modifier.size(16.dp))
                Spacer(Modifier.width(8.dp))
                Text("Manage online keys")
            }
        }
    }
}

@Composable
private fun HelpdeskBubble(msg: HelpdeskMessage) {
    val isUser = msg.role == "user"
    val context = LocalContext.current
    var showActions by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
    ) {
        if (!isUser) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)) {
                Box(Modifier.size(24.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.13f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.HeadsetMic, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(15.dp))
                }
                Spacer(Modifier.width(6.dp))
                Text("Helpdesk", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Surface(
            modifier = Modifier.widthIn(max = 330.dp).clickable { showActions = !showActions },
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isUser) 18.dp else 6.dp,
                bottomEnd = if (isUser) 6.dp else 18.dp,
            ),
            color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
        ) {
            Text(
                msg.content,
                modifier = Modifier.padding(13.dp),
                color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodyMedium,
                overflow = TextOverflow.Visible,
            )
        }

        AnimatedVisibility(showActions) {
            Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("PocketMind Helpdesk", msg.content))
                    showActions = false
                }) {
                    Icon(Icons.Default.ContentCopy, null, Modifier.size(15.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Copy")
                }
            }
        }
    }
}
