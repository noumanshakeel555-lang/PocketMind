package com.arslan.llamachat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatsScreen(vm: ChatViewModel, onOpenChat: () -> Unit, modifier: Modifier = Modifier) {
    val state by vm.state.collectAsState()
    val fmt = remember { SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()) }
    var query by remember { mutableStateOf("") }
    var renameTarget by remember { mutableStateOf<ChatSession?>(null) }
    var deleteTarget by remember { mutableStateOf<ChatSession?>(null) }

    val visibleSessions = remember(state.chatSessions, query) {
        val q = query.trim()
        state.chatSessions
            .asReversed()
            .filter { session ->
                q.isBlank() ||
                    session.title.contains(q, ignoreCase = true) ||
                    session.modelKey.contains(q, ignoreCase = true) ||
                    session.messages.any { it.content.contains(q, ignoreCase = true) }
            }
            .sortedWith(
                compareByDescending<ChatSession> { it.isPinned }
                    .thenByDescending { it.updatedAt }
                    .thenByDescending { it.id }
            )
    }

    renameTarget?.let { session ->
        RenameChatDialog(
            currentTitle = session.title,
            onDismiss = { renameTarget = null },
            onSave = { newTitle ->
                vm.renameSession(session.id, newTitle)
                renameTarget = null
            }
        )
    }

    deleteTarget?.let { session ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete chat?") },
            text = { Text("This removes the saved chat from PocketMind. It does not delete any models or files.") },
            confirmButton = {
                Button(
                    onClick = {
                        vm.deleteSession(session.id)
                        deleteTarget = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }

    Column(modifier = modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Chats", fontWeight = FontWeight.Bold, fontSize = 20.sp) },
            actions = {
                if (state.messages.isNotEmpty()) {
                    IconButton(onClick = { vm.saveSession() }) {
                        Icon(Icons.Default.Save, "Save current chat")
                    }
                }
                IconButton(onClick = { vm.newChat(); onOpenChat() }) {
                    Icon(Icons.Default.Add, "New chat")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            windowInsets = WindowInsets(0)
        )

        if (state.chatSessions.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                EmptyChatsState(onNewChat = { vm.newChat(); onOpenChat() })
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 16.dp, top = 16.dp, end = 16.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Search, null) },
                        trailingIcon = {
                            if (query.isNotBlank()) {
                                IconButton(onClick = { query = "" }) {
                                    Icon(Icons.Default.Close, "Clear search")
                                }
                            }
                        },
                        placeholder = { Text("Search saved chats…") },
                        shape = RoundedCornerShape(18.dp),
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AssistChip(
                            onClick = {},
                            label = { Text("${state.chatSessions.size} saved") },
                            leadingIcon = { Icon(Icons.Default.Chat, null, Modifier.size(16.dp)) }
                        )
                        val pinnedCount = state.chatSessions.count { it.isPinned }
                        if (pinnedCount > 0) {
                            AssistChip(
                                onClick = {},
                                label = { Text("$pinnedCount pinned") },
                                leadingIcon = { Icon(Icons.Default.Star, null, Modifier.size(16.dp)) }
                            )
                        }
                    }
                }

                if (visibleSessions.isEmpty()) {
                    item { EmptySearchCard(query) }
                } else {
                    items(visibleSessions, key = { it.id }) { session ->
                        SavedChatCard(
                            session = session,
                            fmt = fmt,
                            onOpen = { vm.loadSession(session); onOpenChat() },
                            onRename = { renameTarget = session },
                            onTogglePin = { vm.togglePinSession(session.id) },
                            onDelete = { deleteTarget = session },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyChatsState(onNewChat: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(28.dp)) {
        Icon(Icons.Default.Chat, null, modifier = Modifier.size(64.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f))
        Spacer(Modifier.height(16.dp))
        Text("No saved chats yet", color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text("Start a chat and PocketMind will keep it here so you can continue later.",
            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.75f),
            style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(16.dp))
        FilledTonalButton(onClick = onNewChat, shape = RoundedCornerShape(14.dp)) {
            Icon(Icons.Default.Add, null, Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Start new chat")
        }
    }
}

@Composable
private fun EmptySearchCard(query: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Search, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Text("No chats found", fontWeight = FontWeight.SemiBold)
            Text("Nothing matched “$query”.", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SavedChatCard(
    session: ChatSession,
    fmt: SimpleDateFormat,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onTogglePin: () -> Unit,
    onDelete: () -> Unit,
) {
    val firstMsg = cleanChatPreview(session.messages.firstOrNull { it.role == "user" }?.content ?: "Empty chat")
    val lastMsg = cleanChatPreview(session.messages.lastOrNull { it.role == "assistant" }?.content ?: "")
    val indicators = chatIndicators(session)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (session.isPinned) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant
        ),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = if (session.isPinned) 4.dp else 2.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (session.isPinned) {
                            Icon(Icons.Default.Star, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                        }
                        Text(
                            session.title.ifBlank { firstMsg },
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                    Spacer(Modifier.height(5.dp))
                    Text(
                        lastMsg.ifBlank { firstMsg },
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                IconButton(onClick = onOpen) {
                    Icon(Icons.Default.OpenInNew, "Open", tint = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Badge(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)) {
                    Text(modelLabel(session.modelKey), modifier = Modifier.padding(horizontal = 5.dp),
                        color = MaterialTheme.colorScheme.primary,
                        style = MaterialTheme.typography.labelSmall)
                }
                indicators.take(3).forEach { label ->
                    Badge(containerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.16f)) {
                        Text(label, modifier = Modifier.padding(horizontal = 5.dp),
                            color = MaterialTheme.colorScheme.secondary,
                            style = MaterialTheme.typography.labelSmall)
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    fmt.format(Date(session.updatedAt.takeIf { it > 0 } ?: session.id)),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = onTogglePin) {
                    Icon(Icons.Default.Star, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (session.isPinned) "Unpin" else "Pin")
                }
                TextButton(onClick = onRename) {
                    Icon(Icons.Default.Edit, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Rename")
                }
                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, "Delete", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun RenameChatDialog(
    currentTitle: String,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit,
) {
    var title by remember(currentTitle) { mutableStateOf(currentTitle) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rename chat") },
        text = {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it.take(80) },
                label = { Text("Chat title") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
            )
        },
        confirmButton = {
            Button(onClick = { onSave(title) }, enabled = title.isNotBlank()) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun cleanChatPreview(text: String): String = text
    .substringBefore("File content extracted for the model:")
    .substringBefore("Image attachment note:")
    .substringBefore("Attachment note:")
    .replace(Regex("\\s+"), " ")
    .trim()
    .ifBlank { "Attachment message" }

private fun chatIndicators(session: ChatSession): List<String> {
    val all = session.messages.joinToString("\n") { it.content }
    val labels = mutableListOf<String>()
    if (all.contains("[Attached file:", ignoreCase = true)) labels += "Files"
    if (all.contains("image/", ignoreCase = true) || all.contains("Image attachment note", ignoreCase = true)) labels += "Photo"
    if (all.contains("application/pdf", ignoreCase = true) || all.contains(".pdf", ignoreCase = true)) labels += "PDF"
    if (all.contains("wordprocessingml", ignoreCase = true) || all.contains(".docx", ignoreCase = true)) labels += "DOCX"
    return labels.distinct()
}

private fun modelLabel(key: String): String = when (key) {
    "groq" -> "Groq"
    "gemini" -> "Gemini"
    "custom" -> "Custom GGUF"
    "tinyllama" -> "TinyLlama"
    "gemma2b" -> "Gemma"
    "phi35" -> "Phi"
    "llama32_3b" -> "Llama 3.2"
    "llama31_8b" -> "Llama 3.1"
    "mistral" -> "Mistral"
    "qwen25_7b", "qwen25_3b" -> "Qwen"
    "deepseek_7b" -> "DeepSeek"
    "mistral_nemo" -> "Nemo"
    else -> key
}
