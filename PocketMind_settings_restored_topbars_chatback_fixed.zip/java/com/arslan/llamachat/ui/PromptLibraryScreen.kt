package com.arslan.llamachat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class PromptItem(
    val title: String,
    val prompt: String,
    val category: String,
    val icon: ImageVector,
    val accent: Color,
)

private val promptLibrary = listOf(
    PromptItem(
        title = "Summarize a PDF or chapter",
        prompt = "Summarize the attached document in simple language. Give me the main ideas, important definitions, examples, and a short exam-focused revision section.",
        category = "Study",
        icon = Icons.Default.School,
        accent = Color(0xFF7C4DFF),
    ),
    PromptItem(
        title = "Make exam MCQs",
        prompt = "Create exam-style MCQs from this topic/document. Include 15 questions, four options each, the correct answer, and a one-line explanation for each answer.",
        category = "Study",
        icon = Icons.Default.Quiz,
        accent = Color(0xFF7C4DFF),
    ),
    PromptItem(
        title = "Explain like I am new",
        prompt = "Explain this topic like I am a beginner. Start from intuition, then formulas/steps, then solve one easy example and one exam-style example.",
        category = "Study",
        icon = Icons.Default.MenuBook,
        accent = Color(0xFF7C4DFF),
    ),
    PromptItem(
        title = "Debug code carefully",
        prompt = "Debug this code carefully. Tell me the exact issue, why it happens, the smallest safe fix, and then provide the corrected code without changing unrelated logic.",
        category = "Coding",
        icon = Icons.Default.Code,
        accent = Color(0xFF00A67E),
    ),
    PromptItem(
        title = "Explain an error log",
        prompt = "Explain this error log in simple words. Identify the real failing line, separate warnings from real errors, and give me exact steps to fix it safely.",
        category = "Coding",
        icon = Icons.Default.BugReport,
        accent = Color(0xFF00A67E),
    ),
    PromptItem(
        title = "Improve code quality",
        prompt = "Review this code like a senior engineer. Keep the behavior the same, point out risky parts, and suggest clean improvements that will not break existing functionality.",
        category = "Coding",
        icon = Icons.Default.Engineering,
        accent = Color(0xFF00A67E),
    ),
    PromptItem(
        title = "Write a client email",
        prompt = "Write a professional client outreach email. Make it short, respectful, specific to their business, and focused on how my AI/software service can solve a real problem for them.",
        category = "Business",
        icon = Icons.Default.Email,
        accent = Color(0xFFFF9800),
    ),
    PromptItem(
        title = "Create a proposal",
        prompt = "Create a clear project proposal with problem, solution, features, timeline, price, deliverables, and a confident but professional closing section.",
        category = "Business",
        icon = Icons.Default.BusinessCenter,
        accent = Color(0xFFFF9800),
    ),
    PromptItem(
        title = "Social media post",
        prompt = "Create an attractive social media post for this product/service. Give me a hook, caption, benefits, call-to-action, hashtags, and a short version for Instagram/Facebook.",
        category = "Business",
        icon = Icons.Default.Campaign,
        accent = Color(0xFFFF9800),
    ),
    PromptItem(
        title = "Image generation prompt",
        prompt = "Turn this idea into a high-quality Stable Diffusion prompt. Include subject, style, lighting, camera details, background, quality words, and a negative prompt.",
        category = "Images",
        icon = Icons.Default.Image,
        accent = Color(0xFFE91E63),
    ),
    PromptItem(
        title = "Character portrait prompt",
        prompt = "Create a detailed image prompt for a character portrait. Include face, outfit, personality, pose, background, lighting, style, and negative prompt.",
        category = "Images",
        icon = Icons.Default.Person,
        accent = Color(0xFFE91E63),
    ),
    PromptItem(
        title = "Think step by step",
        prompt = "Solve this carefully. First restate the problem, then list what is known, choose the method, solve step by step, and give the final answer clearly.",
        category = "General",
        icon = Icons.Default.Psychology,
        accent = Color(0xFF4285F4),
    ),
    PromptItem(
        title = "Make a plan",
        prompt = "Make a practical step-by-step plan for this goal. Keep it realistic, prioritize the safest first steps, and tell me what to do today, this week, and this month.",
        category = "General",
        icon = Icons.Default.Checklist,
        accent = Color(0xFF4285F4),
    ),
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PromptLibraryScreen(
    onBack: () -> Unit,
    onUsePrompt: (String) -> Unit,
) {
    var selectedCategory by remember { mutableStateOf("All") }
    var query by remember { mutableStateOf("") }
    val categories = remember { listOf("All") + promptLibrary.map { it.category }.distinct() }
    val visiblePrompts = remember(selectedCategory, query) {
        val q = query.trim()
        promptLibrary.filter { item ->
            (selectedCategory == "All" || item.category == selectedCategory) &&
                (q.isBlank() || item.title.contains(q, ignoreCase = true) ||
                    item.prompt.contains(q, ignoreCase = true) || item.category.contains(q, ignoreCase = true))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Prompt Library", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text("Ready-made prompts for better results", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = pocketMindTopBarInsets(),
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                PromptHeroCard()
            }
            item {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Default.Search, null) },
                    trailingIcon = {
                        if (query.isNotBlank()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, "Clear") }
                    },
                    placeholder = { Text("Search prompts…") },
                    shape = RoundedCornerShape(18.dp),
                )
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    categories.take(3).forEach { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text(category) },
                        )
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    categories.drop(3).forEach { category ->
                        FilterChip(
                            selected = selectedCategory == category,
                            onClick = { selectedCategory = category },
                            label = { Text(category) },
                        )
                    }
                }
            }
            if (visiblePrompts.isEmpty()) {
                item {
                    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SearchOff, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(8.dp))
                            Text("No prompts found", fontWeight = FontWeight.Bold)
                            Text("Try another search or category.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            } else {
                items(visiblePrompts, key = { it.title }) { prompt ->
                    PromptCard(item = prompt, onUse = { onUsePrompt(prompt.prompt) })
                }
            }
        }
    }
}

@Composable
private fun PromptHeroCard() {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(28.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer), elevation = CardDefaults.cardElevation(3.dp)) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Start smarter", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text("Pick a polished prompt, edit it in chat, and send when ready.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f))
            }
        }
    }
}

@Composable
private fun PromptCard(item: PromptItem, onUse: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onUse),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(1.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(item.accent.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                    Icon(item.icon, null, tint = item.accent)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(item.category, style = MaterialTheme.typography.labelSmall, color = item.accent, fontWeight = FontWeight.SemiBold)
                }
                Icon(Icons.Default.ArrowForward, null, tint = MaterialTheme.colorScheme.primary)
            }
            Text(item.prompt, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
            FilledTonalButton(onClick = onUse, shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.AddComment, null, Modifier.size(17.dp))
                Spacer(Modifier.width(8.dp))
                Text("Use this prompt")
            }
        }
    }
}
