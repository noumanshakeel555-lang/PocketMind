package com.arslan.llamachat.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private const val PRIVACY_POLICY_URL = "https://mshakeelbsai25seecs-star.github.io/portfolio-website.github.io/#privacy"

@Composable
fun PrivacyConsentGate(
    onAccepted: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    var accepted by remember { mutableStateOf(false) }
    var showDetails by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background,
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                            MaterialTheme.colorScheme.background,
                            MaterialTheme.colorScheme.background,
                        )
                    )
                )
        ) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 28.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                item {
                    Box(
                        modifier = Modifier
                            .size(74.dp)
                            .clip(RoundedCornerShape(26.dp))
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Icon(
                            imageVector = Icons.Default.PrivacyTip,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(42.dp),
                        )
                    }
                }

                item {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "Privacy Policy Agreement",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 28.sp,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onBackground,
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Before using PocketMind Hybrid AI, please review and accept how offline AI, online providers, file attachments, API keys, and generated content are handled.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.72f),
                            textAlign = TextAlign.Center,
                            lineHeight = 22.sp,
                        )
                    }
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(28.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.72f)),
                    ) {
                        Column(
                            modifier = Modifier.padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            ConsentPoint(
                                icon = Icons.Default.Memory,
                                title = "Offline AI stays on your device",
                                body = "When you use local GGUF models, prompts, chats, document text, and responses are processed locally and are not sent to PocketMind servers."
                            )
                            ConsentPoint(
                                icon = Icons.Default.Cloud,
                                title = "Online AI is optional",
                                body = "If you choose an online provider, the needed prompt, context, files, images, or image prompts may be sent directly to that provider."
                            )
                            ConsentPoint(
                                icon = Icons.Default.Key,
                                title = "API keys are stored locally",
                                body = "Provider API keys are saved on this device and are used only to call the selected provider from your device."
                            )
                            ConsentPoint(
                                icon = Icons.Default.Description,
                                title = "Attachments follow the selected mode",
                                body = "Documents are extracted locally first. Offline models keep that text local; online models may send it to the selected provider."
                            )
                            ConsentPoint(
                                icon = Icons.Default.Image,
                                title = "Image generation and images are user-controlled",
                                body = "Generated images are saved only when you choose to save them. Online image providers may receive your prompt and generation settings."
                            )
                        }
                    }
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(24.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.85f)),
                    ) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Security, null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    text = "Important AI Notice",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            }
                            Text(
                                text = "AI responses can be inaccurate, incomplete, outdated, or unsuitable for professional decisions. Do not rely on PocketMind as a substitute for medical, legal, financial, safety, or other licensed professional advice.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.82f),
                                lineHeight = 19.sp,
                            )
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { showDetails = !showDetails },
                            shape = RoundedCornerShape(18.dp),
                        ) {
                            Text(if (showDetails) "Hide Policy Summary" else "Read Policy Summary")
                        }
                        OutlinedButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                runCatching {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(PRIVACY_POLICY_URL)))
                                }
                            },
                            shape = RoundedCornerShape(18.dp),
                        ) {
                            Text("Open Full Privacy Policy")
                        }
                    }
                }

                if (showDetails) {
                    item {
                        PolicyDetailsCard()
                    }
                }

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Checkbox(
                                checked = accepted,
                                onCheckedChange = { accepted = it },
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "I have read and agree to the PocketMind Hybrid AI Privacy Policy and understand how offline and online AI features handle my data.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.86f),
                                lineHeight = 18.sp,
                            )
                        }
                    }
                }

                item {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp),
                            enabled = accepted,
                            onClick = onAccepted,
                            shape = RoundedCornerShape(18.dp),
                        ) {
                            Icon(Icons.Default.CheckCircle, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Accept & Continue", fontWeight = FontWeight.Bold)
                        }
                        TextButton(
                            modifier = Modifier.fillMaxWidth(),
                            onClick = { (context as? Activity)?.finish() },
                        ) {
                            Text("Decline and Exit")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConsentPoint(icon: ImageVector, title: String, body: String) {
    Row(verticalAlignment = Alignment.Top) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(
                body,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.78f),
                lineHeight = 18.sp,
            )
        }
    }
}

@Composable
private fun PolicyDetailsCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Policy Summary", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Text(
                text = "PocketMind Hybrid AI does not operate a developer cloud server to collect or sell your chats, files, API keys, or generated content. Local model chats, imported models, settings, custom characters, and API keys are stored on your device. Online AI features are optional and require sending the needed request data directly to the selected third-party provider. Data sent to third-party providers is handled under that provider's own privacy policy and terms. You can delete local data by deleting chats, removing models, clearing app data, deleting backups, removing API keys, or uninstalling the app.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.82f),
                lineHeight = 19.sp,
            )
        }
    }
}
