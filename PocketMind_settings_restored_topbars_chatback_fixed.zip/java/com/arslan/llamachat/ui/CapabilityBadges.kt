package com.arslan.llamachat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun CapabilityBadges(
    labels: List<String>,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
) {
    val rows = labels.chunked(if (compact) 3 else 2)
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        rows.forEach { rowLabels ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                rowLabels.forEach { label ->
                    CapabilityBadge(label = label, compact = compact)
                }
            }
        }
    }
}

@Composable
private fun CapabilityBadge(label: String, compact: Boolean) {
    val positive = !label.startsWith("No ") && !label.startsWith("Needs ") && !label.startsWith("Limited") && !label.startsWith("Not ")
    val bg = if (positive) {
        MaterialTheme.colorScheme.primaryContainer
    } else {
        MaterialTheme.colorScheme.errorContainer
    }
    val fg = if (positive) {
        MaterialTheme.colorScheme.onPrimaryContainer
    } else {
        MaterialTheme.colorScheme.onErrorContainer
    }
    Text(
        text = label,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .background(bg)
            .padding(horizontal = if (compact) 8.dp else 10.dp, vertical = if (compact) 4.dp else 5.dp),
        style = if (compact) MaterialTheme.typography.labelSmall else MaterialTheme.typography.bodySmall,
        color = fg,
        fontWeight = FontWeight.SemiBold,
    )
}

fun localModelCapabilityLabels(): List<String> = listOf(
    "Offline",
    "Text chat",
    "PDF/DOCX text",
    "Code/files",
    "No photo vision yet",
)

fun domainModelCapabilityLabels(category: String): List<String> = when (category) {
    "Coding" -> listOf("Offline", "Code", "Debugging", "Files", "No photo vision yet")
    "Study" -> listOf("Offline", "Math", "Exams", "PDF/DOCX text", "No photo vision yet")
    "Medical" -> listOf("Offline", "Biomedical", "Study only", "PDF/DOCX text", "Not medical advice")
    "Law" -> listOf("Offline", "Legal text", "Study only", "PDF/DOCX text", "Not legal advice")
    "Business" -> listOf("Offline", "Writing", "Proposals", "PDF/DOCX text", "No photo vision yet")
    "Small" -> listOf("Offline", "Fast", "Low RAM", "Testing", "No photo vision yet")
    "Large" -> listOf("Offline", "High quality", "More RAM", "Long answers", "No photo vision yet")
    else -> localModelCapabilityLabels()
}

fun customModelCapabilityLabels(): List<String> = listOf(
    "Offline",
    "Custom GGUF",
    "Text chat",
    "PDF/DOCX text",
    "No photo vision yet",
)

fun onlineModelCapabilityLabels(provider: String): List<String> = when (provider) {
    "groq" -> listOf("Online", "Fast text", "Photo vision", "PDF/DOCX text", "Requires key")
    "gemini" -> listOf("Online", "Text", "Photo vision", "PDF/DOCX text", "Requires key")
    else -> listOf("Online", "Text", "Requires key")
}

fun attachmentCompatibilityLabel(
    isImage: Boolean,
    hasText: Boolean,
    activeProvider: String,
    offlineSelected: Boolean,
): String = when {
    isImage && activeProvider == "gemini" -> "Ready: Gemini can understand this photo."
    isImage && activeProvider == "groq" -> "Ready: Groq will use a vision model for this photo."
    isImage && offlineSelected -> "Limited: offline text models cannot see photo pixels yet."
    isImage -> "Photo attached. Select Gemini or Groq for image understanding."
    hasText -> "Ready: extracted text will be sent to the model."
    else -> "Attached, but no readable text was extracted."
}
