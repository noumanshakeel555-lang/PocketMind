package com.arslan.llamachat.ui

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp

@Composable
fun pocketMindTopBarInsets(extraTopPadding: androidx.compose.ui.unit.Dp = 0.dp): WindowInsets {
    val density = LocalDensity.current
    val safeTop = with(density) { WindowInsets.safeDrawing.getTop(this).toDp() }
    val balancedTop = when {
        safeTop <= 0.dp -> 10.dp
        safeTop < 20.dp -> 12.dp
        safeTop < 32.dp -> safeTop - 4.dp
        else -> safeTop - 6.dp
    }.coerceAtLeast(10.dp)
    return WindowInsets(top = balancedTop + extraTopPadding)
}
