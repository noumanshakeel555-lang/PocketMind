package com.arslan.llamachat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.arslan.llamachat.llm.IMAGE_MODELS
import com.arslan.llamachat.llm.ImageModelInfo
import com.arslan.llamachat.llm.ImageModelManager
import com.arslan.llamachat.llm.MODELS
import com.arslan.llamachat.llm.ModelInfo
import com.arslan.llamachat.llm.ModelManager
import java.io.File
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StorageManagerScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val state by vm.state.collectAsState()
    var refreshKey by remember { mutableStateOf(0) }
    var pendingDelete by remember { mutableStateOf<DeleteTarget?>(null) }

    val llmModels = remember(refreshKey) { MODELS.filter { ModelManager.isDownloaded(context, it) } }
    val imageModels = remember(refreshKey) { IMAGE_MODELS.filter { ImageModelManager.isDownloaded(context, it) } }
    val llmBytes = remember(refreshKey) { llmModels.sumOf { ModelManager.modelFile(context, it).length() } }
    val imageBytes = remember(refreshKey) { imageModels.sumOf { ImageModelManager.modelFile(context, it).length() } }
    val cacheBytes = remember(refreshKey) { folderSize(context.cacheDir) }
    val chatCount = state.chatSessions.size

    pendingDelete?.let { target ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text(target.title) },
            text = { Text(target.message) },
            confirmButton = {
                Button(
                    onClick = {
                        target.action()
                        vm.refreshDownloadedModels()
                        refreshKey++
                        pendingDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Storage Manager", fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = pocketMindTopBarInsets()
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                StorageHeroCard(totalBytes = llmBytes + imageBytes + cacheBytes)
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StorageStatCard("LLM Models", formatStorageSize(llmBytes), Icons.Default.Memory, Modifier.weight(1f))
                    StorageStatCard("Image Models", formatStorageSize(imageBytes), Icons.Default.Image, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StorageStatCard("Cache", formatStorageSize(cacheBytes), Icons.Default.FolderOpen, Modifier.weight(1f))
                    StorageStatCard("Saved Chats", chatCount.toString(), Icons.Default.Chat, Modifier.weight(1f))
                }
            }

            item {
                StorageSectionHeader(
                    icon = Icons.Default.Memory,
                    title = "Offline LLM Models",
                    subtitle = "Delete unused GGUF models safely. Active model files can be downloaded again later."
                )
            }

            if (llmModels.isEmpty()) {
                item { EmptyStorageCard("No offline LLM models downloaded yet.") }
            } else {
                items(llmModels, key = { it.key }) { model ->
                    LlmStorageRow(
                        model = model,
                        isActive = state.loadedModel?.key == model.key || state.customGgufName == model.file,
                        onDelete = {
                            val file = ModelManager.modelFile(context, model)
                            pendingDelete = DeleteTarget(
                                title = "Delete ${model.displayName}?",
                                message = "This will remove ${formatStorageSize(file.length())} from local storage. The file can be downloaded again later.",
                                action = { ModelManager.delete(context, model) }
                            )
                        }
                    )
                }
            }

            item {
                StorageSectionHeader(
                    icon = Icons.Default.Image,
                    title = "Image Generation Models",
                    subtitle = "Stable Diffusion files are large. Remove unused models to free storage."
                )
            }

            if (imageModels.isEmpty()) {
                item { EmptyStorageCard("No image models downloaded yet.") }
            } else {
                items(imageModels, key = { it.key }) { model ->
                    ImageModelStorageRow(
                        model = model,
                        onDelete = {
                            val file = ImageModelManager.modelFile(context, model)
                            pendingDelete = DeleteTarget(
                                title = "Delete ${model.displayName}?",
                                message = "This will remove ${formatStorageSize(file.length())} from local storage. The file can be downloaded or imported again later.",
                                action = { ImageModelManager.delete(context, model) }
                            )
                        }
                    )
                }
            }

            item {
                StorageSectionHeader(
                    icon = Icons.Default.DeleteSweep,
                    title = "App Cache",
                    subtitle = "Temporary files only. Clearing cache does not delete downloaded models."
                )
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Temporary cache", fontWeight = FontWeight.SemiBold)
                            Text(formatStorageSize(cacheBytes), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        OutlinedButton(
                            onClick = {
                                pendingDelete = DeleteTarget(
                                    title = "Clear temporary cache?",
                                    message = "This removes temporary app files only. Downloaded models are kept.",
                                    action = { context.cacheDir.deleteRecursively(); context.cacheDir.mkdirs() }
                                )
                            },
                            enabled = cacheBytes > 0L,
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("Clear") }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Generated images saved to the phone gallery are managed by the gallery app. PocketMind manages only private app files here.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

private data class DeleteTarget(
    val title: String,
    val message: String,
    val action: () -> Unit,
)

@Composable
private fun StorageHeroCard(totalBytes: Long) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(26.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(58.dp).clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.FolderOpen, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(30.dp))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text("Manage PocketMind storage", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(
                    "Private app files using ${formatStorageSize(totalBytes)}. Review large models and keep storage organized.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f)
                )
            }
        }
    }
}

@Composable
private fun StorageStatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier = modifier, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun StorageSectionHeader(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier.size(38.dp).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun EmptyStorageCard(text: String) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF4CAF50))
            Spacer(Modifier.width(10.dp))
            Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun LlmStorageRow(model: ModelInfo, isActive: Boolean, onDelete: () -> Unit) {
    val file = ModelManager.modelFile(LocalContext.current, model)
    StorageFileRow(
        icon = Icons.Default.Memory,
        title = model.displayName,
        subtitle = "${model.category} · ${formatStorageSize(file.length())}${if (isActive) " · Active" else ""}",
        warning = isActive,
        onDelete = onDelete,
    )
}

@Composable
private fun ImageModelStorageRow(model: ImageModelInfo, onDelete: () -> Unit) {
    val file = ImageModelManager.modelFile(LocalContext.current, model)
    StorageFileRow(
        icon = Icons.Default.Image,
        title = model.displayName,
        subtitle = "${formatStorageSize(file.length())} · Best ${model.bestSize}×${model.bestSize}, ${model.bestSteps} steps",
        warning = false,
        onDelete = onDelete,
    )
}

@Composable
private fun StorageFileRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    warning: Boolean,
    onDelete: () -> Unit,
) {
    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(15.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(title, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    if (warning) {
                        Spacer(Modifier.width(6.dp))
                        AssistChip(
                            onClick = {},
                            label = { Text("Active", style = MaterialTheme.typography.labelSmall) },
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

private fun folderSize(file: File?): Long {
    if (file == null || !file.exists()) return 0L
    if (file.isFile) return file.length()
    return file.listFiles()?.sumOf { folderSize(it) } ?: 0L
}

private fun formatStorageSize(bytes: Long): String = when {
    bytes < 1024L -> "$bytes B"
    bytes < 1024L * 1024L -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
    bytes < 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1f MB", bytes / 1024.0 / 1024.0)
    else -> String.format(Locale.US, "%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0)
}
