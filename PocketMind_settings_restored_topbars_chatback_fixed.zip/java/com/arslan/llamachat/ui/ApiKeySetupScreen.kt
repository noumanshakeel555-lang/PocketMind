package com.arslan.llamachat.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arslan.llamachat.llm.Prefs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ApiKeySetupScreen(vm: ChatViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current
    var groqKey by remember { mutableStateOf(state.groqApiKey) }
    var geminiKey by remember { mutableStateOf(state.geminiApiKey) }
    var groqVisible by remember { mutableStateOf(false) }
    var geminiVisible by remember { mutableStateOf(false) }
    var groqValidating by remember { mutableStateOf(false) }
    var geminiValidating by remember { mutableStateOf(false) }
    var groqStatus by remember { mutableStateOf<Boolean?>(null) }
    var geminiStatus by remember { mutableStateOf<Boolean?>(null) }

    var hfImageKey by remember { mutableStateOf(Prefs.getString(context, "hfImageApiKey", "")) }
    var togetherImageKey by remember { mutableStateOf(Prefs.getString(context, "togetherImageApiKey", "")) }
    var hfImageVisible by remember { mutableStateOf(false) }
    var togetherImageVisible by remember { mutableStateOf(false) }
    var hfImageValidating by remember { mutableStateOf(false) }
    var togetherImageValidating by remember { mutableStateOf(false) }
    var hfImageStatus by remember { mutableStateOf<Boolean?>(null) }
    var togetherImageStatus by remember { mutableStateOf<Boolean?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Online Models Setup", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = pocketMindTopBarInsets()
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)
            .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)) {

            InfoCard(
                title = "What are API keys?",
                body = "An API key authorizes PocketMind to connect directly to an online AI service. Keys are created by the account holder, stored only on-device, and sent directly from the phone to the selected provider. PocketMind does not proxy, view, or store keys on any server."
            )


            InfoCard(
                title = "Online provider keys",
                body = "Groq and Gemini power fast chat and photo understanding. Hugging Face and Together AI can be used for online chat models and image generation. Offline models remain fully on-device."
            )

            ProviderCard(
                name = "Groq",
                modelName = "Llama 3.3 70B + Llama 4 Scout Vision",
                speed = "~1–2 seconds",
                limit = "Text + photo vision with provider API key",
                color = Color(0xFF00A67E),
                url = "https://console.groq.com/keys",
                steps = listOf(
                    "Go to console.groq.com (tap button below)",
                    "Create a free account or sign in",
                    "Click 'API Keys' in the left menu",
                    "Click 'Create API Key'",
                    "Copy the key and paste it below"
                ),
                apiKey = groqKey,
                keyVisible = groqVisible,
                validating = groqValidating,
                status = groqStatus,
                onKeyChange = { groqKey = it; groqStatus = null },
                onToggleVisible = { groqVisible = !groqVisible },
                onOpenUrl = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.groq.com/keys"))) },
                onSave = {
                    groqValidating = true
                    groqStatus = null
                    vm.validateAndSaveGroqKey(groqKey) { ok ->
                        groqValidating = false
                        groqStatus = ok
                    }
                },
                onClear = { groqKey = ""; groqStatus = null; vm.clearGroqKey() }
            )

            ProviderCard(
                name = "Google Gemini",
                modelName = "Gemini 2.5 Flash",
                speed = "~1–3 seconds",
                limit = "Free-tier when available",
                color = Color(0xFF4285F4),
                url = "https://aistudio.google.com/app/apikey",
                steps = listOf(
                    "Go to aistudio.google.com (tap button below)",
                    "Sign in with a Google account",
                    "Click 'Get API key' or 'Create API key'",
                    "Copy the key and paste it below"
                ),
                apiKey = geminiKey,
                keyVisible = geminiVisible,
                validating = geminiValidating,
                status = geminiStatus,
                onKeyChange = { geminiKey = it; geminiStatus = null },
                onToggleVisible = { geminiVisible = !geminiVisible },
                onOpenUrl = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/app/apikey"))) },
                onSave = {
                    geminiValidating = true
                    geminiStatus = null
                    vm.validateAndSaveGeminiKey(geminiKey) { ok ->
                        geminiValidating = false
                        geminiStatus = ok
                    }
                },
                onClear = { geminiKey = ""; geminiStatus = null; vm.clearGeminiKey() }
            )

            ProviderCard(
                name = "Hugging Face",
                modelName = "Chat models + FLUX.1 Schnell",
                speed = "Free-tier / variable",
                limit = "HF token required",
                color = Color(0xFFFFC107),
                url = "https://huggingface.co/settings/tokens",
                steps = listOf(
                    "Go to huggingface.co/settings/tokens",
                    "Sign in or create an account",
                    "Create a token with inference access",
                    "Copy the token and paste it below"
                ),
                apiKey = hfImageKey,
                keyVisible = hfImageVisible,
                validating = hfImageValidating,
                status = hfImageStatus,
                onKeyChange = { hfImageKey = it; hfImageStatus = null },
                onToggleVisible = { hfImageVisible = !hfImageVisible },
                onOpenUrl = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://huggingface.co/settings/tokens"))) },
                onSave = {
                    val clean = hfImageKey.trim()
                    hfImageValidating = true
                    hfImageStatus = null
                    vm.validateAndSaveHuggingFaceKey(clean) { ok ->
                        hfImageValidating = false
                        hfImageStatus = ok
                        if (ok) hfImageKey = clean
                    }
                },
                onClear = {
                    hfImageKey = ""
                    hfImageStatus = null
                    vm.saveHuggingFaceKey("")
                }
            )

            ProviderCard(
                name = "Together AI",
                modelName = "Llama/Qwen chat + FLUX/SDXL images",
                speed = "Fast / premium",
                limit = "Together AI key required",
                color = Color(0xFF7C4DFF),
                url = "https://api.together.ai/settings/api-keys",
                steps = listOf(
                    "Go to api.together.ai/settings/api-keys",
                    "Sign in or create an account",
                    "Create an API key",
                    "Copy the key and paste it below"
                ),
                apiKey = togetherImageKey,
                keyVisible = togetherImageVisible,
                validating = togetherImageValidating,
                status = togetherImageStatus,
                onKeyChange = { togetherImageKey = it; togetherImageStatus = null },
                onToggleVisible = { togetherImageVisible = !togetherImageVisible },
                onOpenUrl = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://api.together.ai/settings/api-keys"))) },
                onSave = {
                    val clean = togetherImageKey.trim()
                    togetherImageValidating = true
                    togetherImageStatus = null
                    vm.validateAndSaveTogetherKey(clean) { ok ->
                        togetherImageValidating = false
                        togetherImageStatus = ok
                        if (ok) togetherImageKey = clean
                    }
                },
                onClear = {
                    togetherImageKey = ""
                    togetherImageStatus = null
                    vm.saveTogetherKey("")
                }
            )

            Card(modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("API keys remain on-device", fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium)
                        Text("Keys are saved locally and sent directly to the selected provider. PocketMind does not send API keys to a PocketMind-owned server; keys are used from your device to contact the selected provider.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun InfoCard(title: String, body: String) {
    Card(modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            }
            Spacer(Modifier.height(8.dp))
            Text(body, style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun ProviderCard(
    name: String, modelName: String, speed: String, limit: String,
    color: Color, url: String, steps: List<String>,
    apiKey: String, keyVisible: Boolean,
    validating: Boolean, status: Boolean?,
    onKeyChange: (String) -> Unit, onToggleVisible: () -> Unit,
    onOpenUrl: () -> Unit, onSave: () -> Unit, onClear: () -> Unit,
) {
    var showSteps by remember { mutableStateOf(apiKey.isBlank()) }

    Card(modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(color),
                    contentAlignment = Alignment.Center) {
                    Text(name.first().toString(), color = Color.White,
                        fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text(modelName, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (status == true) {
                    Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF4CAF50),
                        modifier = Modifier.size(24.dp))
                }
            }

            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("⚡ $speed", Color(0xFF4CAF50))
                Chip(limit, MaterialTheme.colorScheme.primary)
            }

            Spacer(Modifier.height(12.dp))
            TextButton(onClick = { showSteps = !showSteps },
                contentPadding = PaddingValues(0.dp)) {
                Icon(if (showSteps) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text(if (showSteps) "Hide instructions" else "How to get a provider API key",
                    style = MaterialTheme.typography.bodySmall)
            }

            AnimatedVisibility(showSteps) {
                Column {
                    steps.forEachIndexed { i, step ->
                        Row(modifier = Modifier.padding(vertical = 3.dp),
                            verticalAlignment = Alignment.Top) {
                            Box(Modifier.size(22.dp).clip(RoundedCornerShape(11.dp))
                                .background(color.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center) {
                                Text("${i + 1}", style = MaterialTheme.typography.labelSmall,
                                    color = color, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(step, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 2.dp))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onOpenUrl, modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = color)) {
                        Icon(Icons.Default.OpenInBrowser, null, Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Open $name website")
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }

            OutlinedTextField(
                value = apiKey,
                onValueChange = onKeyChange,
                modifier = Modifier.fillMaxWidth(),
                label = { Text("$name API Key") },
                placeholder = { Text("Paste API key") },
                visualTransformation = if (keyVisible) VisualTransformation.None
                else PasswordVisualTransformation(),
                trailingIcon = {
                    IconButton(onClick = onToggleVisible) {
                        Icon(if (keyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                    }
                },
                isError = status == false,
                supportingText = when (status) {
                    true  -> {{ Text("✓ Key verified and saved", color = Color(0xFF4CAF50)) }}
                    false -> {{ Text("✗ Invalid key or provider access unavailable — please check and try again",
                        color = MaterialTheme.colorScheme.error) }}
                    null  -> null
                },
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
            )

            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onSave, modifier = Modifier.weight(1f),
                    enabled = apiKey.isNotBlank() && !validating) {
                    if (validating) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.Check, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (validating) "Verifying…" else "Save & Verify")
                }
                if (apiKey.isNotBlank()) {
                    OutlinedButton(onClick = onClear) {
                        Text("Clear")
                    }
                }
            }
        }
    }
}

@Composable
fun Chip(text: String, color: Color) {
    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(color.copy(alpha = 0.12f))
        .padding(horizontal = 8.dp, vertical = 4.dp)) {
        Text(text, style = MaterialTheme.typography.labelSmall, color = color,
            fontWeight = FontWeight.SemiBold)
    }
}
