package com.arslan.llamachat.ui

private data class HelpTopic(
    val title: String,
    val keywords: List<String>,
    val body: String,
)

private val helpTopics = listOf(
    HelpTopic(
        title = "Getting started",
        keywords = listOf("start", "setup", "begin", "first", "wizard", "home"),
        body = "PocketMind has a Home screen, Models tab, Chats tab, Image Studio, and Settings. For first-time setup, open Setup Wizard or Models. Online models require an API key. Offline GGUF models must be downloaded or imported before offline chat can start."
    ),
    HelpTopic(
        title = "Offline text models",
        keywords = listOf("offline", "gguf", "download", "local", "model", "llama", "qwen", "mistral", "gemma"),
        body = "Offline text models run on the device using GGUF files. Download a recommended model from Models or import a custom GGUF file. Smaller models are faster and use less RAM. Larger models provide better quality but need more memory and may be slow on low-end phones."
    ),
    HelpTopic(
        title = "Online text models",
        keywords = listOf("online", "groq", "gemini", "api", "key", "cloud", "fast"),
        body = "Online chat uses Groq or Google Gemini with the API key stored locally on the device. Online mode is faster and supports photo understanding when the selected provider supports vision. Prompts are sent directly to the selected provider only when online mode is used."
    ),
    HelpTopic(
        title = "API keys",
        keywords = listOf("api", "key", "groq", "gemini", "hugging", "together", "token"),
        body = "API keys are managed from Online Models Setup. Groq and Gemini keys power online chat and photo understanding. Hugging Face and Together AI keys power optional online image generation. Keys are saved locally and are not sent to a PocketMind server."
    ),
    HelpTopic(
        title = "Files and document uploads",
        keywords = listOf("pdf", "docx", "file", "upload", "attachment", "document", "txt", "code", "csv", "json"),
        body = "PocketMind can attach and extract text from PDFs, DOCX files, TXT, Markdown, CSV, JSON, logs, and code files. Offline models keep extracted text on-device; online models send the needed request content to the selected provider. Large files are trimmed for stability. Scanned image-only PDFs need OCR, which may not be available yet."
    ),
    HelpTopic(
        title = "Photo understanding",
        keywords = listOf("photo", "image", "vision", "picture", "camera"),
        body = "Photo understanding works through online vision-capable models such as Gemini or Groq vision. Offline text-only GGUF models cannot see image pixels yet, so offline mode receives only an attachment note for photos."
    ),
    HelpTopic(
        title = "Image Studio",
        keywords = listOf("image studio", "generate image", "pollinations", "stable diffusion", "flux", "sdxl", "offline image", "premium online"),
        body = "Image Studio supports Offline, Free-Tier Online, and Premium Online image generation. Offline keeps generation on-device but can be slow. Online modes send the prompt and generation settings to the selected provider. Pollinations may work without an API key; premium providers such as Together AI require a key."
    ),
    HelpTopic(
        title = "Characters and personas",
        keywords = listOf("character", "persona", "voice", "tts", "assistant"),
        body = "Characters change the assistant personality and optional voice behavior. Built-in characters are available, and custom characters can be created with a name, avatar, description, and system prompt. TTS can read responses aloud when enabled."
    ),
    HelpTopic(
        title = "Chats and saved sessions",
        keywords = listOf("chat", "saved", "session", "history", "pin", "rename", "delete"),
        body = "Chats can be saved, renamed, pinned, searched, reopened, and deleted from the Chats tab. The current chat can be saved from the chat menu. Deleting a saved chat does not delete downloaded models."
    ),
    HelpTopic(
        title = "Privacy and online behavior",
        keywords = listOf("privacy", "private", "data", "server", "safe", "offline", "online"),
        body = "Offline GGUF chat runs locally on the device. Online models send only the request content to the selected provider. API keys are stored on-device. Backup files should be kept private because they may include saved conversations and custom prompts."
    ),
    HelpTopic(
        title = "Troubleshooting",
        keywords = listOf("error", "slow", "stuck", "loading", "failed", "ram", "storage", "crash", "test"),
        body = "If a model is slow or fails to load, try a smaller model, enable Low RAM Mode, free storage, reduce max tokens, or run the Test button from Home or Models. For slow offline image generation, lower offline size and steps or use an online provider if you are comfortable sending the prompt to that provider."
    ),
)

fun buildPocketMindHelpContext(question: String): String {
    val q = question.lowercase()
    val ranked = helpTopics
        .map { topic -> topic to topic.keywords.count { keyword -> q.contains(keyword.lowercase()) } }
        .sortedByDescending { it.second }

    val selected = ranked.filter { it.second > 0 }.map { it.first }.take(5)
        .ifEmpty { helpTopics.take(6) }

    return buildString {
        appendLine("PocketMind built-in help reference:")
        selected.forEach { topic ->
            appendLine()
            appendLine("# ${topic.title}")
            appendLine(topic.body)
        }
    }
}

fun pocketMindHelpSystemPrompt(): String = """
You are PocketMind Helpdesk, the in-app support assistant for PocketMind.
Answer only questions about using PocketMind, including setup, models, API keys, files, privacy, chats, image generation, characters, storage, backups, and troubleshooting.
Use the built-in help reference as the source of truth.
Be concise, clear, friendly, and practical.
Give step-by-step instructions when useful.
If a question is outside PocketMind usage, briefly say that this helpdesk is focused on PocketMind app support.
Never claim that offline image generation is guaranteed to be fast. Explain that offline speed depends on device hardware and model size.
Never claim that online providers are controlled by PocketMind. Explain that online requests go to the selected provider.
""".trimIndent()
