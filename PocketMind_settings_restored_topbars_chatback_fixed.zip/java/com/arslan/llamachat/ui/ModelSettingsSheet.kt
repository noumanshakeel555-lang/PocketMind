package com.arslan.llamachat.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModelSettingsSheet(vm: ChatViewModel, onDismiss: () -> Unit) {
    val state by vm.state.collectAsState()

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(modifier = Modifier.fillMaxWidth()
            .padding(horizontal = 24.dp)
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()) {

            Text("Model Settings", fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleLarge)
            val subtitle = when {
                state.activeOnlineProvider == "groq"   -> "Groq Online · Llama 3.3 + Vision"
                state.activeOnlineProvider == "gemini" -> "Gemini 2.5 Flash"
                state.customGgufName.isNotBlank()      -> state.customGgufName
                else -> state.loadedModel?.displayName ?: ""
            }
            if (subtitle.isNotBlank()) {
                Text(subtitle, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (state.loadInfo.isNotBlank()) {
                Text(state.loadInfo, style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(top = 2.dp))
            }

            Spacer(Modifier.height(24.dp))

            Text("Max Response Tokens: ${state.maxTokens}",
                fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
            Text("Higher = longer answers. More tokens = slower on local models.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(value = state.maxTokens.toFloat(),
                onValueChange = { vm.setMaxTokens(it.roundToInt()) },
                valueRange = 64f..2048f, steps = 30, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("64 (short)", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("2048 (long)", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(Modifier.height(20.dp))

            Text("Creativity: ${"%.2f".format(state.temperature)}",
                fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
            Text("Lower = focused. Higher = creative and varied.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Slider(value = state.temperature, onValueChange = { vm.setTemperature(it) },
                valueRange = 0.1f..2.0f, steps = 18, modifier = Modifier.fillMaxWidth())
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("0.1 (precise)", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("2.0 (wild)", style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(Modifier.height(20.dp))

            if (state.activeOnlineProvider.isBlank()) {
                Text("Context Window: ${state.contextSize} tokens",
                    fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                Text("How much conversation history the model remembers. Larger = more RAM.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(512, 1024, 2048, 4096).forEach { size ->
                        FilterChip(selected = state.contextSize == size,
                            onClick = { vm.setContextSize(size) },
                            label = { Text("$size") })
                    }
                }

                Spacer(Modifier.height(20.dp))

                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Low RAM Mode", fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium)
                        Text("Forces 512 tokens context. Helps on 4–6 GB phones.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = state.lowRamMode, onCheckedChange = { vm.setLowRamMode(it) })
                }

                Spacer(Modifier.height(20.dp))
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Read Aloud (TTS)", fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium)
                    Text("Speaks responses using your device's voice engine.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = state.ttsEnabled, onCheckedChange = { vm.toggleTts() })
            }

            Spacer(Modifier.height(20.dp))

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Notify when done", fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.bodyMedium)
                    Text("Send a notification when the AI finishes responding.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = state.notifyOnDone, onCheckedChange = { vm.setNotifyOnDone(it) })
            }

            Spacer(Modifier.height(24.dp))
            Button(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Done") }
            Spacer(Modifier.height(16.dp))
        }
    }
}
