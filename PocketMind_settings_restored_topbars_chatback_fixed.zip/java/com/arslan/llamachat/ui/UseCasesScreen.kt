package com.arslan.llamachat.ui
import androidx.compose.runtime.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class UseCaseItem(
    val title: String,
    val subtitle: String,
    val steps: List<String>,
    val icon: ImageVector,
    val accent: Color,
    val primaryAction: String,
    val secondaryAction: String? = null,
    val target: HelpTarget,
    val secondaryTarget: HelpTarget? = null,
)

enum class HelpTarget {
    Chat,
    Models,
    ImageStudio,
    Characters,
    CustomModel,
    ApiKeys,
    Storage,
    Settings,
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UseCasesScreen(
    onBack: () -> Unit,
    onNavigate: (HelpTarget) -> Unit,
) {
    val useCases = listOf(
        UseCaseItem(
            title = "Study with PDFs and DOCX files",
            subtitle = "Attach notes, assignments, reports, and ask questions about them.",
            steps = listOf(
                "Open Chat and tap the attachment button.",
                "Choose a PDF, DOCX, TXT, code, CSV, JSON, or log file.",
                "Ask a clear question like: summarize this, explain chapter 2, or make quiz questions.",
                "Extracted text can be analyzed by offline or online text models. Offline keeps it on-device; online sends it to the selected provider. Scanned/image-only PDFs may not contain readable text unless OCR is available."
            ),
            icon = Icons.Default.Description,
            accent = Color(0xFF7C4DFF),
            primaryAction = "Open Chat",
            secondaryAction = "Choose Model",
            target = HelpTarget.Chat,
            secondaryTarget = HelpTarget.Models,
        ),
        UseCaseItem(
            title = "Analyze photos online",
            subtitle = "Use Gemini or Groq Vision to understand images.",
            steps = listOf(
                "Add a Gemini or Groq API key first.",
                "Select Gemini or Groq from Models.",
                "Attach a small photo under 4 MB in Chat.",
                "Ask what is in the image, describe it, or extract visible information. Offline text models cannot see photo pixels yet."
            ),
            icon = Icons.Default.PhotoCamera,
            accent = Color(0xFF4285F4),
            primaryAction = "API Keys",
            secondaryAction = "Open Chat",
            target = HelpTarget.ApiKeys,
            secondaryTarget = HelpTarget.Chat,
        ),
        UseCaseItem(
            title = "Chat fully offline",
            subtitle = "Download a GGUF model once and use it without internet.",
            steps = listOf(
                "Open Models and choose a model recommended for the device RAM.",
                "Download it and tap Load Model.",
                "Use the Test button to confirm it responds correctly.",
                "Start chatting offline. PDF, DOCX, and text extraction still works because it happens on-device."
            ),
            icon = Icons.Default.Memory,
            accent = Color(0xFF00A67E),
            primaryAction = "Open Models",
            secondaryAction = "Open Chat",
            target = HelpTarget.Models,
            secondaryTarget = HelpTarget.Chat,
        ),
        UseCaseItem(
            title = "Use fast online AI",
            subtitle = "Use Groq and Gemini for quick answers and stronger online features.",
            steps = listOf(
                "Open API Keys and paste a Groq or Gemini key.",
                "Save and verify the key.",
                "Select the online model from Models.",
                "Use online models for fast responses, photo understanding, and heavy questions."
            ),
            icon = Icons.Default.Cloud,
            accent = Color(0xFF03A9F4),
            primaryAction = "API Keys",
            secondaryAction = "Open Models",
            target = HelpTarget.ApiKeys,
            secondaryTarget = HelpTarget.Models,
        ),
        UseCaseItem(
            title = "Create images on-device",
            subtitle = "Use Image Studio with Stable Diffusion models.",
            steps = listOf(
                "Open Image Studio from the Create tab.",
                "Download an image model card or import a .safetensors, .ckpt, or compatible .gguf file.",
                "Start with 256×256 and 8–12 steps for testing.",
                "Use Test Image Model before trying bigger prompts or higher settings."
            ),
            icon = Icons.Default.Image,
            accent = Color(0xFFE91E63),
            primaryAction = "Image Studio",
            secondaryAction = "Storage",
            target = HelpTarget.ImageStudio,
            secondaryTarget = HelpTarget.Storage,
        ),
        UseCaseItem(
            title = "Create AI characters",
            subtitle = "Build tutors, coders, storytellers, roleplay characters, and custom assistants.",
            steps = listOf(
                "Open Characters.",
                "Select a built-in character or create a custom one.",
                "Give it a name, emoji, description, and system prompt.",
                "Start a chat to use the selected character personality."
            ),
            icon = Icons.Default.Person,
            accent = Color(0xFFFF9800),
            primaryAction = "Characters",
            secondaryAction = "Open Chat",
            target = HelpTarget.Characters,
            secondaryTarget = HelpTarget.Chat,
        ),
        UseCaseItem(
            title = "Use a custom GGUF model",
            subtitle = "Import local models from phone storage.",
            steps = listOf(
                "Download a GGUF model file from a trusted source.",
                "Open Custom GGUF.",
                "Pick the file and let PocketMind copy it into app storage.",
                "Load it, then use the Test button to confirm it works."
            ),
            icon = Icons.Default.FolderOpen,
            accent = Color(0xFF009688),
            primaryAction = "Custom GGUF",
            secondaryAction = "Storage",
            target = HelpTarget.CustomModel,
            secondaryTarget = HelpTarget.Storage,
        ),
        UseCaseItem(
            title = "Keep storage under control",
            subtitle = "Large LLM and image models can take many GBs.",
            steps = listOf(
                "Open Storage Manager.",
                "Review downloaded LLM models, image models, cache, and saved chat counts.",
                "Delete unused models to free storage space.",
                "Downloaded models can be reinstalled later if needed."
            ),
            icon = Icons.Default.Storage,
            accent = Color(0xFF607D8B),
            primaryAction = "Storage",
            secondaryAction = "Settings",
            target = HelpTarget.Storage,
            secondaryTarget = HelpTarget.Settings,
        ),
    )

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("What can I do?", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        Text(
                            "Guides and use cases",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = pocketMindTopBarInsets(),
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            item {
                HelpHeroCard(onStart = { onNavigate(HelpTarget.Models) })
            }
            items(useCases, key = { it.title }) { item ->
                UseCaseCard(item = item, onNavigate = onNavigate)
            }
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                ) {
                    Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Build, null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(Modifier.width(12.dp))
                        Text(
                            "If something does not work, use the Test buttons on Home, Models, or Image Studio first. They verify readiness without changing the current setup.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSecondaryContainer,
                        )
                    }
                }
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

@Composable
private fun HelpHeroCard(onStart: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(4.dp),
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.linearGradient(
                        listOf(
                            MaterialTheme.colorScheme.primaryContainer,
                            MaterialTheme.colorScheme.secondaryContainer,
                            MaterialTheme.colorScheme.tertiaryContainer,
                        )
                    )
                )
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(58.dp).clip(RoundedCornerShape(20.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Default.AutoAwesome, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("PocketMind playbook", fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Use this guide to explore features, match each task to the right model, and distinguish between offline, online, file, photo, and image-generation modes.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f),
                    )
                }
            }
            Button(onClick = onStart, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.RocketLaunch, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Choose a model and start")
            }
        }
    }
}

@Composable
private fun UseCaseCard(item: UseCaseItem, onNavigate: (HelpTarget) -> Unit) {
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth().clickable { expanded = !expanded },
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(1.dp),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(16.dp)).background(item.accent.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(item.icon, null, tint = item.accent)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text(item.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Icon(if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (expanded) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item.steps.forEachIndexed { index, step ->
                        Row(verticalAlignment = Alignment.Top) {
                            Box(
                                Modifier.size(24.dp).clip(RoundedCornerShape(12.dp)).background(item.accent.copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("${index + 1}", color = item.accent, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                            }
                            Spacer(Modifier.width(10.dp))
                            Text(step, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { onNavigate(item.target) },
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = item.accent),
                ) {
                    Text(item.primaryAction)
                }
                if (item.secondaryAction != null && item.secondaryTarget != null) {
                    OutlinedButton(
                        onClick = { onNavigate(item.secondaryTarget) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(item.secondaryAction)
                    }
                }
            }
        }
    }
}
