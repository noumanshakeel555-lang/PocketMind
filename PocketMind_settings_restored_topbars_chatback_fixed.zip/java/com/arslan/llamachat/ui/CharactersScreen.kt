package com.arslan.llamachat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.arslan.llamachat.llm.Character
import com.arslan.llamachat.llm.CharacterManager

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharactersScreen(vm: ChatViewModel, onBack: () -> Unit, onStartChat: () -> Unit) {
    val context = LocalContext.current
    val state by vm.state.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }
    var editingCharacter by remember { mutableStateOf<Character?>(null) }
    val allChars = remember(state.customCharacters) {
        CharacterManager.allCharacters(context)
    }

    if (showCreateDialog || editingCharacter != null) {
        CharacterEditDialog(
            existing = editingCharacter,
            onDismiss = { showCreateDialog = false; editingCharacter = null },
            onSave = { char ->
                vm.saveCharacter(char)
                showCreateDialog = false
                editingCharacter = null
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Characters", fontWeight = FontWeight.Bold, fontSize = 20.sp) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                },
                actions = {
                    IconButton(onClick = { showCreateDialog = true }) {
                        Icon(Icons.Default.Add, "Create character")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = TopAppBarDefaults.windowInsets
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {

            item {
                CharacterHeroCard(onCreate = { showCreateDialog = true })
            }

            item {
                Text("Built-in Characters", fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(4.dp))
            }

            items(allChars.filter { it.isBuiltIn }, key = { it.id }) { char ->
                CharacterCard(
                    character = char,
                    isActive = state.activeCharacterId == char.id,
                    onSelect = {
                        vm.setCharacter(char)
                        onStartChat()
                    },
                    onEdit = null,
                    onDelete = null,
                )
            }

            val custom = allChars.filter { !it.isBuiltIn }
            if (custom.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(4.dp))
                    Text("My Characters", fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall,
                        color = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.height(4.dp))
                }
                items(custom, key = { it.id }) { char ->
                    CharacterCard(
                        character = char,
                        isActive = state.activeCharacterId == char.id,
                        onSelect = { vm.setCharacter(char); onStartChat() },
                        onEdit = { editingCharacter = char },
                        onDelete = { vm.deleteCharacter(char.id) },
                    )
                }
            }

            item {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { showCreateDialog = true },
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                    Icon(Icons.Default.Add, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Create Custom Character")
                }
            }
        }
    }
}

@Composable
private fun CharacterHeroCard(onCreate: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        shape = RoundedCornerShape(24.dp),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(56.dp).clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Person, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(30.dp))
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("Characters make every AI feel different",
                        fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                    Text("Pick a built-in personality or create your own custom assistant.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.75f))
                }
            }
            Spacer(Modifier.height(16.dp))
            Button(onClick = onCreate, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                Icon(Icons.Default.Add, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Create Custom Character")
            }
        }
    }
}

@Composable
fun CharacterCard(
    character: Character, isActive: Boolean,
    onSelect: () -> Unit, onEdit: (() -> Unit)?, onDelete: (() -> Unit)?,
) {
    Card(modifier = Modifier.fillMaxWidth().clickable { onSelect() },
        colors = CardDefaults.cardColors(
            containerColor = if (isActive) MaterialTheme.colorScheme.primaryContainer
            else MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(if (isActive) 4.dp else 1.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center) {
                Text(character.avatarEmoji, fontSize = 26.sp)
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(character.name, fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleSmall)
                    if (isActive) Badge(containerColor = MaterialTheme.colorScheme.primary) {
                        Text("Active", modifier = Modifier.padding(horizontal = 4.dp))
                    }
                }
                Text(character.description, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(top = 2.dp))
            }
            if (onEdit != null) {
                IconButton(onClick = onEdit, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Edit, null, Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            if (onDelete != null) {
                IconButton(onClick = onDelete, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.Delete, null, Modifier.size(18.dp),
                        tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

val EMOJI_OPTIONS = listOf("🤖","🧠","🎭","🔬","📚","👨‍🍳","💻","🏛️","🌿","🦊","🐉","🧙","👾","🎯","🚀","⚡","🌊","🔥","🎵","🌟")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharacterEditDialog(
    existing: Character?, onDismiss: () -> Unit, onSave: (Character) -> Unit,
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var description by remember { mutableStateOf(existing?.description ?: "") }
    var systemPrompt by remember { mutableStateOf(existing?.systemPrompt ?: "") }
    var emoji by remember { mutableStateOf(existing?.avatarEmoji ?: "🤖") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Create Character" else "Edit Character") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Avatar", style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary)
                androidx.compose.foundation.lazy.LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(EMOJI_OPTIONS) { e ->
                        Box(modifier = Modifier.size(42.dp).clip(CircleShape)
                            .background(if (emoji == e) MaterialTheme.colorScheme.primary.copy(0.2f)
                            else MaterialTheme.colorScheme.surfaceVariant)
                            .border(if (emoji == e) 2.dp else 0.dp,
                                MaterialTheme.colorScheme.primary, CircleShape)
                            .clickable { emoji = e },
                            contentAlignment = Alignment.Center) {
                            Text(e, fontSize = 22.sp)
                        }
                    }
                }
                OutlinedTextField(value = name, onValueChange = { name = it },
                    label = { Text("Name") }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true, shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = description, onValueChange = { description = it },
                    label = { Text("Short description") }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true, shape = RoundedCornerShape(12.dp))
                OutlinedTextField(value = systemPrompt, onValueChange = { systemPrompt = it },
                    label = { Text("System prompt (personality)") },
                    modifier = Modifier.fillMaxWidth().height(120.dp),
                    shape = RoundedCornerShape(12.dp))
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank() && systemPrompt.isNotBlank()) {
                    onSave(Character(
                        id = existing?.id ?: System.currentTimeMillis().toString(),
                        name = name.trim(), description = description.trim(),
                        systemPrompt = systemPrompt.trim(), avatarEmoji = emoji,
                    ))
                }
            }, enabled = name.isNotBlank() && systemPrompt.isNotBlank()) {
                Text("Save")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
