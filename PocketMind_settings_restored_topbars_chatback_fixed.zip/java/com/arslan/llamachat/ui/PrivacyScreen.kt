package com.arslan.llamachat.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Privacy & Offline Mode", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                windowInsets = pocketMindTopBarInsets(),
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(26.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            Modifier.size(56.dp).clip(RoundedCornerShape(18.dp))
                                .background(MaterialTheme.colorScheme.primary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Lock, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Built for private AI", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                            Text(
                                "PocketMind is designed to keep offline work on-device and make every online action clear before anything is sent.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.78f)
                            )
                        }
                    }
                }
            }

            item {
                PrivacyItem(
                    Icons.Default.Memory,
                    "Offline mode stays on-device",
                    "When a downloaded GGUF model is used, prompts, chat history, attached document text, and generated responses are processed locally on the phone. They are not uploaded to PocketMind servers."
                )
            }
            item {
                PrivacyItem(
                    Icons.Default.Description,
                    "Document reading is local first",
                    "PDF, DOCX, text, code, CSV, JSON, and log extraction happens on-device. The extracted text is then used by the selected model: local models keep it on-device, while online models require sending the request to the chosen provider."
                )
            }
            item {
                PrivacyItem(
                    Icons.Default.Cloud,
                    "Online models are optional",
                    "Groq and Gemini require internet. When an online model is selected, the content needed for that request is sent directly from the phone to the selected provider using the stored API key."
                )
            }
            item {
                PrivacyItem(
                    Icons.Default.Key,
                    "API keys stay local",
                    "Groq and Gemini keys are stored on this device. PocketMind does not operate a separate server to collect, proxy, or read API keys."
                )
            }
            item {
                PrivacyItem(
                    Icons.Default.PhotoCamera,
                    "Photos need a vision provider",
                    "Photo understanding is available through vision-capable online models. Offline text models cannot see image pixels yet, so they only receive an attachment note instead of the image itself."
                )
            }
            item {
                PrivacyItem(
                    Icons.Default.Image,
                    "Image Studio storage",
                    "Imported or downloaded image models stay in app storage. Generated images are saved only when explicitly saved, and saved images are then managed by the phone gallery."
                )
            }
            item {
                PrivacyItem(
                    Icons.Default.Save,
                    "Backups are user-controlled",
                    "Backup files are created only during export. Backup JSON files should be kept private because they may contain saved chats, prompts, and custom characters."
                )
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "Responsible AI use",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onTertiaryContainer
                        )
                        Text(
                            "PocketMind can help explain, summarize, draft, and reason, but AI output can be incomplete or wrong. For medical, legal, financial, academic, or safety-critical decisions, verify important information with qualified professionals and trusted sources.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PrivacyItem(icon: ImageVector, title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
    ) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(15.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodyMedium)
                Text(body, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
